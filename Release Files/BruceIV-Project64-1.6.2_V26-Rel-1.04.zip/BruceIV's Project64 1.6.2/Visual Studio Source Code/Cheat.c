/*
*Project64 - A Nintendo 64 emulator.
*
*(c) Copyright 2001 zilmar (zilmar@emulation64.com) and
*Jabo (jabo@emulation64.com).
*
*pj64 homepage: www.pj64.net
*
*Permission to use, copy, modify and distribute Project64 in both binary and
*source form, for non-commercial purposes, is hereby granted without fee,
*providing that this license information and copyright notice appear with
*all copies and any derived work.
*
*This software is provided 'as-is', without any express or implied
*warranty. In no event shall the authors be held liable for any damages
*arising from the use of this software.
*
*Project64 is freeware for PERSONAL USE only. Commercial users should
*seek permission of the copyright holders first. Commercial use includes
*charging money for Project64 or software derived from Project64.
*
*The copyright holders request that bug fixes and improvements to the code
*should be forwarded to them so if they want them.
*
*/
#include <Windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <stdio.h>
#include <winuser.h>
#include <string.h>
#include "Main.h"
#include "Cheat.h"
#include "CPU.h"
#include "Plugin.h"
#include "Resource.h"
#define UM_CLOSE_CHEATS         (WM_APP+1)
#define UM_CHANGECODEEXTENSION  (WM_APP+2)
#define IDC_MYTREE				0x500
#define SelectCheat				1
#define EditCheat				2
#define NewCheat 				3
HWND hManageWindow=0,hSelectCheat,hAddCheat,hCheatTree;
CHEAT_CODES Codes[999]; // Don't support more than 999 cheats
char codestring[2048],optionsstring[8192];
int NoOfCodes,codeformat,numcodes,numoptions,MinSizeDlg,MaxSizeDlg;
BOOL validname,validcodes,validoptions,nooptions;
LRESULT CALLBACK ManageCheatsProc (HWND,UINT,WPARAM,LPARAM);
enum Dialog_State {
	CONTRACTED,
	EXPANDED
} DialogState;
enum Cheat_Type {
	SIMPLE,
	OPTIONS,
	RANGE
} CheatType;
enum TV_CHECK_STATE{
	TV_STATE_CLEAR,
	TV_STATE_CHECKED,
	TV_STATE_INDETERMINATE,
} DialogState;
BOOL CheatUsesCodeExtensions (char*CheatString) {
	BOOL CodeExtension;
	DWORD count,len;
	char*ReadPos;
	if (strlen(CheatString)==0||strchr(CheatString,'"')==0) return FALSE;
	len=strrchr(CheatString,'"')-strchr(CheatString,'"')-1;
	ReadPos=strrchr(CheatString,'"')+2;
	CodeExtension=FALSE;
	for (count=0;count<MaxGSEntries&&CodeExtension==FALSE;count++) {
		if (strchr(ReadPos,' ')==0) {break;}
		ReadPos=strchr(ReadPos,' ')+1;
		if (ReadPos[0]=='?'&&ReadPos[1]=='?'||ReadPos[2]=='?'&&ReadPos[3]=='?') CodeExtension=TRUE;
		if (strchr(ReadPos,',')==0) continue;
		ReadPos=strchr(ReadPos,',')+1;
	}
	return CodeExtension;
}
BOOL LoadCheatExt(char*CheatName,char*CheatExt,int MaxCheatExtLen) {
	char String[300],Identifier[100];
	HKEY hKeyResults=0;
	long lResult;
	if (CheatName!=0) {
		sprintf(Identifier,"%08X-%08X-C:%X",*(DWORD*)(&RomHeader[0x10]),*(DWORD*)(&RomHeader[0x14]),RomHeader[0x3D]);
		sprintf(String,"PJ64 V 1.6.2\\Configuration\\Cheats\\%s",Identifier);
		lResult=RegOpenKeyEx(HKEY_CURRENT_USER,String,0,KEY_ALL_ACCESS,&hKeyResults);
		if (lResult==ERROR_SUCCESS) {
			DWORD Type,Bytes;
			sprintf(String,"%s.exten",CheatName);
			Bytes=MaxCheatExtLen;
			lResult=RegQueryValueEx(hKeyResults,String,0,&Type,(LPBYTE)CheatExt,&Bytes);
			RegCloseKey(hKeyResults);
			if (lResult==ERROR_SUCCESS) return TRUE;
		}
	}
	return FALSE;
}
void AddCheatExtension(int CheatNo,char*CheatName,int CheatNameLen) {
	char*String=0,Identifier[100],CheatNumber[20];
	LPSTR IniFileName=GetCheatIniFileName();
	sprintf(Identifier,"%08X-%08X-C:%X",*(DWORD*)(&RomHeader[0x10]),*(DWORD*)(&RomHeader[0x14]),RomHeader[0x3D]);
	sprintf(CheatNumber,"Cheat%d",CheatNo);
	_GetPrivateProfileString2(Identifier,CheatNumber,"",&String,IniFileName);
	//Add cheat extension to the end
	if (CheatUsesCodeExtensions(String)) {
		char CheatExt[300];
		if (!LoadCheatExt(CheatName,CheatExt,sizeof(CheatExt))) {strcpy(CheatExt,"?");}
		sprintf(CheatName,"%s (=> %s)",CheatName,CheatExt);
	}
	if (String) {free(String);}
}
/********************************************************************************************
  ConvertXP64Address
  Purpose: Decode encoded XP64 address to physical address
  Author: Witten
********************************************************************************************/
DWORD ConvertXP64Address(DWORD Address) {
	DWORD tmpAddress;
	tmpAddress=(Address^0x68000000)&0xFF000000;
	tmpAddress+=((Address+0x002B0000)^0x00810000)&0x00FF0000;
	tmpAddress+=((Address+0x00002B00)^0x00008200)&0x0000FF00;
	tmpAddress+=((Address+0x0000002B)^0x00000083)&0x000000FF;
	return tmpAddress;
}
/********************************************************************************************
  ConvertXP64Value
  Purpose: Decode encoded XP64 value
  Author: Witten
********************************************************************************************/
WORD ConvertXP64Value(WORD Value) {
	WORD tmpValue;
	tmpValue=((Value+0x2B00)^0x8400)&0xFF00;
	tmpValue+=((Value+0x002B)^0x0085)&0x00FF;
	return tmpValue;
}
void ApplyGSButton () {
	int count,count2,count3;
	DWORD Address;
	WORD Memory;
	GAMESHARK_CODE PrevCode;
	for (count=0;count<NoOfCodes;count++) {
		PrevCode.Command=0X00000000;
		PrevCode.Value=0x0000;
		for (count2=0;count2<MaxGSEntries;count2++) {
			if ((PrevCode.Command&0xFF000000)==0x50000000) {
				int numrepeats=(PrevCode.Command&0x0000FF00)>>8,offset=PrevCode.Command&0x000000FF,incr=PrevCode.Value;
				switch (Codes[count].Code[count2].Command&0xFF000000) {
				// Gameshark / AR
				case 0x88000000:
					Address=0x80000000|(Codes[count].Code[count2].Command&0xFFFFFF);
					Memory=Codes[count].Code[count2].Value;
					for (count3=0;count3<numrepeats;count3++) {
						r4300i_SB_VAddr(Address,(BYTE)Memory);
						Address+=offset;
						Memory+=incr;
					}
					break;
				case 0x89000000:
					Address=0x80000000|(Codes[count].Code[count2].Command&0xFFFFFF);
					Memory=Codes[count].Code[count2].Value;
					for (count3=0;count3<numrepeats;count3++) {
						r4300i_SH_VAddr(Address,(WORD)Memory);
						Address+=offset;
						Memory+=incr;
					}
					break;
				// Xplorer64
				case 0xA8000000:
					Address=0x80000000|(ConvertXP64Address(Codes[count].Code[count2].Command)&0xFFFFFF);
					Memory=ConvertXP64Value(Codes[count].Code[count2].Value);
					for (count3=0;count3<numrepeats;count3++) {
						r4300i_SB_VAddr(Address,(BYTE)Memory);
						Address+=offset;
						Memory+=incr;
					}
					break;
				case 0xA9000000:
					Address=0x80000000|(ConvertXP64Address(Codes[count].Code[count2].Command)&0xFFFFFF);
					Memory=ConvertXP64Value(Codes[count].Code[count2].Value);
					for (count3=0;count3<numrepeats;count3++) {
						r4300i_SH_VAddr(Address,(WORD)Memory);
						Address+=offset;
						Memory+=incr;
					}
					break;
				}
			} else {
				switch (Codes[count].Code[count2].Command&0xFF000000) {
				// Gameshark / AR
				case 0x88000000:
					Address=0x80000000|(Codes[count].Code[count2].Command&0xFFFFFF);
					r4300i_SB_VAddr(Address,(BYTE)Codes[count].Code[count2].Value);
					break;
				case 0x89000000:
					Address=0x80000000|(Codes[count].Code[count2].Command&0xFFFFFF);
					r4300i_SH_VAddr(Address,Codes[count].Code[count2].Value);
					break;
				// Xplorer64
				case 0xA8000000:
					Address=0x80000000|(ConvertXP64Address(Codes[count].Code[count2].Command)&0xFFFFFF);
					r4300i_SB_VAddr(Address,(BYTE)ConvertXP64Value(Codes[count].Code[count2].Value));
					break;
				case 0xA9000000:
					Address=0x80000000|(ConvertXP64Address(Codes[count].Code[count2].Command)&0xFFFFFF);
					r4300i_SH_VAddr(Address,ConvertXP64Value(Codes[count].Code[count2].Value));
					break;
				}
			}
			PrevCode.Command=Codes[count].Code[count2].Command;
			PrevCode.Value=Codes[count].Code[count2].Value;
		}
	}
}
/********************************************************************************************
  ApplyCheats
  Purpose: Patch codes into memory
********************************************************************************************/
int ApplyCheatEntry (GAMESHARK_CODE*Code,BOOL Execute) {
	DWORD Address;
	WORD Memory;
	switch (Code->Command&0xFF000000) {
	case 0x50000000:													// Added by Witten (witten@pj64cheats.net)
		{
			int numrepeats=(Code->Command&0x0000FF00)>>8,offset=Code->Command&0x000000FF,incr=Code->Value,count;
			switch (Code[1].Command&0xFF000000) {
			case 0x80000000:
				Address=0x80000000|(Code[1].Command&0xFFFFFF);
				Memory=Code[1].Value;
				for (count=0;count<numrepeats;count++) {
					r4300i_SB_VAddr(Address,(BYTE)Memory);
					Address+=offset;
					Memory+=incr;
				}
				return 2;
			case 0x81000000:
				Address=0x80000000|(Code[1].Command&0xFFFFFF);
				Memory=Code[1].Value;
				for (count=0;count<numrepeats;count++) {
					r4300i_SH_VAddr(Address,(WORD)Memory);
					Address+=offset;
					Memory+=incr;
				}
				return 2;
			default: return 1;
			}
		}
		break;
	case 0x80000000:
		Address=0x80000000|(Code->Command&0xFFFFFF);
		if (Execute) {r4300i_SB_VAddr(Address,(BYTE)Code->Value);}
		break;
	case 0x81000000:
		Address=0x80000000|(Code->Command&0xFFFFFF);
		if (Execute) {r4300i_SH_VAddr(Address,Code->Value);}
		break;
	case 0xA0000000:
		Address=0xA0000000|(Code->Command&0xFFFFFF);
		if (Execute) {r4300i_SB_VAddr(Address,(BYTE)Code->Value);}
		break;
	case 0xA1000000:
		Address=0xA0000000|(Code->Command&0xFFFFFF);
		if (Execute) {r4300i_SH_VAddr(Address,Code->Value);}
		break;
	case 0xD0000000:													// Added by Witten (witten@pj64cheats.net)
		Address=0x80000000|(Code->Command&0xFFFFFF);
		r4300i_LB_VAddr(Address,(BYTE*)&Memory);
		Memory&=0x00FF;
		if (Memory!=Code->Value) {Execute=FALSE;}
		return ApplyCheatEntry(&Code[1],Execute)+1;
	case 0xD1000000:													// Added by Witten (witten@pj64cheats.net)
		Address=0x80000000|(Code->Command&0xFFFFFF);
		r4300i_LH_VAddr(Address,(WORD*)&Memory);
		if (Memory!=Code->Value) {Execute=FALSE;}
		return ApplyCheatEntry(&Code[1],Execute)+1;
	case 0xD2000000:													// Added by Witten (witten@pj64cheats.net)
		Address=0x80000000|(Code->Command&0xFFFFFF);
		r4300i_LB_VAddr(Address,(BYTE*)&Memory);
		Memory&=0x00FF;
		if (Memory==Code->Value) {Execute=FALSE;}
		return ApplyCheatEntry(&Code[1],Execute)+1;
	case 0xD3000000:													// Added by Witten (witten@pj64cheats.net)
		Address=0x80000000|(Code->Command&0xFFFFFF);
		r4300i_LH_VAddr(Address,(WORD*)&Memory);
		if (Memory==Code->Value) {Execute=FALSE;}
		return ApplyCheatEntry(&Code[1],Execute)+1;
		// Xplorer64 (Author: Witten)
	case 0x30000000:
	case 0x82000000:
	case 0x84000000:
		Address=0x80000000|(Code->Command&0xFFFFFF);
		if (Execute) {r4300i_SB_VAddr(Address,(BYTE)Code->Value);}
		break;
	case 0x31000000:
	case 0x83000000:
	case 0x85000000:
		Address=0x80000000|(Code->Command&0xFFFFFF);
		if (Execute) {r4300i_SH_VAddr(Address,Code->Value);}
		break;
	case 0xE8000000:
		Address=0x80000000|(ConvertXP64Address(Code->Command)&0xFFFFFF);
		if (Execute) {r4300i_SB_VAddr(Address,(BYTE)ConvertXP64Value(Code->Value));}
		break;
	case 0xE9000000:
		Address=0x80000000|(ConvertXP64Address(Code->Command)&0xFFFFFF);
		if (Execute) {r4300i_SH_VAddr(Address,ConvertXP64Value(Code->Value));}
		break;
	case 0xC8000000:
		Address=0xA0000000|(ConvertXP64Address(Code->Command)&0xFFFFFF);
		if (Execute) {r4300i_SB_VAddr(Address,(BYTE)Code->Value);}
		break;
	case 0xC9000000:
		Address=0xA0000000|(ConvertXP64Address(Code->Command)&0xFFFFFF);
		if (Execute) {r4300i_SH_VAddr(Address,ConvertXP64Value(Code->Value));}
		break;
	case 0xB8000000:
		Address=0x80000000|(ConvertXP64Address(Code->Command)&0xFFFFFF);
		r4300i_LB_VAddr(Address,(BYTE*)&Memory);
		Memory&=0x00FF;
		if (Memory!=ConvertXP64Value(Code->Value)) {Execute=FALSE;}
		return ApplyCheatEntry(&Code[1],Execute)+1;
	case 0xB9000000:
		Address=0x80000000|(ConvertXP64Address(Code->Command)&0xFFFFFF);
		r4300i_LH_VAddr(Address,(WORD*)&Memory);
		if (Memory!=ConvertXP64Value(Code->Value)) {Execute=FALSE;}
		return ApplyCheatEntry(&Code[1],Execute)+1;
	case 0xBA000000:
		Address=0x80000000|(ConvertXP64Address(Code->Command)&0xFFFFFF);
		r4300i_LB_VAddr(Address,(BYTE*)&Memory);
		Memory&=0x00FF;
		if (Memory==ConvertXP64Value(Code->Value)) {Execute=FALSE;}
		return ApplyCheatEntry(&Code[1],Execute)+1;
	case 0xBB000000:
		Address=0x80000000|(ConvertXP64Address(Code->Command)&0xFFFFFF);
		r4300i_LH_VAddr(Address,(WORD*)&Memory);
		if (Memory==ConvertXP64Value(Code->Value)) {Execute=FALSE;}
		return ApplyCheatEntry(&Code[1],Execute)+1;
	case 0: return MaxGSEntries;
	}
	return 1;
}
void ApplyCheats () {
	int CurrentCheat,CurrentEntry;
	for (CurrentCheat=0;CurrentCheat<NoOfCodes;CurrentCheat++) {
		for (CurrentEntry=0;CurrentEntry<MaxGSEntries;) {
			CurrentEntry+=ApplyCheatEntry(&Codes[CurrentCheat].Code[CurrentEntry],TRUE);
		}
	}
}
void ChangeRomCheats(HWND hwndOwner) {
	char OrigFileName[sizeof(CurrentFileName)];
	BYTE OrigByteHeader[sizeof(RomHeader)];
	DWORD OrigFileSize;
	CloseCheatWindow();
	//Load information about target rom and back up current information
	strncpy(OrigFileName,CurrentFileName,sizeof(OrigFileName));
	memcpy(OrigByteHeader,RomHeader,sizeof(RomHeader));
	strncpy(CurrentFileName,CurrentRBFileName,sizeof(CurrentFileName));
	OrigFileSize=RomFileSize;
	LoadRomHeader();
	ManageCheats(hwndOwner);
	//Restore details
	strncpy(CurrentFileName,OrigFileName,sizeof(CurrentFileName));
	memcpy(RomHeader,OrigByteHeader,sizeof(RomHeader));
	RomFileSize=OrigFileSize;
}
/********************************************************************************************
  CheatActive
  Purpose: Checks in registry if cheat is active
  Parameters: char*
  Name: name of cheat
  Returns: Boolean
  True: cheat is active
  False: cheat isn't active or cheat isn't found in registry
********************************************************************************************/
BOOL CheatActive (char*Name) {
	char String[300],Identifier[100];
	HKEY hKeyResults=0;
	long lResult;
	sprintf(Identifier,"%08X-%08X-C:%X",*(DWORD*)(&RomHeader[0x10]),*(DWORD*)(&RomHeader[0x14]),RomHeader[0x3D]);
	sprintf(String,"PJ64 V 1.6.2\\Configuration\\Cheats\\%s",Identifier);
	lResult=RegOpenKeyEx(HKEY_CURRENT_USER,String,0,KEY_ALL_ACCESS,&hKeyResults); // check if game ID exists in registry
	if (lResult==ERROR_SUCCESS) {
		DWORD Type,Bytes,Active;
		Bytes=sizeof(Active);
		lResult=RegQueryValueEx(hKeyResults,Name,0,&Type,(LPBYTE)(&Active),&Bytes); // get cheat-state from registry
		RegCloseKey(hKeyResults);
		if (lResult==ERROR_SUCCESS) {return Active;} // if no errors return active state
	}
	return FALSE;
}
void SaveCheat(char*CheatName,BOOL Active) {
	char String[300],Identifier[100];
	DWORD Disposition=0;
	HKEY hKeyResults=0;
	long lResult;
	sprintf(Identifier,"%08X-%08X-C:%X",*(DWORD*)(&RomHeader[0x10]),*(DWORD*)(&RomHeader[0x14]),RomHeader[0x3D]);
	sprintf(String,"PJ64 V 1.6.2\\Configuration\\Cheats\\%s",Identifier);
	lResult=RegCreateKeyEx(HKEY_CURRENT_USER,String,0,"",REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,0,&hKeyResults,&Disposition);
	if (lResult==ERROR_SUCCESS) {
		if (Active) RegSetValueEx(hKeyResults,CheatName,0,REG_DWORD,(CONST BYTE*)(&Active),sizeof(DWORD));
		else RegDeleteValue(hKeyResults,CheatName);
		RegCloseKey(hKeyResults);
	}
}
void SaveCheatExt(char*CheatName,char*CheatExt) {
	char String[300],Identifier[100];
	DWORD Disposition=0;
	HKEY hKeyResults=0;
	long lResult;
	sprintf(Identifier,"%08X-%08X-C:%X",*(DWORD*)(&RomHeader[0x10]),*(DWORD*)(&RomHeader[0x14]),RomHeader[0x3D]);
	sprintf(String,"PJ64 V 1.6.2\\Configuration\\Cheats\\%s",Identifier);
	lResult=RegCreateKeyEx(HKEY_CURRENT_USER,String,0,"",REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,0,&hKeyResults,&Disposition);
	if (lResult==ERROR_SUCCESS) {
		sprintf(String,"%s.exten",CheatName);
		RegSetValueEx(hKeyResults,String,0,REG_SZ,(CONST BYTE*)CheatExt,strlen(CheatExt));
		RegCloseKey(hKeyResults);
	}
}
BOOL GetCheatName(int CheatNo,char*CheatName,int CheatNameLen) {
	char*String=0,Identifier[100];
	DWORD len;
	LPSTR IniFileName;
	IniFileName=GetCheatIniFileName();
	sprintf(Identifier,"%08X-%08X-C:%X",*(DWORD*)(&RomHeader[0x10]),*(DWORD*)(&RomHeader[0x14]),RomHeader[0x3D]);
	sprintf(CheatName,"Cheat%d",CheatNo);
	_GetPrivateProfileString2(Identifier,CheatName,"",&String,IniFileName);
	if (strlen(String)==0) {
		memset(CheatName,0,CheatNameLen);
		if (String) {free(String);}
		return FALSE;
	}
	len=strrchr(String,'"')-strchr(String,'"')-1;
	memset(CheatName,0,CheatNameLen);
	strncpy(CheatName,strchr(String,'"')+1,len);
	if (String) {free(String);}
	return TRUE;
}
LRESULT CALLBACK CheatsCodeExProc (HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam) {
	static DWORD CheatNo;
	switch (uMsg) {
	case WM_INITDIALOG:
		CheatNo=lParam;
		{
			char*String=0,Identifier[100],CheatName[300],CheatExt[300],*ReadPos;
			LPSTR IniFileName;
			DWORD len;
			SetWindowText(hDlg,"Code Extensions");
			SetDlgItemText(hDlg,IDC_NOTE,"Please choose a value to be used for:");
			SetDlgItemText(hDlg,IDOK,"OK");
			GetCheatName(CheatNo,CheatName,sizeof(CheatName));
			SetDlgItemText(hDlg,IDC_CHEAT_NAME,CheatName);
			LoadCheatExt(CheatName,CheatExt,sizeof(CheatExt));
			IniFileName=GetCheatIniFileName();
			sprintf(Identifier,"%08X-%08X-C:%X",*(DWORD*)(&RomHeader[0x10]),*(DWORD*)(&RomHeader[0x14]),RomHeader[0x3D]);
			sprintf(CheatName,"Cheat%d_O",CheatNo);
			_GetPrivateProfileString2(Identifier,CheatName,"",&String,IniFileName);
			ReadPos=String;
			while (strlen(ReadPos)>0) {
				int index;
				if(strchr(ReadPos,',')==0) {
					len=strlen(ReadPos);
				} else {
					len=strchr(ReadPos,',')-ReadPos;
				}
				if (len>=sizeof(CheatName)) {len=sizeof(CheatName)-1;}
				strncpy(CheatName,ReadPos,len);
				CheatName[len]=0;
				index=SendMessage(GetDlgItem(hDlg,IDC_CHEAT_LIST),LB_ADDSTRING,0,(LPARAM)CheatName);
				if (strcmp(CheatExt,CheatName)==0) {
					SendMessage(GetDlgItem(hDlg,IDC_CHEAT_LIST),LB_SETCURSEL,index,0);
				}
				if (strchr(ReadPos,',')==0) {
					ReadPos+=strlen(ReadPos);
				} else {
					ReadPos=strchr(ReadPos,',')+1;
				}
			}
			if (String) {free(String);}
		}
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case IDC_CHEAT_LIST:
			if (HIWORD(wParam)==LBN_DBLCLK) {PostMessage(hDlg,WM_COMMAND,IDOK,0); break;}
			break;
		case IDOK:
			{
				char CheatName[300],CheatExt[300];
				int index;
				index=SendMessage(GetDlgItem(hDlg,IDC_CHEAT_LIST),LB_GETCURSEL,0,0);
				if (index<0) {index=0;}
				GetDlgItemText(hDlg,IDC_CHEAT_NAME,CheatName,sizeof(CheatName));
				index=SendMessage(GetDlgItem(hDlg,IDC_CHEAT_LIST),LB_GETTEXT,index,(LPARAM)CheatExt);
				SaveCheatExt(CheatName,CheatExt);
				LoadCheats();
			}
			EndDialog(hDlg,0);
			break;
		case IDCANCEL:
			EndDialog(hDlg,0);
			break;
		}
	default:
		return FALSE;
	}
	return TRUE;
}
int ReadCodeString (HWND hDlg) {
	int numlines,linecount,len,i;
	char str[128],tempformat[128],*formatnormal= "XXXXXXXX XXXX",*formatoptionlb="XXXXXXXX XX??",*formatoptionw="XXXXXXXX ????";
	validcodes=TRUE;
	nooptions=TRUE;
	codeformat=-1;
	numcodes=0;
	memset(codestring,'\0',2048);
	numlines=SendDlgItemMessage(hDlg,IDC_CHEAT_CODES,EM_GETLINECOUNT,0,0);
	if (numlines==0) {validcodes=FALSE;}
	for (linecount=0;linecount<numlines;linecount++) //read line after line (bypassing limitation GetDlgItemText)
	{
		memset(tempformat,0,sizeof(tempformat));
		*(LPWORD)str=sizeof(str);
		len=SendDlgItemMessage(hDlg,IDC_CHEAT_CODES,EM_GETLINE,(WPARAM)linecount,(LPARAM)(LPCSTR)str);
		str[len]=0;
		if (len<=0) continue;
		for (i=0;i<128;i++) {
			if (((str[i]>='A')&&(str[i]<='F'))||((str[i]>='0')&&(str[i]<='9'))) {// Is hexvalue
				tempformat[i]='X';
			}
			if ((str[i]==' ')||(str[i]=='?')) {
				tempformat[i]=str[i];
			}
			if (str[i]==0) {break;}
		}
		if (strcmp(tempformat,formatnormal)==0) {
			strcat(codestring,",");
			strcat(codestring,str);
			numcodes++;
			if (codeformat<0) codeformat=0;
		}
		else if (strcmp(tempformat,formatoptionlb)==0) {
			if (codeformat!=2) {
				strcat(codestring,",");
				strcat(codestring,str);
				numcodes++;
				codeformat=1;
				nooptions=FALSE;
				validoptions=FALSE;
			} else validcodes=FALSE;
		}
		else if (strcmp(tempformat,formatoptionw)==0) {
			if (codeformat!=1) {
				strcat(codestring,",");
				strcat(codestring,str);
				numcodes++;
				codeformat=2;
				nooptions=FALSE;
				validoptions=FALSE;
			} else validcodes=FALSE;
		} else validcodes=FALSE;
	}
	return 0;
}
void ReadOptionsString(HWND hDlg)
{
	int numlines,linecount,len,i,j,leftorder=0,rightorder=0;
	char str[128];
	validoptions=TRUE;
	numoptions=0;
	memset(optionsstring,'\0',2048);
	numlines=SendDlgItemMessage(hDlg,IDC_CHEAT_OPTIONS,EM_GETLINECOUNT,0,0);
	for (linecount=0;linecount<numlines;linecount++) //read line after line (bypassing limitation GetDlgItemText)
	{
		memset(str,0,sizeof(str));
		*(LPWORD)str=sizeof(str);
		len=SendDlgItemMessage(hDlg,IDC_CHEAT_OPTIONS,EM_GETLINE,(WPARAM)linecount,(LPARAM)(LPCSTR)str);
		str[len]=0;
		if (len>0) {
			switch (codeformat) {
			case 1: //option=lower byte
				if (len>=2) {
					for (i=0;i<2;i++) {
						if (!(((str[i]>='a')&&(str[i]<='f'))||((str[i]>='A')&&(str[i]<='F'))||((str[i]>='0')&&(str[i]<='9')))) {
							validoptions=FALSE;
							break;
						}
					}
					if ((str[2]!=' ')&&(len>2)) {
						validoptions=FALSE;
						break;
					}
					for (j=0;j<2;j++) {
						str[j]=toupper(str[j]);
					}
					strcat(optionsstring,",$");
					strcat(optionsstring,str);
					numoptions++;
				} else validoptions=FALSE;
				break;
			case 2: //option=word
				if (len>=4) {
					for (i=0;i<4;i++) {
						if (!(((str[i]>='a')&&(str[i]<='f'))||((str[i]>='A')&&(str[i]<='F'))||((str[i]>='0')&&(str[i]<='9')))) {
							validoptions=FALSE;
							break;
						}
					}
					if (str[4]!=' '&&(len>4)) {
						validoptions=FALSE;
						break;
					}
					for (j=0;j<4;j++) {
						str[j]=toupper(str[j]);
					}
					strcat(optionsstring,",$");
					strcat(optionsstring,str);
					numoptions++;
				} else validoptions=FALSE;
				break;
			}
		}
	}
	if (numoptions<1) validoptions=FALSE;
}
int _TreeView_GetCheckState(HWND hwndTreeView,HTREEITEM hItem) {
	TVITEM tvItem;
	// Prepare to receive the desired information.
	tvItem.mask=TVIF_HANDLE|TVIF_STATE;
	tvItem.hItem=hItem;
	tvItem.stateMask=TVIS_STATEIMAGEMASK;
	// Request the information.
	TreeView_GetItem(hwndTreeView,&tvItem);
	// Return zero if it's not checked,or nonzero otherwise.
	switch (tvItem.state>>12) {
	case 1: return TV_STATE_CHECKED;
	case 2: return TV_STATE_CLEAR;
	case 3: return TV_STATE_INDETERMINATE;
	}
	return ((int)(tvItem.state>>12)-1);
}
BOOL _TreeView_SetCheckState(HWND hwndTreeView,HTREEITEM hItem,int state) {
	TVITEM tvItem;
	tvItem.mask=TVIF_HANDLE|TVIF_STATE;
	tvItem.hItem=hItem;
	tvItem.stateMask=TVIS_STATEIMAGEMASK;
	/*Image 1 in the tree-view check box image list is the
	unchecked box. Image 2 is the checked box.*/
	switch (state) {
	case TV_STATE_CHECKED: tvItem.state=INDEXTOSTATEIMAGEMASK(1); break;
	case TV_STATE_CLEAR: tvItem.state=INDEXTOSTATEIMAGEMASK(2); break;
	case TV_STATE_INDETERMINATE: tvItem.state=INDEXTOSTATEIMAGEMASK(3); break;
	default: tvItem.state=INDEXTOSTATEIMAGEMASK(0); break;
	}
	return TreeView_SetItem(hwndTreeView,&tvItem);
}
void AddCodeLayers (int CheatNumber,char*CheatName,HTREEITEM hParent,BOOL CheatActive) {
	char Text[500],Item[500];
	TV_INSERTSTRUCT tv;
	//Work out text to add
	strcpy(Text,CheatName);
	if (strchr(Text,'\\')>0) {*strchr(Text,'\\')=0;}
	//See if text is already added
	tv.item.mask     =TVIF_TEXT;
	tv.item.pszText  =Item;
	tv.item.cchTextMax=sizeof(Item);
	tv.item.hItem    =TreeView_GetChild(hCheatTree,hParent);
	while (tv.item.hItem) {
		TreeView_GetItem(hCheatTree,&tv.item);
		if (strcmp(Text,Item)==0) {
			//If already exists then just use existing one
			int State=_TreeView_GetCheckState(hCheatTree,tv.item.hItem);
			if ((CheatActive&&State==TV_STATE_CLEAR)||(!CheatActive&&State==TV_STATE_CHECKED)) {
				_TreeView_SetCheckState(hCheatTree,tv.item.hItem,TV_STATE_INDETERMINATE);
			}
			AddCodeLayers(CheatNumber,CheatName+strlen(Text)+1,tv.item.hItem,CheatActive);
			return;
		}
		tv.item.hItem=TreeView_GetNextSibling(hCheatTree,tv.item.hItem);
	}
	//Add to dialog
	tv.hInsertAfter=TVI_SORT;
	tv.item.mask  =TVIF_TEXT|TVIF_PARAM;
	tv.item.pszText=Text;
	tv.item.lParam=CheatNumber;
	tv.hParent    =hParent;
	hParent=TreeView_InsertItem(hCheatTree,&tv);
	_TreeView_SetCheckState(hCheatTree,hParent,CheatActive?TV_STATE_CHECKED:TV_STATE_CLEAR);
	if (strcmp(Text,CheatName)==0) return;
	AddCodeLayers(CheatNumber,CheatName+strlen(Text)+1,hParent,CheatActive);
}
void RefreshCheatManager() {
	char CheatName[300];
	BOOL IsCheatActive;
	DWORD count;
	if (hManageWindow==0) return;
	TreeView_DeleteAllItems(hCheatTree);
	for (count=0;;count++) {
		if (!GetCheatName(count,CheatName,sizeof(CheatName))) {break;}
		IsCheatActive=CheatActive (CheatName);
		AddCheatExtension(count,CheatName,sizeof(CheatName));
		AddCodeLayers(count,CheatName,TVI_ROOT,IsCheatActive);
	}
}
LRESULT CALLBACK CheatAddProc (HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam) {
	char str[1024];
	switch (uMsg) {
	case WM_INITDIALOG:
		SetWindowText(hDlg,"Add Cheat");
		SetWindowText(GetDlgItem(hDlg,IDC_NAME),"Name:");
		SetWindowText(GetDlgItem(hDlg,IDC_CODE),"Code:");
		SetWindowText(GetDlgItem(hDlg,IDC_LABEL_OPTIONS),"Options:");
		SetWindowText(GetDlgItem(hDlg,IDC_CODE_DES),"<address> <value>");
		SetWindowText(GetDlgItem(hDlg,IDC_LABEL_OPTIONS_FORMAT),"<value> <label>");
		SetWindowText(GetDlgItem(hDlg,IDC_CHEATNOTES)," Cheat Notes: ");
		SetWindowText(GetDlgItem(hDlg,IDC_NEWCHEAT),"Clear All");
		SetWindowText(GetDlgItem(hDlg,IDC_ADD),"Add Cheat");
		validcodes=FALSE;
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case IDCANCEL:
			EndDialog(hDlg,0);
			break;
		case IDC_CODE_NAME:
			if (HIWORD(wParam)==EN_CHANGE) {
				if (validcodes&&(validoptions||nooptions)&&SendDlgItemMessage(hDlg,IDC_CODE_NAME,EM_LINELENGTH,0,0)>0) EnableWindow(GetDlgItem(hDlg,IDC_ADD),TRUE);
				else EnableWindow(GetDlgItem(hDlg,IDC_ADD),FALSE);
			}
			break;
		case IDC_CHEAT_CODES:
			if (HIWORD(wParam)==EN_CHANGE) {
				ReadCodeString(hDlg);
				GetDlgItemText(hDlg,IDC_CHEAT_CODES,str,1024);
				if ((codeformat>0)&&!IsWindowEnabled(GetDlgItem(hDlg,IDC_LABEL_OPTIONS))) {
					EnableWindow(GetDlgItem(hDlg,IDC_LABEL_OPTIONS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_LABEL_OPTIONS_FORMAT),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHEAT_OPTIONS),TRUE);
				}
				if ((codeformat<=0)&&IsWindowEnabled(GetDlgItem(hDlg,IDC_LABEL_OPTIONS))) {
					EnableWindow(GetDlgItem(hDlg,IDC_LABEL_OPTIONS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_LABEL_OPTIONS_FORMAT),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHEAT_OPTIONS),FALSE);
				}
				if (!nooptions) ReadOptionsString(hDlg);
				if (validcodes&&(validoptions||nooptions)&&SendDlgItemMessage(hDlg,IDC_CODE_NAME,EM_LINELENGTH,0,0)>0) EnableWindow(GetDlgItem(hDlg,IDC_ADD),TRUE);
				else EnableWindow(GetDlgItem(hDlg,IDC_ADD),FALSE);
			}
			break;
		case IDC_CHEAT_OPTIONS:
			if (HIWORD(wParam)==EN_CHANGE) {
				ReadOptionsString(hDlg);
				if (validcodes&&(validoptions||nooptions)&&SendDlgItemMessage(hDlg,IDC_CODE_NAME,EM_LINELENGTH,0,0)>0) EnableWindow(GetDlgItem(hDlg,IDC_ADD),TRUE);
				else EnableWindow(GetDlgItem(hDlg,IDC_ADD),FALSE);
			}
			break;
		case IDC_ADD:
			{
				char Identifier[100],CheatName[300],NewCheatName[300],*cheat;
				int CheatLen,count,CheatNo;
				LPSTR IniFileName;
				GetDlgItemText(hDlg,IDC_CODE_NAME,NewCheatName,sizeof(NewCheatName));
				for (count=0;;count++) {
					GetCheatName(count,CheatName,sizeof(CheatName));
					if (strlen(CheatName)==0) {
						CheatNo=count;
						break;
					}
					if (strcmp(CheatName,NewCheatName)==0) {
						DisplayError("Cheat name is currently in use");
						SetFocus(GetDlgItem(hDlg,IDC_CODE_NAME));
						return TRUE;
					}
				}
				CheatLen=strlen(NewCheatName)+strlen(codestring);
				cheat=malloc(CheatLen+3);
				sprintf(cheat,"\"%s\"",NewCheatName);
				strcat(cheat,codestring);
				//Add to ini
				IniFileName=GetCheatIniFileName();
				sprintf(Identifier,"%08X-%08X-C:%X",*(DWORD*)(&RomHeader[0x10]),*(DWORD*)(&RomHeader[0x14]),RomHeader[0x3D]);
				sprintf(NewCheatName,"Cheat%d",CheatNo);
				_WritePrivateProfileString(Identifier,NewCheatName,cheat,IniFileName);
				if (cheat) {free(cheat);cheat=0;}
				if (validoptions) {
					cheat=malloc(strlen(optionsstring)+1);
					strcpy(cheat,optionsstring+1);
					sprintf(NewCheatName,"Cheat%d_O",CheatNo);
					_WritePrivateProfileString(Identifier,NewCheatName,cheat,IniFileName);
					if (cheat) {free(cheat);cheat=0;}
				}
				CheatLen=SendDlgItemMessage(hDlg,IDC_NOTES,WM_GETTEXTLENGTH,0,0)+5;
				if (CheatLen>5) {
					cheat=malloc(CheatLen);
					GetDlgItemText(hDlg,IDC_NOTES,cheat,CheatLen);
					sprintf(NewCheatName,"Cheat%d_N",CheatNo);
					_WritePrivateProfileString(Identifier,NewCheatName,cheat,IniFileName);
					if (cheat) {free(cheat);cheat=0;}
				}
				RefreshCheatManager();
				SetDlgItemText(hDlg,IDC_CODE_NAME,"");
				SetDlgItemText(hDlg,IDC_CHEAT_CODES,"");
				SetDlgItemText(hDlg,IDC_CHEAT_OPTIONS,"");
				SetDlgItemText(hDlg,IDC_NOTES,"");
				EnableWindow(GetDlgItem(hDlg,IDC_ADD),FALSE);
			}
			EndDialog(hDlg,0);
			break;
		case IDC_NEWCHEAT:
			{
				SetDlgItemText(hDlg,IDC_CODE_NAME,"");
				SetDlgItemText(hDlg,IDC_CHEAT_CODES,"");
				SetDlgItemText(hDlg,IDC_CHEAT_OPTIONS,"");
				SetDlgItemText(hDlg,IDC_NOTES,"");
				EnableWindow(GetDlgItem(hDlg,IDC_ADD),FALSE);
			}
		}
		break;
	default:
		return FALSE;
	}
	return TRUE;
}
LRESULT CALLBACK CheatEditProc (HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam) {
	static int CheatNo;
	switch (uMsg) {
	case WM_INITDIALOG:
		SetWindowText(hDlg,"Edit Cheat");
		SetWindowText(GetDlgItem(hDlg,IDC_NAME),"Name:");
		SetWindowText(GetDlgItem(hDlg,IDC_CODE),"Code:");
		SetWindowText(GetDlgItem(hDlg,IDC_LABEL_OPTIONS),"Options:");
		SetWindowText(GetDlgItem(hDlg,IDC_CODE_DES),"<address> <value>");
		SetWindowText(GetDlgItem(hDlg,IDC_LABEL_OPTIONS_FORMAT),"<value> <label>");
		SetWindowText(GetDlgItem(hDlg,IDC_CHEATNOTES)," Cheat Notes: ");
		SetWindowText(GetDlgItem(hDlg,IDC_ADD),"Update Cheat");
		{
			char*String=0,*ReadPos,*Buffer,Identifier[100],CheatName[300];
			LPSTR IniFileName;
			TVITEM item;
			int len;
			item.mask=TVIF_PARAM ;
			item.hItem=(HTREEITEM)lParam;
			TreeView_GetItem(hCheatTree,&item);
			CheatNo=item.lParam;
			IniFileName=GetCheatIniFileName();
			//Get Main cheat Entry
			sprintf(Identifier,"%08X-%08X-C:%X",*(DWORD*)(&RomHeader[0x10]),*(DWORD*)(&RomHeader[0x14]),RomHeader[0x3D]);
			sprintf(CheatName,"Cheat%d",CheatNo);
			_GetPrivateProfileString2(Identifier,CheatName,"",&String,IniFileName);
			//Set Cheat Name
			len=strrchr(String,'"')-strchr(String,'"')-1;
			memset(CheatName,0,sizeof(CheatName));
			strncpy(CheatName,strchr(String,'"')+1,len);
			SetDlgItemText(hDlg,IDC_CODE_NAME,CheatName);
			//Add Gameshark codes to screen
			ReadPos=strrchr(String,'"')+2;
			Buffer=malloc(strlen(ReadPos)+MaxGSEntries);
			strcpy(Buffer,"");
			do {
				strncat(Buffer,ReadPos,strchr(ReadPos,',')-ReadPos);
				ReadPos=strchr(ReadPos,',');
				if (ReadPos!=0) {
					strcat(Buffer,"\r\n");
					ReadPos+=1;
				}
			} while (ReadPos);
			SetDlgItemText(hDlg,IDC_CHEAT_CODES,Buffer);
			if (Buffer) {free(Buffer); Buffer=0;}
			if (String) {free(String); String=0;}
			//Add option values to screen
			sprintf(CheatName,"Cheat%d_O",item.lParam);
			_GetPrivateProfileString2(Identifier,CheatName,"",&String,IniFileName);
			if (strlen(String)>0) {
				ReadPos=strchr(String,'$')+1;
				Buffer=malloc(strlen(ReadPos)+2);
				strcpy(Buffer,"");
				do {
					strncat(Buffer,ReadPos,strchr(ReadPos,',')-ReadPos);
					ReadPos=strchr(ReadPos,'$');
					if (ReadPos!=0) {
						strcat(Buffer,"\r\n");
						ReadPos+=1;
					}
				} while (ReadPos);
				SetDlgItemText(hDlg,IDC_CHEAT_OPTIONS,Buffer);
			}
			if (Buffer) {free(Buffer);Buffer=0;}
			if (String) {free(String);String=0;}
			//Add cheat Notes
			sprintf(CheatName,"Cheat%d_N",item.lParam);
			_GetPrivateProfileString2(Identifier,CheatName,"",&String,IniFileName);
			SetDlgItemText(hDlg,IDC_NOTES,String);
			if (String) {free(String);String=0;}
			//Update Screen
			PostMessage(hDlg,WM_COMMAND,MAKEWPARAM(IDC_CHEAT_CODES,EN_CHANGE),(LPARAM)GetDlgItem(hDlg,IDC_CHEAT_CODES));
		}
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case IDCANCEL:
			EndDialog(hDlg,0);
			break;
		case IDC_CODE_NAME:
			if (HIWORD(wParam)==EN_CHANGE) {
				if (validcodes&&(validoptions||nooptions)&&SendDlgItemMessage(hDlg,IDC_CODE_NAME,EM_LINELENGTH,0,0)>0) EnableWindow(GetDlgItem(hDlg,IDC_ADD),TRUE);
				else EnableWindow(GetDlgItem(hDlg,IDC_ADD),FALSE);
			}
			break;
		case IDC_CHEAT_CODES:
			if (HIWORD(wParam)==EN_CHANGE) {
				ReadCodeString(hDlg);
				if ((codeformat>0)&&!IsWindowEnabled(GetDlgItem(hDlg,IDC_LABEL_OPTIONS))) {
					EnableWindow(GetDlgItem(hDlg,IDC_LABEL_OPTIONS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_LABEL_OPTIONS_FORMAT),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHEAT_OPTIONS),TRUE);
				}
				if ((codeformat<=0)&&IsWindowEnabled(GetDlgItem(hDlg,IDC_LABEL_OPTIONS))) {
					EnableWindow(GetDlgItem(hDlg,IDC_LABEL_OPTIONS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_LABEL_OPTIONS_FORMAT),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHEAT_OPTIONS),FALSE);
				}
				if (!nooptions) ReadOptionsString(hDlg);
				if (validcodes&&(validoptions||nooptions)&&SendDlgItemMessage(hDlg,IDC_CODE_NAME,EM_LINELENGTH,0,0)>0) EnableWindow(GetDlgItem(hDlg,IDC_ADD),TRUE);
				else EnableWindow(GetDlgItem(hDlg,IDC_ADD),FALSE);
			}
			break;
		case IDC_CHEAT_OPTIONS:
			if (HIWORD(wParam)==EN_CHANGE) {
				ReadOptionsString(hDlg);
				if (validcodes&&(validoptions||nooptions)&&SendDlgItemMessage(hDlg,IDC_CODE_NAME,EM_LINELENGTH,0,0)>0) {
					EnableWindow(GetDlgItem(hDlg,IDC_ADD),TRUE);
				} else {
					EnableWindow(GetDlgItem(hDlg,IDC_ADD),FALSE);
				}
			}
			break;
		case IDC_ADD:
			{
				char Identifier[100],Key[100],*Ext[]={"","_N","_O","_R"};
				char NewCheatName[300],*cheat;
				int CheatLen,type;
				LPSTR IniFileName;
				IniFileName=GetCheatIniFileName();
				sprintf(Identifier,"%08X-%08X-C:%X",*(DWORD*)(&RomHeader[0x10]),*(DWORD*)(&RomHeader[0x14]),RomHeader[0x3D]);
				//Delete old Entries
				for (type=0;type<(sizeof(Ext) / sizeof(char*));type++) {
					sprintf(Key,"Cheat%d%s",CheatNo,Ext[type]);
					_DeletePrivateProfileString(Identifier,Key,IniFileName);
				}
				//Insert New Entries
				GetDlgItemText(hDlg,IDC_CODE_NAME,NewCheatName,sizeof(NewCheatName));
				CheatLen=strlen(NewCheatName)+strlen(codestring);
				cheat=malloc(CheatLen+3);
				sprintf(cheat,"\"%s\"",NewCheatName);
				strcat(cheat,codestring);
				//Add to ini
				sprintf(NewCheatName,"Cheat%d",CheatNo);
				_WritePrivateProfileString(Identifier,NewCheatName,cheat,IniFileName);
				if (cheat) {free(cheat);cheat=0;}
				if (validoptions) {
					cheat=malloc(strlen(optionsstring)+1);
					strcpy(cheat,optionsstring+1);
					sprintf(NewCheatName,"Cheat%d_O",CheatNo);
					_WritePrivateProfileString(Identifier,NewCheatName,cheat,IniFileName);
					if (cheat) {free(cheat);cheat=0;}
				}
				CheatLen=SendDlgItemMessage(hDlg,IDC_NOTES,WM_GETTEXTLENGTH,0,0)+5;
				if (CheatLen>5) {
					cheat=malloc(CheatLen);
					GetDlgItemText(hDlg,IDC_NOTES,cheat,CheatLen);
					sprintf(NewCheatName,"Cheat%d_N",CheatNo);
					_WritePrivateProfileString(Identifier,NewCheatName,cheat,IniFileName);
					if (cheat) {free(cheat);cheat=0;}
				}
				LoadCheats();
				RefreshCheatManager();
				EndDialog(hDlg,0);
			}
		}
		break;
	default:
		return FALSE;
	}
	return TRUE;
}
void ChangeChildrenStatus(HTREEITEM hParent,BOOL Checked) {
	HTREEITEM hItem=TreeView_GetChild(hCheatTree,hParent);
	if (hItem==0) {
		//Save Cheat
		char CheatName[300];
		TVITEM item;
		if (hParent==TVI_ROOT) return;
		item.mask=TVIF_PARAM ;
		item.hItem=hParent;
		TreeView_GetItem(hCheatTree,&item);
		GetCheatName(item.lParam,CheatName,sizeof(CheatName));
		SaveCheat(CheatName,Checked);
		return;
	}
	while (hItem!=0) {
		ChangeChildrenStatus(hItem,Checked);
		_TreeView_SetCheckState(hCheatTree,hItem,Checked?TV_STATE_CHECKED:TV_STATE_CLEAR);
		hItem=TreeView_GetNextSibling(hCheatTree,hItem);
	}
}
void CheckParentStatus(HTREEITEM hParent) {
	int CurrentState,InitialState;
	HTREEITEM hItem;
	if (!hParent) return;
	hItem=TreeView_GetChild(hCheatTree,hParent);
	InitialState=_TreeView_GetCheckState(hCheatTree,hParent);
	CurrentState=_TreeView_GetCheckState(hCheatTree,hItem);
	while (hItem!=0) {
		if (_TreeView_GetCheckState(hCheatTree,hItem)!=CurrentState) {
			CurrentState=TV_STATE_INDETERMINATE;
			break;
		}
		hItem=TreeView_GetNextSibling(hCheatTree,hItem);
	}
	_TreeView_SetCheckState(hCheatTree,hParent,CurrentState);
	if (InitialState!=CurrentState) {
		CheckParentStatus(TreeView_GetParent(hCheatTree,hParent));
	}
}
void DeleteCheat(int CheatNo) {
	char Identifier[100],Key[100],*Ext[]={"","_N","_O","_R"},*Input=0,*Data=0,*Pos=0,CurrentSection[300];
	LPSTR IniFileName;
	int type,DataLen=0,DataLeft,result,count;
	long WritePos;
	FILE*fInput;
#ifdef WIN32
	char*LineFeed="\r\n";
#else
	char*LineFeed="\n";
#endif
	IniFileName=GetCheatIniFileName();
	sprintf(Identifier,"%08X-%08X-C:%X",*(DWORD*)(&RomHeader[0x10]),*(DWORD*)(&RomHeader[0x14]),RomHeader[0x3D]);
	for (type=0;type<(sizeof(Ext) / sizeof(char*));type++) {
		sprintf(Key,"Cheat%d%s",CheatNo,Ext[type]);
		_DeletePrivateProfileString(Identifier,Key,IniFileName);
	}
	fInput=fopen(IniFileName,"r+b");
	if (fInput==0) {
		fInput=fopen(IniFileName,"w+b");
		if (IniFileName==0) return;
	}
	CurrentSection[0]=0;
	do {
		result=fGetString2(fInput,&Input,&Data,&DataLen,&DataLeft);
		if (result<=1) continue;
		Pos=Input;
		while (Pos!=0) {
			Pos=strchr(Pos,'/');
			if (Pos!=0) {
				if (Pos[1]=='/') {Pos[0]=0;} else {Pos+=1;}
			}
		}
		for (count=strlen(&Input[0])-1;count>=0;count--) {
			if (Input[count]!=' '&&Input[count]!='\r') {break;}
			Input[count]=0;
		}
		//stip leading spaces
		if (strlen(Input)<=1) continue;
		if (Input[0]=='[') {
			if (Input[strlen(Input)-1]!=']') continue;
			if (strcmp(Identifier,CurrentSection)==0) {
				result=-1;
				continue;
			}
			strcpy(CurrentSection,&Input[1]);
			CurrentSection[strlen(CurrentSection)-1]=0;
			WritePos=ftell(fInput)-DataLeft;
			continue;
		}
		if (strcmp(Identifier,CurrentSection)!=0) {
			continue;
		}
		Pos=strchr(Input,'=');
		if (Pos==0) continue;
		if (strncmp(Input,"Cheat",5)!=0) {
			WritePos=ftell(fInput)-DataLeft;
			continue;
		}
		if (atoi(&Input[5])<CheatNo) {
			WritePos=ftell(fInput)-DataLeft;
			continue;
		}
		if (strchr(Input,'_')>0&&strchr(Input,'_')<Pos) {Pos=strchr(Input,'_');}
		{
			long OldLen=strlen(Input)+strlen(LineFeed),CurrentPos=ftell(fInput);
			int Newlen=strlen(Pos)+strlen(LineFeed);
			char Header[100];
			sprintf(Header,"Cheat%d",atoi(&Input[5])-1);
			Newlen+=strlen(Header);
			if (OldLen!=Newlen) CurrentPos+=Newlen-OldLen;
			fseek(fInput,WritePos,SEEK_SET);
			fprintf(fInput,"%s%s%s",Header,Pos,LineFeed);
			fflush(fInput);
			fseek(fInput,CurrentPos,SEEK_SET);
		}
		WritePos=ftell(fInput)-DataLeft;
	} while (result>=0);
	fclose(fInput);
	if (Input) {free(Input);Input=0;}
	if (Data) {free(Data); Data=0;}
}
LRESULT CALLBACK CheatListProc (HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam) {
	static HTREEITEM hSelectedItem;
	switch (uMsg) {
	case WM_INITDIALOG:
		{
			DWORD Style;
			RECT rcList;
			RECT rcButton;
			SetWindowText(GetDlgItem(hDlg,IDC_CHEATSFRAME),"Cheats:");
			SetWindowText(GetDlgItem(hDlg,IDC_NOTESFRAME)," Notes: ");
			SetWindowText(GetDlgItem(hDlg,IDC_UNMARK),"Unmark All");
			GetWindowRect(GetDlgItem(hDlg,IDC_CHEATSFRAME),&rcList);
			GetWindowRect(GetDlgItem(hDlg,IDC_UNMARK),&rcButton);
			hCheatTree=CreateWindowEx(WS_EX_CLIENTEDGE,WC_TREEVIEW,"",WS_CHILD|WS_BORDER|WS_VISIBLE|WS_VSCROLL|TVS_HASLINES|TVS_HASBUTTONS|TVS_LINESATROOT|TVS_DISABLEDRAGDROP|WS_TABSTOP|TVS_FULLROWSELECT,8,15,rcList.right-rcList.left-16,rcButton.top-rcList.top-22,hDlg,(HMENU)IDC_MYTREE,hInst,0);
			Style=GetWindowLong(hCheatTree,GWL_STYLE);
			SetWindowLong(hCheatTree,GWL_STYLE,TVS_CHECKBOXES|TVS_SHOWSELALWAYS|Style);
			{
				HIMAGELIST hImageList;
				HBITMAP hBmp;
				hImageList=ImageList_Create(16,16,ILC_COLOR|ILC_MASK,40,40);
				hBmp=LoadBitmap(hInst,MAKEINTRESOURCE(IDB_BITMAP1));
				ImageList_AddMasked(hImageList,hBmp,RGB(255,0,255));
				DeleteObject(hBmp);
				TreeView_SetImageList(hCheatTree,hImageList,TVSIL_STATE);
			}
			hSelectedItem=0;
		}
		break;
	case WM_SIZE:
		{
			int nWidth=LOWORD(lParam),nHeight=HIWORD(lParam);
			SetWindowPos(GetDlgItem(hDlg,IDC_CHEATSFRAME),0,0,0,nWidth,nHeight-100,SWP_NOOWNERZORDER);
			SetWindowPos(GetDlgItem(hDlg,IDC_NOTESFRAME),0,0,nHeight-96,nWidth,95,SWP_NOOWNERZORDER);
			SetWindowPos(GetDlgItem(hDlg,IDC_NOTES),0,6,nHeight-80,nWidth-12,72,SWP_NOOWNERZORDER);
			SetWindowPos(GetDlgItem(hDlg,IDC_UNMARK),0,nWidth-110,nHeight-124,0,0,SWP_NOSIZE|SWP_NOOWNERZORDER);
			SetWindowPos(GetDlgItem(hDlg,IDC_DELETE),0,nWidth-165,nHeight-124,0,0,SWP_NOSIZE|SWP_NOOWNERZORDER);
			SetWindowPos(hCheatTree,0,0,0,nWidth-13,nHeight-142,SWP_NOMOVE|SWP_NOOWNERZORDER);
		}
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case ID_POPUP_ADDNEWCHEAT:
			DialogBox(hInst,MAKEINTRESOURCE(IDD_Cheats_Add),hDlg,(DLGPROC)CheatAddProc);
			break;
		case ID_POPUP_EDIT:
			DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_Cheats_Edit),hDlg,(DLGPROC)CheatEditProc,(LPARAM)hSelectedItem);
			break;
		case ID_POPUP_DELETE:
			{
				TVITEM item;
				item.hItem=hSelectedItem;
				item.mask=TVIF_PARAM ;
				TreeView_GetItem(hCheatTree,&item);
				DeleteCheat(item.lParam);
				RefreshCheatManager();
			}
			break;
		case IDC_UNMARK:
			ChangeChildrenStatus(TVI_ROOT,FALSE);
			LoadCheats();
		}
		break;
	case WM_NOTIFY:
		{
			LPNMHDR lpnmh=(LPNMHDR) lParam;
			if ((lpnmh->code==NM_RCLICK)&&(lpnmh->idFrom==IDC_MYTREE)) {
				TVHITTESTINFO ht={0};
				DWORD dwpos=GetMessagePos();
				ht.pt.x=GET_X_LPARAM(dwpos);
				ht.pt.y=GET_Y_LPARAM(dwpos);
				MapWindowPoints(HWND_DESKTOP,lpnmh->hwndFrom,&ht.pt,1);
				TreeView_HitTest(lpnmh->hwndFrom,&ht);
				hSelectedItem=ht.hItem;
				HMENU hMenu=LoadMenu(hInst,MAKEINTRESOURCE(IDR_CHEAT_MENU)),hPopupMenu=GetSubMenu(hMenu,0);
				POINT Mouse;
				GetCursorPos(&Mouse);
				MenuSetText(hPopupMenu,0,"Add Cheat",0);
				MenuSetText(hPopupMenu,1,"Edit Cheat",0);
				MenuSetText(hPopupMenu,3,"Delete Cheat",0);
				if (hSelectedItem==0||TreeView_GetChild(hCheatTree,hSelectedItem)!=0) {
					DeleteMenu(hPopupMenu,3,MF_BYPOSITION);
					DeleteMenu(hPopupMenu,2,MF_BYPOSITION);
					DeleteMenu(hPopupMenu,1,MF_BYPOSITION);
				}
				TrackPopupMenu(hPopupMenu,0,Mouse.x,Mouse.y,0,hDlg,0);
				DestroyMenu(hMenu);
		}
		   if ((lpnmh->code==NM_CLICK)&&(lpnmh->idFrom==IDC_MYTREE)) {
				TVHITTESTINFO ht={0};
				DWORD dwpos=GetMessagePos();
				ht.pt.x=GET_X_LPARAM(dwpos);
				ht.pt.y=GET_Y_LPARAM(dwpos);
				MapWindowPoints(HWND_DESKTOP,lpnmh->hwndFrom,&ht.pt,1);
				TreeView_HitTest(lpnmh->hwndFrom,&ht);
				if (TVHT_ONITEMSTATEICON&ht.flags) {
					switch (_TreeView_GetCheckState(hCheatTree,ht.hItem)) {
					case TV_STATE_CLEAR:
					case TV_STATE_INDETERMINATE:
						_TreeView_SetCheckState(hCheatTree,ht.hItem,TV_STATE_CHECKED);
						ChangeChildrenStatus(ht.hItem,TRUE);
						CheckParentStatus(TreeView_GetParent(hCheatTree,ht.hItem));
						_TreeView_SetCheckState(hCheatTree,ht.hItem,TV_STATE_INDETERMINATE);
						break;
					case TV_STATE_CHECKED:
						_TreeView_SetCheckState(hCheatTree,ht.hItem,TV_STATE_CLEAR);
						ChangeChildrenStatus(ht.hItem,FALSE);
						CheckParentStatus(TreeView_GetParent(hCheatTree,ht.hItem));
						_TreeView_SetCheckState(hCheatTree,ht.hItem,TV_STATE_CHECKED);
						break;
					}
					LoadCheats();
				}
			}
			if ((lpnmh->code==NM_DBLCLK)&&(lpnmh->idFrom==IDC_MYTREE)) {
				TVHITTESTINFO ht={0};
				DWORD dwpos=GetMessagePos();
				ht.pt.x=GET_X_LPARAM(dwpos);
				ht.pt.y=GET_Y_LPARAM(dwpos);
				MapWindowPoints(HWND_DESKTOP,lpnmh->hwndFrom,&ht.pt,1);
				TreeView_HitTest(lpnmh->hwndFrom,&ht);
				if (TVHT_ONITEMLABEL&ht.flags) PostMessage(hDlg,UM_CHANGECODEEXTENSION,0,(LPARAM)ht.hItem);
			}
			if ((lpnmh->code==TVN_SELCHANGED)&&(lpnmh->idFrom==IDC_MYTREE)) {
				HTREEITEM hItem;
				hItem=TreeView_GetSelection(hCheatTree);
				if (TreeView_GetChild(hCheatTree,hItem)==0) {
					char*String=0,Lookup[40],Identifier[100];
					LPSTR IniFileName;
					TVITEM item;
					item.mask=TVIF_PARAM;
					item.hItem=hItem;
					TreeView_GetItem(hCheatTree,&item);
					IniFileName=GetCheatIniFileName();
					sprintf(Identifier,"%08X-%08X-C:%X",*(DWORD*)(&RomHeader[0x10]),*(DWORD*)(&RomHeader[0x14]),RomHeader[0x3D]);
					sprintf(Lookup,"Cheat%d_N",item.lParam);
					_GetPrivateProfileString2(Identifier,Lookup,"",&String,IniFileName);
					SetDlgItemText(hDlg,IDC_NOTES,String);
					if (String) free(String);
				} else SetDlgItemText(hDlg,IDC_NOTES,"");
			}
		}
		break;
	case UM_CHANGECODEEXTENSION:
		{
			char Identifier[100],*String=0,CheatName[300],CheatExt[300];
			HTREEITEM hItemChanged=(HTREEITEM)lParam;
			LPSTR IniFileName;
			TVITEM item;
			item.mask=TVIF_PARAM ;
			item.hItem=hItemChanged;
			TreeView_GetItem(hCheatTree,&item);
			IniFileName=GetCheatIniFileName();
			sprintf(Identifier,"%08X-%08X-C:%X",*(DWORD*)(&RomHeader[0x10]),*(DWORD*)(&RomHeader[0x14]),RomHeader[0x3D]);
			sprintf(CheatName,"Cheat%d",item.lParam);
			_GetPrivateProfileString2(Identifier,CheatName,"",&String,IniFileName);
			if (!CheatUsesCodeExtensions(String)) {
				if (String) {free(String);}
				break;
			}
			sprintf(CheatName,"Cheat%d_O",item.lParam);
			_GetPrivateProfileString2(Identifier,CheatName,"",&String,IniFileName);
			if (strlen(String)>0) {
				DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_Cheats_CodeEx),hDlg,(DLGPROC)CheatsCodeExProc,item.lParam);
			}
			if (String) {free(String);}
			GetCheatName(item.lParam,CheatName,sizeof(CheatName));
			if (!LoadCheatExt(CheatName,CheatExt,sizeof(CheatExt))) {
				sprintf(CheatExt,"?");
			}
			item.mask=TVIF_PARAM|TVIF_TEXT;
			item.pszText=CheatName;
			item.cchTextMax=sizeof(CheatName);
			if (strrchr(CheatName,'\\')!=0) {
				strcpy(CheatName,strrchr(CheatName,'\\')+1);
			}
			sprintf(CheatName,"%s (=> %s)",CheatName,CheatExt);
			TreeView_SetItem(hCheatTree,&item);
		}
		break;
	default:
		return FALSE;
	}
	return TRUE;
}
void DisableAllCheats() {
	char CheatName[300];
	int count;
	for (count=0;;count++) {
		if (!GetCheatName(count,CheatName,sizeof(CheatName))) {break;}
		SaveCheat(CheatName,FALSE);
	}
}
char*GetCheatIniFileName() {
	char path_buffer[_MAX_PATH],drive[_MAX_DRIVE],dir[_MAX_DIR];
	char fname[_MAX_FNAME],ext[_MAX_EXT];
	static char IniFileName[_MAX_PATH];
	GetModuleFileName(0,path_buffer,sizeof(path_buffer));
	_splitpath(path_buffer,drive,dir,fname,ext);
	sprintf(IniFileName,"%s%sPJ64DB\\%s",drive,dir,CheatIniName);
	return IniFileName;
}
void CloseCheatWindow () {
	if (hManageWindow) SendMessage(hManageWindow,UM_CLOSE_CHEATS,0,0);
}
void LoadCode (LPSTR CheatName,LPSTR CheatString) {
	char*ReadPos=CheatString;
	int count2;
	if (NoOfCodes>=999) return; // Don't support more than 999 cheats
	for (count2=0;count2<MaxGSEntries;count2++) {
		char CheatExt[300];
		WORD Value;
		Codes[NoOfCodes].Code[count2].Command=AsciiToHex(ReadPos);
		if (strchr(ReadPos,' ')==0) {break;}
		ReadPos=strchr(ReadPos,' ')+1;
		if (strncmp(ReadPos,"????",4)==0) {
			if (LoadCheatExt(CheatName,CheatExt,sizeof(CheatExt))) {
				Value=CheatExt[0]=='$'?(WORD)AsciiToHex(&CheatExt[1]):(WORD)atol(CheatExt);
			} else {
				count2=0; break;
			}
			Codes[NoOfCodes].Code[count2].Value=Value;
		} else if (strncmp(ReadPos,"??",2)==0) {
			Codes[NoOfCodes].Code[count2].Value=(BYTE)(AsciiToHex(ReadPos));
			if (LoadCheatExt(CheatName,CheatExt,sizeof(CheatExt))) {
				Value=CheatExt[0]=='$'?(BYTE)AsciiToHex(&CheatExt[1]):(BYTE)atol(CheatExt);
			} else {
				count2=0; break;
			}
			Codes[NoOfCodes].Code[count2].Value+=(Value<<16);
		} else if (strncmp(&ReadPos[2],"??",2)==0) {
			Codes[NoOfCodes].Code[count2].Value=(WORD)(AsciiToHex(ReadPos)<<16);
			if (LoadCheatExt(CheatName,CheatExt,sizeof(CheatExt))) {
				Value=CheatExt[0]=='$'?(BYTE)AsciiToHex(&CheatExt[1]):(BYTE)atol(CheatExt);
			} else {
				count2=0; break;
			}
			Codes[NoOfCodes].Code[count2].Value+=Value;
		} else {
			Codes[NoOfCodes].Code[count2].Value=(WORD)AsciiToHex(ReadPos);
		}
		if (strchr(ReadPos,',')==0) continue;
		ReadPos=strchr(ReadPos,',')+1;
	}
	if (count2==0) return;
	if (count2<MaxGSEntries) {
		Codes[NoOfCodes].Code[count2].Command=0;
		Codes[NoOfCodes].Code[count2].Value=0;
	}
	NoOfCodes+=1;
}
void LoadPermCheats ()
{
	LPSTR IniFileName;
	char*String=0,Identifier[100],CheatName[300];
	int count;
	IniFileName=GetIniFileName();
	sprintf(Identifier,"%08X-%08X-C:%X",*(DWORD*)(&RomHeader[0x10]),*(DWORD*)(&RomHeader[0x14]),RomHeader[0x3D]);
	for (count=0;;count++) {
		sprintf(CheatName,"Cheat%d",count);
		_GetPrivateProfileString2(Identifier,CheatName,"",&String,IniFileName);
		if (strlen(String)==0) {break;}
		LoadCode (0,String);
	}
	if (String) {free(String);}
}
void LoadCheats () {
	DWORD len,count;
	LPSTR IniFileName;
	char*String=0;
	char Identifier[100],CheatName[300];
	IniFileName=GetCheatIniFileName();
	sprintf(Identifier,"%08X-%08X-C:%X",*(DWORD*)(&RomHeader[0x10]),*(DWORD*)(&RomHeader[0x14]),RomHeader[0x3D]);
	NoOfCodes=0;
	LoadPermCheats();
	for (count=0;;count++) {
		char*ReadPos;
		sprintf(CheatName,"Cheat%d",count);
		_GetPrivateProfileString2(Identifier,CheatName,"",&String,IniFileName);
		if (strlen(String)==0) {break;}
		if (strchr(String,'"')==0) continue;
		len=strrchr(String,'"')-strchr(String,'"')-1;
		if ((int)len<1) continue;
		memset(CheatName,0,sizeof(CheatName));
		strncpy(CheatName,strchr(String,'"')+1,len);
		if (strlen(CheatName)==0) continue;
		if (!CheatActive (CheatName)) continue;
		ReadPos=strrchr(String,'"')+2;
		LoadCode(CheatName,ReadPos);
	}
	if (String) {free(String);}
}
void ManageCheats (HWND hParent) {
	DWORD X,Y,WindowWidth,WindowHeight,Style;
	int screenHeight=GetSystemMetrics(SM_CYSCREEN),screenWidth=GetSystemMetrics(SM_CXSCREEN);
	double n;
	if (hManageWindow) {
		SetForegroundWindow(hManageWindow);
		return;
	}
	if (screenHeight>=1440&&screenWidth>=1920) n=2;
	else if (screenHeight>=1080&&screenWidth>=1440) n=1.5;
	else n=1;
	WindowWidth=(int)(315*n);
	WindowHeight=(int)(415*n);
  	X=(GetSystemMetrics(SM_CXSCREEN)-WindowWidth) / 2;
	Y=(GetSystemMetrics(SM_CYSCREEN)-WindowHeight) / 2;
	if (hParent) {Style=WS_SIZEBOX|WS_SYSMENU;}
	if (!hParent) {Style=WS_SIZEBOX|WS_SYSMENU|WS_MINIMIZEBOX;}
	hManageWindow=CreateWindow("PJ64.Cheats","Cheats",Style,X,Y,WindowWidth,WindowHeight,hParent,0,hInst,0);
	UsuallyonTopWindow(hManageWindow);
	RefreshCheatManager();
	ShowWindow(hManageWindow,SW_SHOW);
	if (hParent) {
		MSG msg;
		EnableWindow(hParent,FALSE);
		while (hManageWindow) {
			if (!GetMessage(&msg,0,0,0)) {
				DestroyWindow(hManageWindow);
				hManageWindow=0;
				PostMessage(msg.hwnd,msg.message,msg.wParam,msg.lParam);
				continue;
			}
			if (IsDialogMessage(hManageWindow,&msg)) continue;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		EnableWindow(hParent,TRUE);
		SetFocus(hParent);
	}
}
LRESULT CALLBACK Cheat_Proc(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam) {
	int screenHeight=GetSystemMetrics(SM_CYSCREEN),screenWidth=GetSystemMetrics(SM_CXSCREEN),MinWidth,nWidth=LOWORD(lParam),nHeight=HIWORD(lParam);
#define MinHeight 263
	if (screenHeight>=2160&&screenWidth>=2880) MinWidth=427;
	else if (screenHeight>=1440&&screenWidth>=1920) MinWidth=274;
	else MinWidth=220;
	switch (uMsg) {
	case WM_CREATE:
		hSelectCheat=CreateDialog(hInst,MAKEINTRESOURCE(IDD_Cheats_List),hWnd,(DLGPROC)CheatListProc);
		SetWindowPos(hSelectCheat,HWND_TOP,5,8,0,0,SWP_NOSIZE);
		ShowWindow(hSelectCheat,SW_SHOW);
		break;
	case WM_MOVE:
		if (IsIconic(hWnd)) {break;}
		break;
	case UM_CLOSE_CHEATS:
		DestroyWindow(hWnd);
		break;
	case WM_SIZING:
		{
			LPRECT lprc=(LPRECT) lParam;
			int fwSide=wParam;
			if ((lprc->bottom-lprc->top)<=MinHeight) {
				switch (fwSide) {
				case WMSZ_TOPLEFT:
				case WMSZ_TOP:
				case WMSZ_TOPRIGHT:
					lprc->top=lprc->bottom-MinHeight;
					break;
				case WMSZ_BOTTOMLEFT:
				case WMSZ_BOTTOM:
				case WMSZ_BOTTOMRIGHT:
					lprc->bottom=lprc->top+MinHeight;
					break;
				}
			}
			if ((lprc->right-lprc->left)<=MinWidth) {
				switch (fwSide) {
				case WMSZ_TOPLEFT:
				case WMSZ_LEFT:
				case WMSZ_BOTTOMLEFT:
					lprc->left=lprc->right-MinWidth;
					break;
				case WMSZ_TOPRIGHT:
				case WMSZ_RIGHT:
				case WMSZ_BOTTOMRIGHT:
					lprc->right=lprc->left+MinWidth;
					break;
				}
			}
		}
		break;
	case WM_SIZE:
		SetWindowPos(hSelectCheat,HWND_TOP,5,5,nWidth-8,nHeight-10,SWP_NOOWNERZORDER);
		break;
	case WM_DESTROY:
		hManageWindow=0;
		break;
	default:
		return DefWindowProc(hWnd,uMsg,wParam,lParam);
	}
	return TRUE;
}
LRESULT CALLBACK ManageCheatsProc (HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam) {
	static int CurrentPanel=SelectCheat;
	static RECT rcDisp,rcList,rcAdd;
	HANDLE hStateButton;
	switch (uMsg) {
	case WM_INITDIALOG:
		hManageWindow=hDlg;
		{
			WINDOWPLACEMENT WndPlac;
			RECT*rc;
			WndPlac.length=sizeof(WndPlac);
			GetWindowPlacement(hDlg,&WndPlac);
			rc=&WndPlac.rcNormalPosition;
			SetWindowText(hDlg,"Cheats");
			hSelectCheat=CreateDialog(hInst,MAKEINTRESOURCE(IDD_Cheats_List),hDlg,(DLGPROC)CheatListProc);
			SetWindowPos(hSelectCheat,HWND_TOP,5,8,0,0,SWP_NOSIZE);
			ShowWindow(hSelectCheat,SW_SHOW);
			hAddCheat=CreateDialog(hInst,MAKEINTRESOURCE(IDD_Cheats_Add),hDlg,(DLGPROC)CheatAddProc);
			SetWindowPos(hAddCheat,HWND_TOP,(rc->right-rc->left)/2,8,0,0,SWP_NOSIZE);
			ShowWindow(hAddCheat,SW_HIDE);
			GetWindowRect(GetDlgItem(hSelectCheat,IDC_CHEATSFRAME),&rcList);
			GetWindowRect(GetDlgItem(hAddCheat,IDC_ADDCHEATSFRAME),&rcAdd);
			MinSizeDlg=rcList.right-rcList.left+32;
			MaxSizeDlg=rcAdd.right-rcList.left+32;
			DialogState=CONTRACTED;
			WndPlac.rcNormalPosition.right=WndPlac.rcNormalPosition.left+MinSizeDlg;
			SetWindowPlacement(hDlg,&WndPlac);
			GetClientRect(hDlg,rc);
			hStateButton=GetDlgItem(hDlg,IDC_STATE);
			SetWindowPos(hStateButton,HWND_TOP,(rc->right-rc->left)-16,0,16,rc->bottom-rc->top,0);
		}
		hManageWindow=hDlg;
		RefreshCheatManager();
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case IDCANCEL:
			EndDialog(hDlg,0);
			DestroyWindow(hDlg);
		}
		break;
	case WM_DESTROY:
		hManageWindow=0;
		break;
	default:
		return FALSE;
	}
	return TRUE;
}