/*
*Project64 - A Nintendo 64 emulator.
*
*(c) Copyright 2001 zilmar (zilmar@emulation64.com) and
*Jabo (jabo@emulation64.com).
*
*pj64 homepage: www.pj64.net
*
*Permission to use, copy, modify and distribute Project64 in both binary and
*source form, for non-commercial purposes, is hereby granted without fee,
*providing that this license information and copyright notice appear with
*all copies and any derived work.
*
*This software is provided 'as-is', without any express or implied
*warranty. In no event shall the authors be held liable for any damages
*arising from the use of this software.
*
*Project64 is freeware for PERSONAL USE only. Commercial users should
*seek permission of the copyright holders first. Commercial use includes
*charging money for Project64 or software derived from Project64.
*
*The copyright holders request that bug fixes and improvements to the code
*should be forwarded to them so if they want them.
*
*/
#include "Interpreter CPU.h"
#include "Interpreter Ops.h"
#include "Recompiler CPU.h"
#include "Registers.h"
#include "Recompiler Ops.h"
#include "TLB.h"
#include "Memory.h"
#include "DMA.h"
#include "EEPROM.h"
#include "SRAM.h"
#include "FlashRAM.h"
#include "MemPak.h"
#include "Exception.h"
#include "PIF.h"
#include "Opcode.h"
#include "ROM.h"
typedef struct {
	HANDLE hStepping;
	BOOL DoSomething;
	BOOL CloseCPU;
	BOOL ChangeWindow;
	BOOL CheckInterrupts;
	BOOL Pause;
	BOOL SaveState;
	BOOL RestoreState;
	BOOL DoInterrupt;
	BOOL Stepping;
} CPU_ACTION;
#define InterruptsCD Call_Direct(CheckInterrupts);
#define SetEnd NextInstruction=END_BLOCK;
#define SetNormal NextInstruction=NORMAL;
#define SetJump NextInstruction=JUMP;
#define SetDelay NextInstruction=DELAY_SLOT;
#define MaxTimers	6
#define CompareTimer			0
#define SiTimer					1
#define PiTimer					2
#define ViTimer					3
#define RspTimer				4
#define AiTimer					5
typedef struct {
	int  NextTimer[MaxTimers];
	BOOL Active[MaxTimers];
	int  CurrentTimerType;
	int  Timer;
} SYSTEM_TIMERS;
void EmuAI_InitializePluginHook();
void EmuAI_SetFrameRate (int frameRate);
void ChangeTimer        (int Type,int Value);
void CheckTimer         ();
void EndEmulation       ();
int  DelaySlotEffectsCompare (DWORD PC,DWORD Reg1,DWORD Reg2);
int  DelaySlotEffectsJump (DWORD JumpPC);
void ChangeCompareTimer (void);
void DoSomething        (void);
void InPermLoop         (void);
void GetAutoSaveDir     (char*Directory);
void GetInstantSaveDir  (char*Directory);
void HandleEmulationCrash	(char*ExitPoint);
void INITIALIZECPUFlags ();
BOOL Machine_LoadState  ();
BOOL Machine_SaveState  ();
void PauseCPU           ();
void RefreshScreen      ();
void RunRsp             ();
void SetCoreToRunning   ();
void SetCoreToStepping  ();
void StepOpcode         ();
void TimerDone          (void);
#define NORMAL					0
#define DO_DELAY_SLOT			1
#define DO_END_DELAY_SLOT		2
#define DELAY_SLOT				3
#define END_DELAY_SLOT			4
#define LIKELY_DELAY_SLOT		5
#define JUMP	 				6
#define DELAY_SLOT_DONE			7
#define LIKELY_DELAY_SLOT_DONE	8
#define END_BLOCK 				9
enum SaveType {
	Default,
	EEPROM_4K,
	EEPROM_16K,
	SRAM,
	FlashRAM
};
extern int NextInstruction,JumpToLocation,ManualPaused,CPU_Paused,CountPerOp;
extern char SaveAsFileName[256],LoadFileName[256];
extern int DlistCount,AlistCount,CurrentSaveSlot;
extern enum SaveType SaveUsing;
extern CPU_ACTION CPU_Action;
extern SYSTEM_TIMERS Timers;
extern HANDLE hPauseMutex;
extern OPCODE Opcode;
extern HANDLE hCPU;
extern BOOL inFullScreen,CPURunning;
extern DWORD MemoryStack;