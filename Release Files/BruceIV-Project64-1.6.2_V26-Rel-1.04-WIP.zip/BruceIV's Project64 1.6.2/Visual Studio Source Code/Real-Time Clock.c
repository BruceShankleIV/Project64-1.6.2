#include <time.h>
#include <Windows.h>
#include "Main.h"
#include "CPU.h"
#include "Real-Time Clock.h"
// Supports the player setting a custom time.
// This will be negative if the time is lower than current, positive if higher than current.
__time64_t seconds_offset=0;
int first_load=TRUE;
BYTE INTtoBCD (int val) {
	val %=100;		// Conversion to 1 byte (8 bits) packed BCD supports 0 to 99 only.
	return ((val / 10)<<4)|(val % 10);
}
BYTE BCDtoBYTE (BYTE val) {
	val %=0x99;	// The maximum a BCD can store in 1 byte (8 bits).
	return val-((val&240)>>3)*3;
}
int RTC_Command (BYTE*Command) {
	switch(Command[2]) {
	case 6:	// Real-Time Clock status
		Command[3]=0;
		Command[4]=16;
		Command[5]=0;	// No error,0x80 would be busy and 0x01 and 0x02 would be failure
		break;
	case 7:	// Real-Time Clock read
		switch (Command[3]) {	// Block number
		case 0:
			Command[4]=0x00;	// Set blocks 1 and 2 to read-write?
			Command[5]=0x02;	// Timer is running
			Command[12]=0x00;	// No error
			break;
		case 2:
			{
				__time64_t rawtime;
				struct tm*timeinfo;
				if (first_load==TRUE) {
					ReadFromRTC();
					first_load=FALSE;
				}
				rawtime=time(0)-seconds_offset;
				timeinfo=_localtime64(&rawtime);
				Command[4]=INTtoBCD(timeinfo->tm_sec);
				Command[5]=INTtoBCD(timeinfo->tm_min);
				Command[6]=INTtoBCD(timeinfo->tm_hour)|0x80;
				Command[7]=INTtoBCD(timeinfo->tm_mday);
				Command[8]=INTtoBCD(timeinfo->tm_wday);
				Command[9]=INTtoBCD(timeinfo->tm_mon)+1;
				Command[10]=INTtoBCD(timeinfo->tm_year % 100);
				Command[11]=INTtoBCD(timeinfo->tm_year / 100);
				Command[12]=0;
			}
		}
		break;
	case 8:	// Real-Time Clock write
		if (Command[3]==2) {
			__time64_t rawtime=time(0);
			struct tm*timeinfo;
			timeinfo=localtime(&rawtime);
			timeinfo->tm_sec=BCDtoBYTE(Command[4]);
			timeinfo->tm_min=BCDtoBYTE(Command[5]);
			timeinfo->tm_hour=BCDtoBYTE(Command[6])+1;
			timeinfo->tm_mday=BCDtoBYTE(Command[7]);
			timeinfo->tm_wday=BCDtoBYTE(Command[8]);
			timeinfo->tm_mon=BCDtoBYTE(Command[9])-1;
			timeinfo->tm_year=BCDtoBYTE(Command[10])+BCDtoBYTE(Command[11])*100;
			seconds_offset=time(0)-_mktime64(timeinfo);
			WriteToRTC();
			Command[12]=0;
		}
		break;
	default:
		return FALSE;
	}
	return TRUE;
}
void ReadFromRTC() {
	FILE*fp;
	char File[256],Directory[256],String[100];
	GetAutoSaveDir(Directory);
	sprintf(File,"%s%s.rtc",Directory,RomName);
	fp=fopen(File,"r");
	if (fp!=0) {
		fscanf(fp,"%s",String);
		seconds_offset=_atoi64(String);
		fclose(fp);
	} else {
		seconds_offset=0;
	}
}
void WriteToRTC() {
	FILE*fp;
	char File[256],Directory[256],String[100];
	GetAutoSaveDir(Directory);
	sprintf(File,"%s%s.rtc",Directory,RomName);
	fp=fopen(File,"w");
	// No error checking, write to it if possible, otherwise don't bother.
	if (fp!=0) {
		_i64toa(seconds_offset,String,10);
		fprintf(fp,String);
		fclose(fp);
	}
}