/*
*Project64 - A Nintendo 64 emulator.
*
*(c) Copyright 2001 zilmar (zilmar@emulation64.com) and
*Jabo (jabo@emulation64.com).
*
*pj64 homepage: www.pj64.net
*
*Permission to use, copy, modify and distribute Project64 in both binary and
*source form, for non-commercial purposes, is hereby granted without fee,
*providing that this license information and copyright notice appear with
*all copies and any derived work.
*
*This software is provided 'as-is', without any express or implied
*warranty. In no event shall the authors be held liable for any damages
*arising from the use of this software.
*
*Project64 is freeware for PERSONAL USE only. Commercial users should
*seek permission of the copyright holders first. Commercial use includes
*charging money for Project64 or software derived from Project64.
*
*The copyright holders request that bug fixes and improvements to the code
*should be forwarded to them so if they want them.
*
*/
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <shlobj.h>
#include <stdio.h>
#include <shellapi.h>
#include <tlhelp32.h>
#include <tchar.h>
#include "Main.h"
#include "Settings.h"
#include "Cheat.h"
#include "CPU.h"
#include "Plugin.h"
#include "ROM.h"
#include "htmlHelp.h"
#include "Resource.h"
#include "SummerCart.h"
LARGE_INTEGER Frequency,Frames[9],LastFrame;
BOOL AutoSleep,AutoHide,CreateStatusBar,RecordRGB,Recursion,LimitFPS,SpeedCap,AutoFullScreen,SystemCF,UsuallyonTop,VideoToScreen,BasicMode,AutoRefreshRomBrowser,DelayHandlePluginsAndEmulationStartup=FALSE,FirstBoot=FALSE,UserCancelPluginInit=FALSE,RefreshRomBrowserOnShutdown=TRUE,FixFEDMAtoNonFEDMA,FixFDCPURtoNonFDCPUR,FixFDTLBtoNonFDTLB;
DWORD CurrentFrame,SystemUseCache,SystemProtectMemoryEnlargeBuffer,RomsToRemember,RomDirsToRemember;
HWND hMainWindow,hHiddenWindow,hStatusWnd,hRomList=0;
int cropHeight=0;
char CurrentSave[256];
HMENU hMainMenu;
HINSTANCE hInst;
LRESULT CALLBACK AboutIniBoxProc (HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam) {
	switch (uMsg) {
	case WM_INITDIALOG:
		{
			char*IniFile,String[256],String2[256];
			SetWindowText(hDlg,GS(MENU_ABOUT_INI));
			//Language.txt
			SetDlgItemText(hDlg,IDC_LAN,GS(INI_CURRENT_LANG));
			sprintf(String,"%s: %s",GS(INI_AUTHOR),GS(LANGUAGE_AUTHOR));
			SetDlgItemText(hDlg,IDC_LAN_AUTHOR,String);
			sprintf(String,"%s: %s",GS(INI_VERSION),GS(LANGUAGE_VERSION));
			SetDlgItemText(hDlg,IDC_LAN_VERSION,String);
			//Game.ini
			IniFile=GetIniFileName();
			SetDlgItemText(hDlg,IDC_GAME_INI,GS(INI_CURRENT_GAME_INI));
			_GetPrivateProfileString("Meta","Author","",String,sizeof(String),IniFile);
			if (strlen(String)==0) {
				EnableWindow(GetDlgItem(hDlg,IDC_GAME_INI),FALSE);
				EnableWindow(GetDlgItem(hDlg,IDC_GAME_INI_AUTHOR),FALSE);
				EnableWindow(GetDlgItem(hDlg,IDC_GAME_INI_VERSION),FALSE);
				EnableWindow(GetDlgItem(hDlg,IDC_GAME_INI_DATE),FALSE);
			}
			sprintf(String2,"%s: %s",GS(INI_AUTHOR),String);
			SetDlgItemText(hDlg,IDC_GAME_INI_AUTHOR,String2);
			_GetPrivateProfileString("Meta","Version","",String,sizeof(String),IniFile);
			sprintf(String2,"%s: %s",GS(INI_VERSION),String);
			SetDlgItemText(hDlg,IDC_GAME_INI_VERSION,String2);
			_GetPrivateProfileString("Meta","Date","",String,sizeof(String),IniFile);
			sprintf(String2,"%s: %s",GS(INI_DATE),String);
			SetDlgItemText(hDlg,IDC_GAME_INI_DATE,String2);
			//Cheat.ini
			SetDlgItemText(hDlg,IDC_CHEAT_INI,GS(INI_CURRENT_CHEAT_INI));
			IniFile=GetCheatIniFileName();
			_GetPrivateProfileString("Meta","Author","",String,sizeof(String),IniFile);
			if (strlen(String)==0) {
				EnableWindow(GetDlgItem(hDlg,IDC_CHEAT_INI),FALSE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHEAT_INI_AUTHOR),FALSE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHEAT_INI_VERSION),FALSE);
			}
			sprintf(String2,"%s: %s",GS(INI_AUTHOR),String);
			SetDlgItemText(hDlg,IDC_CHEAT_INI_AUTHOR,String2);
			_GetPrivateProfileString("Meta","Version","",String,sizeof(String),IniFile);
			sprintf(String2,"%s: %s",GS(INI_VERSION),String);
			SetDlgItemText(hDlg,IDC_CHEAT_INI_VERSION,String2);
			_GetPrivateProfileString("Meta","","",String,sizeof(String),IniFile);
		}
		break;
	case WM_COMMAND: {
			switch (LOWORD(wParam)) {
			case IDOK:
			case IDCANCEL:
				EndDialog(hDlg,0);
				break;
			}
	}
	default:
		return FALSE;
	}
	return TRUE;
}
LRESULT CALLBACK RomInfoProc (HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam) {
	char String[256],count;
	char drive[_MAX_DRIVE],dir[_MAX_DIR];
	char fname[_MAX_FNAME],ext[_MAX_EXT];
	switch (uMsg) {
	case WM_INITDIALOG:
		SetWindowText(hDlg,GS(INFO_TITLE));
		SetDlgItemText(hDlg,IDC_ROM_NAME,GS(RB_INTERNALNAME));
		SetDlgItemText(hDlg,IDC_FILE_NAME,GS(RB_FILENAME));
		SetDlgItemText(hDlg,IDC_LOCATION,GS(INFO_LOCATION_TEXT));
		SetDlgItemText(hDlg,IDC_ROM_SIZE,GS(RB_ROMSIZE));
		SetDlgItemText(hDlg,IDC_CART_ID,GS(RB_CART_ID));
		SetDlgItemText(hDlg,IDC_CRC1,GS(RB_CRC1));
		SetDlgItemText(hDlg,IDC_CRC2,GS(RB_CRC2));
		SetDlgItemText(hDlg,IDC_CIC_CHIP,GS(RB_CICCHIP));
		memcpy(&String[1],(void*)(&RomHeader[0x20]),20);
		for(count=1 ;count<21;count+=4) {
			String[count]^=String[count+3];
			String[count+3]^=String[count];
			String[count]^=String[count+3];
			String[count+1]^=String[count+2];
			String[count+2]^=String[count+1];
			String[count+1]^=String[count+2];
		}
		String[0]=' ';
		String[21]='\0';
		SetDlgItemText(hDlg,IDC_INFO_ROMNAME,String);
		_splitpath(CurrentFileName,drive,dir,fname,ext);
		strcpy(&String[1],fname);
		strcat(String,ext);
		SetDlgItemText(hDlg,IDC_INFO_FILENAME,String);
		strcpy(&String[1],drive);
		strcat(String,dir);
		SetDlgItemText(hDlg,IDC_INFO_LOCATION,String);
		sprintf(&String[1],"%.1f MBit",(float)RomFileSize/0x20000);
		SetDlgItemText(hDlg,IDC_INFO_ROMSIZE,String);
		String[1]=RomHeader[0x3F];
		String[2]=RomHeader[0x3E];
		String[3]='\0';
		SetDlgItemText(hDlg,IDC_INFO_CARTID,String);
		sprintf(&String[1],"0x%08X",*(DWORD*)(&RomHeader[0x10]));
		SetDlgItemText(hDlg,IDC_INFO_CRC1,String);
		sprintf(&String[1],"0x%08X",*(DWORD*)(&RomHeader[0x14]));
		SetDlgItemText(hDlg,IDC_INFO_CRC2,String);
		if (GetCicChipID(RomHeader)<0) sprintf(&String[1],GS(UNKNOWN));
		else {
			if (GetCicChipID(RomHeader)==4) sprintf(&String[1],"CIC-NUS-XENO");
			else if (GetCicChipID(RomHeader)==7) sprintf(&String[1],"CIC-NUS-5167");
			else if (GetCicChipID(RomHeader)==8) sprintf(&String[1],"CIC-NUS-8303");
			else if (GetCicChipID(RomHeader)==9) sprintf(&String[1],"CIC-NUS-DDUS");
			else sprintf(&String[1],"CIC-NUS-610%d",GetCicChipID(RomHeader));
		}
		SetDlgItemText(hDlg,IDC_INFO_CIC,String);
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case IDCANCEL:
			EndDialog(hDlg,0);
			break;
		}
	default:
		return FALSE;
	}
	return TRUE;
}
void RomInfo () {
	DialogBox(hInst,"ROM_INFO_DIALOG",hMainWindow,(DLGPROC)RomInfoProc);
}
void ShutdownApplication () {
	CloseCheatWindow();
	if (CPURunning) EndEmulation();
	if (TargetInfo!=0) VirtualFree(TargetInfo,0,MEM_RELEASE);
	SaveRomBrowserColumnInfo();
	FreeRomBrowser();
	ShutdownPlugins();
	SaveRecentFiles();
	Release_Memory();
	CoUninitialize();
}
int CALLBACK SelectRomDirCallBack (HWND hwnd,DWORD uMsg,DWORD lp,DWORD lpData) {
	if (uMsg==BFFM_INITIALIZED&&lpData) SendMessage((HWND)hwnd,BFFM_SETSELECTION,TRUE,lpData);
	return 0;
}
int ChooseN64RomToOpen () {
	OPENFILENAME openfilename;
	char FileName[256],Directory[256];
	memset(&FileName,0,sizeof(FileName));
	memset(&openfilename,0,sizeof(openfilename));
	GetRomDirectory(Directory);
	openfilename.lStructSize=sizeof(openfilename);
	openfilename.hwndOwner  =hMainWindow;
	openfilename.lpstrFilter="N64 ROMs (*.zip,*.z64,*.v64,*.n64)\0*.zip;*.z64;*.v64;*.n64\0All files (*.*)\0*.*\0";
	openfilename.lpstrFile  =FileName;
	openfilename.lpstrInitialDir  =Directory;
	openfilename.nMaxFile   =MAX_PATH;
	openfilename.Flags      =OFN_FILEMUSTEXIST|OFN_HIDEREADONLY;
	if (GetOpenFileName (&openfilename)) {
		strcpy(CurrentFileName,FileName);
		return TRUE;
	}
	return FALSE;
}
void AboutIniBox () {
	DialogBox(hInst,MAKEINTRESOURCE(IDD_About_Ini),hMainWindow,(DLGPROC)AboutIniBoxProc);
}
void UsuallyonTopWindow(HWND hWnd) {
	SetWindowPos(hWnd,(UsuallyonTop?HWND_TOPMOST:HWND_NOTOPMOST),0,0,0,0,SWP_NOMOVE|SWP_NOREPOSITION|SWP_NOSIZE);
}
DWORD AsciiToHex (char*HexValue) {
	DWORD Count,Finish,Value=0;
	Finish=strlen(HexValue);
	if (Finish>8) {Finish=8;}
	for (Count=0;Count<Finish;Count++) {
		Value=(Value<<4);
		switch(HexValue[Count]) {
		case '1': Value+=1; break;
		case '2': Value+=2; break;
		case '3': Value+=3; break;
		case '4': Value+=4; break;
		case '5': Value+=5; break;
		case '6': Value+=6; break;
		case '7': Value+=7; break;
		case '8': Value+=8; break;
		case '9': Value+=9; break;
		case 'A': case 'a': Value+=10; break;
		case 'B': case 'b': Value+=11; break;
		case 'C': case 'c': Value+=12; break;
		case 'D': case 'd': Value+=13; break;
		case 'E': case 'e': Value+=14; break;
		case 'F': case 'f': Value+=15;
		case '0': break;
		default:
			Value=(Value>>4);
			Count=Finish;
		}
	}
	return Value;
}
void ChangeWinSize (HWND hWnd,long width,long height,HWND hStatusBar) {
	WINDOWPLACEMENT wndpl;
	RECT rc1,swrect;
	wndpl.length=sizeof(wndpl);
	GetWindowPlacement(hWnd,&wndpl);
	if (hStatusBar!=0) {
		GetClientRect(hStatusBar,&swrect);
		SetRect(&rc1,0,0,width,height+swrect.bottom);
	} else SetRect(&rc1,0,0,width,height);
	AdjustWindowRectEx(&rc1,GetWindowLong(hWnd,GWL_STYLE),GetMenu(hWnd)!=0,GetWindowLong(hWnd,GWL_EXSTYLE));
	MoveWindow(hWnd,wndpl.rcNormalPosition.left,wndpl.rcNormalPosition.top,rc1.right-rc1.left,rc1.bottom-rc1.top,TRUE);
}
void __cdecl DisplayError (char*Message,...) {
	char Msg[256];
	va_list ap;
	va_start(ap,Message);
	vsprintf(Msg,Message,ap);
	va_end(ap);
	HandleModal1(hMainWindow);
	MessageBox(0,Msg,GS(MSG_ERROR_TITLE),MB_OK|MB_ICONERROR|MB_SETFOREGROUND);
	HandleModal2(hMainWindow);
}
void FixMenuLang (HMENU hMenu) {
	HMENU hSubMenu;
	MenuSetText(hMenu,0,GS(MENU_FILE),0);
	MenuSetText(hMenu,1,GS(MENU_SYSTEM),0);
	MenuSetText(hMenu,2,GS(MENU_OPTIONS),0);
	MenuSetText(hMenu,3,GS(MENU_HELP),0);
	//File
	hSubMenu=GetSubMenu(hMenu,0);
	MenuSetText(hSubMenu,0,GS(MENU_OPEN),"Ctrl+O");
	MenuSetText(hSubMenu,1,GS(INFO_TITLE),0);
	MenuSetText(hSubMenu,3,GS(MENU_START),"F10");
	MenuSetText(hSubMenu,4,GS(MENU_END),"F11");
	MenuSetText(hSubMenu,6,GS(MENU_LANGUAGE),0);
	MenuSetText(hSubMenu,8,GS(MENU_CHOOSE_ROM),0);
	MenuSetText(hSubMenu,9,GS(MENU_REFRESH),"F5");
	MenuSetText(hSubMenu,11,GS(MENU_RECENT_ROM),0);
	MenuSetText(hSubMenu,12,GS(MENU_RECENT_DIR),0);
	MenuSetText(hSubMenu,13,GS(MENU_EXIT),"Alt+F4");
	//System
	hSubMenu=GetSubMenu(hMenu,1);
	MenuSetText(hSubMenu,0,GS(MENU_RESET),"F1");
	MenuSetText(hSubMenu,1,GS(CPU_Paused?MENU_RESUME:MENU_PAUSE),"Shift+Caps Lock/F2");
	MenuSetText(hSubMenu,2,GS(MENU_ADVANCE),"Caps Lock");
	MenuSetText(hSubMenu,3,GS(MENU_BITMAP),"F3");
	MenuSetText(hSubMenu,5,GS(MENU_LIMIT_FPS),"F4");
	MenuSetText(hSubMenu,6,GS(SPEEDCAP),"Ctrl+F4");
	MenuSetText(hSubMenu,8,GS(MENU_SAVE),"F5");
	MenuSetText(hSubMenu,9,GS(MENU_SAVE_AS),"Ctrl+S");
	MenuSetText(hSubMenu,10,GS(MENU_RESTORE),"F7");
	MenuSetText(hSubMenu,11,GS(MENU_LOAD),"Ctrl+L");
	MenuSetText(hSubMenu,13,GS(MENU_CURRENT_SAVE),0);
	MenuSetText(hSubMenu,15,GS(MENU_CHEAT),"Ctrl+C");
	MenuSetText(hSubMenu,16,GS(MENU_GS_BUTTON),"Ctrl+G");
	MenuSetText(hSubMenu,18,GS(GAMECAPTURE),"F9");
	//Options
	hSubMenu=GetSubMenu(hMenu,2);
	MenuSetText(hSubMenu,0,GS(MENU_FULL_SCREEN),"Esc/Alt+Enter");
	MenuSetText(hSubMenu,1,GS(AllocateCompile_SD),"Ctrl+M");
	MenuSetText(hSubMenu,3,GS(MENU_ON_TOP),"Ctrl+U");
	MenuSetText(hSubMenu,5,GS(MENU_CONFIG_GFX),"Ctrl+V");
	MenuSetText(hSubMenu,6,GS(MENU_CONFIG_AUDIO),"Ctrl+A");
	MenuSetText(hSubMenu,7,GS(MENU_CONFIG_CTRL),"Ctrl+I");
	MenuSetText(hSubMenu,9,GS(GAME_CAPTURE),0);
	MenuSetText(hSubMenu,11,GS(MENU_UNINSTALL),"Ctrl+F");
	MenuSetText(hSubMenu,13,GS(MENU_SETTINGS),"Ctrl+T");
	//Game Display Options
	hSubMenu=GetSubMenu(hSubMenu,9);
	MenuSetText(hSubMenu,0,GS(RGBREC),"Ctrl+R");
	MenuSetText(hSubMenu,1,GS(VIDEOTOSCREEN),"Ctrl+P");
	MenuSetText(hSubMenu,2,GS(HIDE_MOUSE),"Ctrl+H");
	MenuSetText(hSubMenu,3,GS(CREATE_STATUS_BAR),"Ctrl+B");
	//Help Menu
	hSubMenu=GetSubMenu(hMenu,3);
	MenuSetText(hSubMenu,0,GS(MENU_USER_GUIDE),0);
	MenuSetText(hSubMenu,1,GS(MENU_ABOUT_INI),0);
}
char*GetIniFileName() {
	char path_buffer[_MAX_PATH],drive[_MAX_DRIVE],dir[_MAX_DIR];
	char fname[_MAX_FNAME],ext[_MAX_EXT];
	static char IniFileName[_MAX_PATH];
	GetModuleFileName(0,path_buffer,sizeof(path_buffer));
	_splitpath(path_buffer,drive,dir,fname,ext);
	sprintf(IniFileName,"%s%sPJ64DB\\%s",drive,dir,IniName);
	return IniFileName;
}
char*GetLangFileName() {
	char path_buffer[_MAX_PATH],drive[_MAX_DRIVE],dir[_MAX_DIR];
	char fname[_MAX_FNAME],ext[_MAX_EXT];
	static char IniFileName[_MAX_PATH];
	GetModuleFileName(0,path_buffer,sizeof(path_buffer));
	_splitpath(path_buffer,drive,dir,fname,ext);
	sprintf(IniFileName,"%s%s%s",drive,dir,LangFileName);
	return IniFileName;
}
void LoadSettings () {
	DWORD Type,Bytes=4;
	HKEY hKeyResults;
	char String[256];
	long lResult;
	// APP NON-PLUGIN DEFAULTS
	SystemUseCache=REG_CACHE_ON;
	SystemProtectMemoryEnlargeBuffer=PROTECT_MEMORY_ENLARGE_BUFFER_OFF;
	SystemCF=2;
	AutoSleep=FALSE;
	ForceDisableTLB=FALSE;
	ForceDisableCpuRecompiler=FALSE;
	ForceEnableDMA=FALSE;
	SkipAudioClear=FALSE;
	ForceAuto16kbit=FALSE;
	AutoFullScreen=FALSE;
	RomsToRemember=10;
	RomDirsToRemember=10;
	AutoRefreshRomBrowser=TRUE;
	BasicMode=TRUE;
	Recursion=TRUE;
	LimitFPS=TRUE;
	SpeedCap=FALSE;
	UsuallyonTop=FALSE;
	RecordRGB=FALSE;
	AutoHide=TRUE;
	VideoToScreen=FALSE;
	CreateStatusBar=TRUE;
	sprintf(String,"PJ64 V 1.6.2\\Configuration");
	lResult=RegOpenKeyEx(HKEY_CURRENT_USER,String,0,KEY_ALL_ACCESS,&hKeyResults);
	if (lResult==ERROR_SUCCESS) {
		lResult=RegQueryValueEx(hKeyResults,"Limit FPS",0,&Type,(LPBYTE)(&LimitFPS),&Bytes);
		if (Type!=REG_DWORD||lResult!=ERROR_SUCCESS) {LimitFPS=TRUE;}
		lResult=RegQueryValueEx(hKeyResults,"Speed Cap",0,&Type,(LPBYTE)(&SpeedCap),&Bytes);
		if (Type!=REG_DWORD||lResult!=ERROR_SUCCESS) {SpeedCap=FALSE;}
		lResult=RegQueryValueEx(hKeyResults,"Usually on Top",0,&Type,(LPBYTE)(&UsuallyonTop),&Bytes);
		if (Type!=REG_DWORD||lResult!=ERROR_SUCCESS) {UsuallyonTop=FALSE;}
		lResult=RegQueryValueEx(hKeyResults,"Record gameplay with RGB instead of YUV",0,&Type,(LPBYTE)(&RecordRGB),&Bytes);
		if (Type!=REG_DWORD||lResult!=ERROR_SUCCESS) {RecordRGB=FALSE;}
		lResult=RegQueryValueEx(hKeyResults,"Hide Mouse Cursor",0,&Type,(LPBYTE)(&AutoHide),&Bytes);
		if (Type!=REG_DWORD||lResult!=ERROR_SUCCESS) {AutoHide=TRUE;}
		lResult=RegQueryValueEx(hKeyResults,"Display Status Bar",0,&Type,(LPBYTE)(&CreateStatusBar),&Bytes);
		if (Type!=REG_DWORD||lResult!=ERROR_SUCCESS) {CreateStatusBar=TRUE;}
		lResult=RegQueryValueEx(hKeyResults,"Capture Screenshots with Video Plugin",0,&Type,(LPBYTE)(&VideoToScreen),&Bytes);
		if (Type!=REG_DWORD||lResult!=ERROR_SUCCESS) {VideoToScreen=FALSE;}
		lResult=RegQueryValueEx(hKeyResults,"Auto Refresh ROM Browser",0,&Type,(LPBYTE)(&AutoRefreshRomBrowser),&Bytes);
		if (Type!=REG_DWORD||lResult!=ERROR_SUCCESS) {AutoRefreshRomBrowser=TRUE;}
		lResult=RegQueryValueEx(hKeyResults,"Basic Mode",0,&Type,(LPBYTE)(&BasicMode),&Bytes);
		if (Type!=REG_DWORD||lResult!=ERROR_SUCCESS) {BasicMode=TRUE;}
		lResult=RegQueryValueEx(hKeyResults,"Pause CPU Upon Focus Loss",0,&Type,(BYTE*)(&AutoSleep),&Bytes);
		if (Type!=REG_DWORD||lResult!=ERROR_SUCCESS) {AutoSleep=FALSE;}
		lResult=RegQueryValueEx(hKeyResults,"Enter Fullscreen Mode Upon ROM Opening",0,&Type,(BYTE*)(&AutoFullScreen),&Bytes);
		if (Type!=REG_DWORD||lResult!=ERROR_SUCCESS) {AutoFullScreen=FALSE;}
		lResult=RegQueryValueEx(hKeyResults,"Always Disable TLB",0,&Type,(BYTE*)(&ForceDisableTLB),&Bytes);
		if (Type!=REG_DWORD||lResult!=ERROR_SUCCESS) {ForceDisableTLB=FALSE;}
		lResult=RegQueryValueEx(hKeyResults,"Always Interpret VR4300i CPU",0,&Type,(BYTE*)(&ForceDisableCpuRecompiler),&Bytes);
		if (Type!=REG_DWORD||lResult!=ERROR_SUCCESS) {ForceDisableCpuRecompiler=FALSE;}
		lResult=RegQueryValueEx(hKeyResults,"Always Enable Align DMA",0,&Type,(BYTE*)(&ForceEnableDMA),&Bytes);
		if (Type!=REG_DWORD||lResult!=ERROR_SUCCESS) {ForceEnableDMA=FALSE;}
		lResult=RegQueryValueEx(hKeyResults,"Skip Audio Clearance on State Loads",0,&Type,(BYTE*)(&SkipAudioClear),&Bytes);
		if (Type!=REG_DWORD||lResult!=ERROR_SUCCESS) {SkipAudioClear=FALSE;}
		lResult=RegQueryValueEx(hKeyResults,"Always Autodetect With 16kbit",0,&Type,(BYTE*)(&ForceAuto16kbit),&Bytes);
		if (Type!=REG_DWORD||lResult!=ERROR_SUCCESS) {ForceAuto16kbit=FALSE;}
		lResult=RegQueryValueEx(hKeyResults,"Protect Memory / Enlarge Buffer",0,&Type,(LPBYTE)(&SystemProtectMemoryEnlargeBuffer),&Bytes);
		if (Type!=REG_DWORD||lResult!=ERROR_SUCCESS) {SystemProtectMemoryEnlargeBuffer=PROTECT_MEMORY_ENLARGE_BUFFER_OFF;}
		lResult=RegQueryValueEx(hKeyResults,"Register Caching",0,&Type,(LPBYTE)(&SystemUseCache),&Bytes);
		if (Type!=REG_DWORD||lResult!=ERROR_SUCCESS) {SystemUseCache=REG_CACHE_ON;}
		lResult=RegQueryValueEx(hKeyResults,"Counter Factor",0,&Type,(LPBYTE)(&SystemCF),&Bytes);
		if (Type!=REG_DWORD||lResult!=ERROR_SUCCESS) {SystemCF=2;}
		lResult=RegQueryValueEx(hKeyResults,"Directory Recursion",0,&Type,(BYTE*)(&Recursion),&Bytes);
		if (Type!=REG_DWORD||lResult!=ERROR_SUCCESS) {Recursion=TRUE;}
		lResult=RegQueryValueEx(hKeyResults,"Max # of ROMs Remembered",0,&Type,(BYTE*)(&RomsToRemember),&Bytes);
		if (Type!=REG_DWORD||lResult!=ERROR_SUCCESS) {RomsToRemember=10;}
		lResult=RegQueryValueEx(hKeyResults,"Max # of ROM Dirs Remembered",0,&Type,(BYTE*)(&RomDirsToRemember),&Bytes);
		if (Type!=REG_DWORD||lResult!=ERROR_SUCCESS) {RomDirsToRemember=10;}
		RegCloseKey(hKeyResults);
	}
}
int InitializeApplication (HINSTANCE hInstance) {
	INITCOMMONCONTROLSEX IntComStruct;
	CoInitialize(0);
	IntComStruct.dwSize=sizeof(IntComStruct);
	IntComStruct.dwICC=ICC_TREEVIEW_CLASSES;
	InitCommonControls();
	InitCommonControlsEx(&IntComStruct);
	hInst=hInstance;
	if (!Allocate_Memory()) {
		DisplayError(GS(MSG_MEM_ALLOC_ERROR));
		return FALSE;
	}
	init_summercart(&SummerCart);
	poweron_summercart(&SummerCart);
	INITIALIZECPUFlags();
	LoadSettings();
	SetupRegisters(&Registers);
	QueryPerformanceFrequency(&Frequency);
	LoadRomBrowserColumnInfo();
	InitializeInitialCompilerVariable();
	return TRUE;
}
void CheckedMenuItem(UINT uMenuID,BOOL*Flag,char*FlagName) {
	char String[256];
	DWORD Disposition;
	HKEY hKeyResults;
	long lResult;
	UINT uState;
	uState=GetMenuState(hMainMenu,uMenuID,MF_BYCOMMAND);
	hKeyResults=0;
	Disposition=0;
	if (uState&MFS_CHECKED) {
		CheckMenuItem(hMainMenu,uMenuID,MF_BYCOMMAND|MFS_UNCHECKED);
		*Flag=FALSE;
	} else {
		CheckMenuItem(hMainMenu,uMenuID,MF_BYCOMMAND|MFS_CHECKED);
		*Flag=TRUE;
	}
	sprintf(String,"PJ64 V 1.6.2\\Configuration");
	lResult=RegCreateKeyEx(HKEY_CURRENT_USER,String,0,"",REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,0,&hKeyResults,&Disposition);
	if (lResult==ERROR_SUCCESS) {
		RegSetValueEx(hKeyResults,FlagName,0,REG_DWORD,(BYTE*)Flag,sizeof(DWORD));
		RegCloseKey(hKeyResults);
	}
}
void SelectRomDir() {
	char Buffer[MAX_PATH],RomDir[MAX_PATH+1],Directory[256];
	LPITEMIDLIST pidl;
	BROWSEINFO bi;
	GetRomDirectory(RomDir);
	bi.hwndOwner=hMainWindow;
	bi.pidlRoot=0;
	bi.pszDisplayName=Buffer;
	bi.lpszTitle=GS(DIR_SELECT_ROM);
	bi.ulFlags=BIF_RETURNFSANCESTORS|BIF_RETURNONLYFSDIRS;
	bi.lpfn=(BFFCALLBACK)SelectRomDirCallBack;
	bi.lParam=(DWORD)RomDir;
	if ((pidl=SHBrowseForFolder(&bi))!=0) {
		if (SHGetPathFromIDList(pidl,Directory)) {
			int len=strlen(Directory);
			if (Directory[len-1]!='\\') {
				strcat(Directory,"\\");
			}
			SetRomDirectory(Directory);
			SetupMenu(hMainWindow);
		}
	}
}
void SetRecentRomDir (DWORD Index) {
	Index-=ID_FILE_RECENT_DIR;
	if (Index<0||Index>RomDirsToRemember) return;
	SetRomDirectory(LastDirs[Index]);
	SetupMenu(hMainWindow);
}
LRESULT CALLBACK Main_Proc(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam) {
	int screenHeight=GetSystemMetrics(SM_CYSCREEN),screenWidth=GetSystemMetrics(SM_CXSCREEN);
	switch (uMsg) {
	case WM_CREATE:
		if (CreateStatusBar) hStatusWnd=CreateStatusWindow(WS_CHILD|WS_VISIBLE,"",hWnd,100);
		if (screenHeight>=1440&&screenWidth>=1920) ChangeWinSize(hWnd,1280,960,hStatusWnd);
		else if (screenHeight>=1080&&screenWidth>=1440) ChangeWinSize(hWnd,800,600,hStatusWnd);
		else ChangeWinSize(hWnd,640,480,hStatusWnd);
		break;
	case WM_NCLBUTTONDBLCLK:
		return DefWindowProc(hWnd,uMsg,wParam,lParam);
	case WM_SYSCOMMAND:
		switch (wParam) {
		case SC_SCREENSAVE:
		case SC_MONITORPOWER:
			return 0;
		case SC_MAXIMIZE:
		default:
			return DefWindowProc(hWnd,uMsg,wParam,lParam);
		}
	case WM_PAINT:
		ValidateRect(hWnd,0);
		break;
	case WM_MOVE:
		if (hWnd==hHiddenWindow) {break;}
		if (MoveScreen!=0&&CPURunning) {
			MoveScreen((int)(short)LOWORD(lParam),(int)(short)HIWORD(lParam));
		}
		if (IsIconic(hWnd)) {
			if (!CPU_Paused&&!inFullScreen) {PauseCPU();}
			break;
		} else {
			if (!ManualPaused&&(CPU_Paused||CPU_Action.Pause)) {PauseCPU();}
		}
		break;
	case WM_ENTERSIZEMOVE:
		if (strcmp(GfxDLL,"Icepir8sLegacyLLE.dll")==0&&CPURunning) SetWindowLong(hMainWindow,GWL_EXSTYLE,GetWindowLong(hMainWindow,GWL_EXSTYLE)|WS_EX_COMPOSITED);
		break;
	case WM_EXITSIZEMOVE:
		if (strcmp(GfxDLL,"Icepir8sLegacyLLE.dll")==0&&CPURunning) SetWindowLong(hMainWindow,GWL_EXSTYLE,GetWindowLong(hMainWindow,GWL_EXSTYLE)&~WS_EX_COMPOSITED);
		break;
	case WM_SIZE:
		if (hWnd==hHiddenWindow) {break;}
		{
			RECT clrect,swrect;
			int Parts[2];
			GetClientRect(hWnd,&clrect);
			GetClientRect(hStatusWnd,&swrect);
			Parts[0]=(LOWORD(lParam)-(int)(clrect.right*0.25));
			Parts[1]=LOWORD(lParam);
			SendMessage(hStatusWnd,SB_SETPARTS,2,(LPARAM)&Parts[0]);
			MoveWindow(hStatusWnd,0,clrect.bottom-swrect.bottom,LOWORD(lParam),HIWORD(lParam),TRUE);
			if (!CPURunning) SendMessage(hStatusWnd,SB_SETTEXT,1,(LPARAM)"");
		}
		ResizeRomListControl(LOWORD(lParam),HIWORD(lParam));
		SendMessage(hWnd,WM_NCPAINT,0,0);
		break;
	case WM_SETFOCUS:
		if (hWnd==hHiddenWindow) {break;}
		if (AutoSleep&&!ManualPaused&&(CPU_Paused||CPU_Action.Pause)) {PauseCPU();}
		break;
	case WM_KILLFOCUS:
		if (hWnd==hHiddenWindow) {break;}
		if (AutoSleep&&!CPU_Paused) {PauseCPU();}
		break;
	case WM_NOTIFY:
		if (wParam==IDC_ROMLIST) {RomListNotify((LPNMHDR)lParam);}
		return DefWindowProc(hWnd,uMsg,wParam,lParam);
	case WM_DRAWITEM:
		if (wParam==IDC_ROMLIST) {RomListDrawItem((LPDRAWITEMSTRUCT)lParam);}
		break;
	case WM_MENUSELECT:
		switch (LOWORD(wParam)) {
		case ID_PLAYGAME: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_START)); break;
		case ID_POPUPMENU_ROMINFORMATION: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MSG_RB_INFO)); break;
		case ID_BROWSERNOTES: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SETTINGS)); break;
		case ID_EDITCHEATS: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_CHEAT)); break;
		case ID_FILE_OPEN_ROM: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_OPEN)); break;
		case ID_FILE_ROM_INFO: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_ROM_INFO)); break;
		case ID_FILE_STARTEMULATION: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_START)); break;
		case ID_FILE_ENDEMULATION: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_END)); break;
		case ID_FILE_ROMDIRECTORY: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_CHOOSE_ROM)); break;
		case ID_FILE_REFRESHROMLIST: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_REFRESH)); break;
		case ID_FILE_EXIT: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_EXIT)); break;
		case ID_CPU_RESET: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_RESET)); break;
		case ID_CPU_PAUSE: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_PAUSE)); break;
		case ID_SYSTEM_GENERATEBITMAP: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_BITMAP)); break;
		case ID_SYSTEM_ALTERNATEPAUSE: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENU_ADVANCE_DESC)); break;
		case ID_SYSTEM_LIMITFPS: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_LIMIT_FPS)); break;
		case ID_SYSTEM_SPEEDCAP:SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(SPEEDCAP_DESC)); break;
		case ID_CPU_SAVE: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_SAVE)); break;
		case ID_CPU_SAVEAS: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_SAVE_AS)); break;
		case ID_CPU_RESTORE: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_RESTORE)); break;
		case ID_CPU_LOAD: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_LOAD)); break;
		case ID_OPTIONS_CHEATS: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_CHEAT)); break;
		case ID_SYSTEM_GSBUTTON: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GS_BUTTON)); break;
		case ID_OPTIONS_FULLSCREEN: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_FULL_SCREEN)); break;
		case ID_OPTIONS_UsuallyonTop: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_ON_TOP)); break;
		case ID_OPTIONS_VideoToScreen: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_VIDEOTOSCREEN)); break;
		case ID_OPTIONS_CONFIG_GFX: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_CONFIG_GFX)); break;
		case ID_OPTIONS_CONFIG_AUDIO: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_CONFIG_AUDIO)); break;
		case ID_OPTIONS_CONFIG_CONTROL: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_CONFIG_CTRL)); break;
		case ID_OPTIONS_GAMECAPTURE: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAMECAPTURE)); break;
		case ID_OPTIONS_RGBREC: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(RGBREC_MENUDES)); break;
		case ID_OPTIONS_HIDE_CURSOR: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_HIDE_MOUSE)); break;
		case ID_OPTIONS_CREATE_STATUS_BAR: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_CREATE_STATUS_BAR)); break;
		case ID_OPTIONS_SETTINGS: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_SETTINGS)); break;
		case ID_HELP_GUIDE: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_USER_GUIDE)); break;
		case ID_HELP_ABOUTSETTINGFILES: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_ABOUT_INI)); break;
		case ID_HELP_UNINSTALL: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_UNINSTALLAPP)); break;
		case ID_ALLOCATE_COMPILE_SD: SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(AllocateCompile_SD_MENUDES)); break;
		case ID_CURRENTSAVE_DEFAULT:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_2:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_3:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_4:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_5:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_6:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_7:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_8:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_9:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_10:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_11:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_12:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_13:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_14:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_15:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_16:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_17:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_18:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_19:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_20:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_21:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_22:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_23:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_24:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_25:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_26:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_27:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_28:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_29:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		case ID_CURRENTSAVE_30:
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_GAME_SLOT));
			break;
		default:
			if (LOWORD(wParam)>=ID_FILE_RECENT_FILE&&LOWORD(wParam)<=(ID_FILE_RECENT_FILE+RomsToRemember)) SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_RECENT_ROM));
			else if (LOWORD(wParam)>=ID_FILE_RECENT_DIR&&LOWORD(wParam)<=(ID_FILE_RECENT_DIR+RomDirsToRemember)) SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_RECENT_DIR));
			else if (LOWORD(wParam)>=ID_LANG_SELECT&&LOWORD(wParam)<=(ID_LANG_SELECT+100)) SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MENUDES_LANGUAGES));
			else SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)"");
		}
		break;
	case WM_KEYDOWN:
		if (CPURunning&&WM_KeyDown) WM_KeyDown(wParam,lParam);
		break;
	case WM_KEYUP:
		if (CPURunning&&WM_KeyUp) WM_KeyUp(wParam,lParam);
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case ID_PLAYGAME:
			if (strlen(CurrentRBFileName)>0) {
				strcpy(CurrentFileName,CurrentRBFileName);
				OpenChosenFile();
			}
			break;
		case ID_EDITCHEATS: ChangeRomCheats(hWnd); break;
		case ID_BROWSERNOTES: ChangeRomSettings(hWnd); break;
		case ID_POPUPMENU_ROMINFORMATION:
			{
				char OrigRomName[sizeof(RomName)],OrigFileName[sizeof(CurrentFileName)];
				BYTE OrigByteHeader[sizeof(RomHeader)];
				DWORD OrigFileSize;
				//Make copy of current Game values
				strncpy(OrigRomName,RomName,sizeof(OrigRomName));
				strncpy(OrigFileName,CurrentFileName,sizeof(OrigFileName));
				memcpy(OrigByteHeader,RomHeader,sizeof(RomHeader));
				strncpy(CurrentFileName,CurrentRBFileName,sizeof(CurrentFileName));
				OrigFileSize=RomFileSize;
				//Load header of selected Rom
				LoadRomHeader();
				//Display Information
				RomInfo();
				//Restore settings
				strncpy(RomName,OrigRomName,sizeof(RomName));
				strncpy(CurrentFileName,OrigFileName,sizeof(CurrentFileName));
				memcpy(RomHeader,OrigByteHeader,sizeof(RomHeader));
				RomFileSize=OrigFileSize;
			}
			break;
		case ID_FILE_OPEN_ROM: if (ChooseN64RomToOpen()) OpenChosenFile(); break;
		case ID_FILE_ROM_INFO: RomInfo(); break;
		case ID_FILE_STARTEMULATION:
			strcpy(CurrentFileName,LastRoms[0]);
			OpenChosenFile();
			break;
		case ID_FILE_ENDEMULATION:
			if (inFullScreen) {
				if (strcmp(GfxDLL,"GLideN64.dll")==0) break;
				SendMessage(hMainWindow,WM_COMMAND,ID_OPTIONS_FULLSCREEN,0);
			}
			EndEmulation();
			CPURunning=FALSE;
			EnableWindow(hRomList,TRUE);
			OpenRomBrowser();
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MSG_EMULATION_ENDED));
			break;
		case ID_FILE_ROMDIRECTORY: SelectRomDir(); break;
		case ID_FILE_REFRESHROMLIST: RefreshRomBrowser(); break;
		case ID_FILE_EXIT: DestroyWindow(hWnd); break;
		case ID_CPU_RESET:
			EndEmulation();
			HandlePluginsAndEmulationStartup();
			break;
		case ID_CPU_PAUSE:
			ManualPaused=TRUE;
			PauseCPU();
			break;
		case ID_CPU_SAVE:
			if (CPU_Paused) {
				if (!Machine_SaveState()) CPU_Action.SaveState=TRUE;
			} else CPU_Action.SaveState=TRUE;
			break;
		case ID_CPU_SAVEAS:
			{
				char drive[_MAX_DRIVE],dir[_MAX_DIR],fname[_MAX_FNAME],ext[_MAX_EXT],Directory[256],SaveFile[256];
				OPENFILENAME openfilename;
				memset(&SaveFile,0,sizeof(SaveFile));
				memset(&openfilename,0,sizeof(openfilename));
				GetInstantSaveDir(Directory);
				openfilename.lStructSize=sizeof(openfilename);
				openfilename.hwndOwner  =hWnd;
				openfilename.lpstrFilter="All files (*.*)\0*\0Slots (*.st)\0*.st\0";
				openfilename.lpstrFile  =SaveFile;
				openfilename.lpstrInitialDir  =Directory;
				openfilename.nMaxFile   =MAX_PATH;
				openfilename.Flags      =OFN_OVERWRITEPROMPT|OFN_HIDEREADONLY;
				if (GetSaveFileName (&openfilename)) {
					_splitpath(SaveFile,drive,dir,fname,ext);
					if (strcmp(ext,"st")==0) _makepath(SaveFile,drive,dir,fname,0);
					strcpy(SaveAsFileName,SaveFile);
					if (CPU_Paused) {
						if (!Machine_SaveState()) CPU_Action.SaveState=TRUE;
					} else CPU_Action.SaveState=TRUE;
				}
			}
			break;
		case ID_CPU_RESTORE:
			CPU_Action.RestoreState=TRUE;
			break;
		case ID_CPU_LOAD:
			{
				char Directory[256],SaveFile[256];
				OPENFILENAME openfilename;
				memset(&SaveFile,0,sizeof(SaveFile));
				memset(&openfilename,0,sizeof(openfilename));
				GetInstantSaveDir(Directory);
				openfilename.lStructSize=sizeof(openfilename);
				openfilename.hwndOwner  =hWnd;
				openfilename.lpstrFilter="All files (*.*)\0*\0Slots (*.st)\0*.st\0";
				openfilename.lpstrFile  =SaveFile;
				openfilename.lpstrInitialDir  =Directory;
				openfilename.nMaxFile   =MAX_PATH;
				openfilename.Flags      =OFN_FILEMUSTEXIST|OFN_HIDEREADONLY;
				if (GetOpenFileName (&openfilename)) {
					strcpy(LoadFileName,SaveFile);
					CPU_Action.RestoreState=TRUE;
				}
			}
			break;
		case ID_SYSTEM_GENERATEBITMAP:
		{
			char Directory[256],statusMsg[256];
			static BOOL toggle=FALSE;
			if (VideoToScreen||inFullScreen&&strcmp(GfxDLL,"GLideN64.dll")==0) {
				if (CaptureScreen==0) break;
				FetchScreenAndVideoDir(Directory);
				CaptureScreen(Directory);
			} else {
				int fileIndex=0,rowSize,sourceX=0,sourceY=0;
				char outputFile[_MAX_PATH],Directory[_MAX_PATH],*IniFile,Identifier[100],GameName[200];
				HDC hScreenDC,hMemoryDC;
				HBITMAP hBitmap,hOldBitmap;
				BITMAPINFO bi;
				BITMAPFILEHEADER bfh;
				BYTE* pixels;
				HANDLE hFile;
				DWORD bytesWritten,imageSize;
				RECT rc;
				FetchScreenAndVideoDir(Directory);
				IniFile=GetIniFileName();
				sprintf(Identifier,"%08X-%08X-C:%X",*(DWORD*)(&RomHeader[0x10]),*(DWORD*)(&RomHeader[0x14]),RomHeader[0x3D]);
				_GetPrivateProfileString(Identifier,"Game Name","",GameName,sizeof(GameName),IniFile);
				do {
					if (strcmp(GameName,"(UNREGISTERED GAME ENTRY)")==0) sprintf(outputFile,"%s\\snap%04d.bmp",Directory,fileIndex);
					else sprintf(outputFile,"%s\\%s snap%04d.bmp",Directory,GameName,fileIndex);
					fileIndex++;
				} while (GetFileAttributes(outputFile)!=INVALID_FILE_ATTRIBUTES);
				if (!inFullScreen) {
					RECT statusRect;
					if (!GetClientRect(hMainWindow,&rc)) break;
					if (GetWindowRect(hStatusWnd,&statusRect)) cropHeight=statusRect.bottom-statusRect.top;
					screenWidth=rc.right-rc.left;
					screenHeight=rc.bottom-rc.top-cropHeight;
					if (screenWidth>0&&(screenWidth&1)) {
						sourceX=1;
						screenWidth--;
					}
					if (screenHeight>0&&(screenHeight&1)) {
						sourceY=1;
						screenHeight--;
					}
				}
				hScreenDC=GetDC(hMainWindow);
				if (hScreenDC==0) break;
				hMemoryDC=CreateCompatibleDC(hScreenDC);
				if (hMemoryDC==0) {
					ReleaseDC(hMainWindow,hScreenDC);
					break;
				}
				hBitmap=CreateCompatibleBitmap(hScreenDC,screenWidth,screenHeight);
				if (hBitmap==0) {
					DeleteDC(hMemoryDC);
					ReleaseDC(hMainWindow,hScreenDC);
					break;
				}
				hOldBitmap=(HBITMAP)SelectObject(hMemoryDC,hBitmap);
				BitBlt(hMemoryDC,0,0,screenWidth,screenHeight,hScreenDC,sourceX,sourceY,SRCCOPY);
				if (!AutoHide) {
					CURSORINFO ci;
					ICONINFO ii;
					ZeroMemory(&ci,sizeof(ci));
					ci.cbSize=sizeof(ci);
					if (GetCursorInfo(&ci)&(ci.flags&CURSOR_SHOWING)) {
						if (GetIconInfo(ci.hCursor,&ii)) {
							int cursorX,cursorY;
							POINT pt;
							pt.x=ci.ptScreenPos.x;
							pt.y=ci.ptScreenPos.y;
							if (ScreenToClient(hMainWindow,&pt)) {
								cursorX=pt.x;
								cursorY=pt.y;
							} else {
								cursorX=-10000;
								cursorY=-10000;
							}
							if (cursorX>-1000&&cursorY>-1000&&cursorX<screenWidth+1000&&cursorY<screenHeight+1000) DrawIconEx(hMemoryDC,cursorX-(int)ii.xHotspot,cursorY-(int)ii.yHotspot,ci.hCursor,0,0,0,0,DI_NORMAL);
							if (ii.hbmMask) DeleteObject(ii.hbmMask);
							if (ii.hbmColor) DeleteObject(ii.hbmColor);
						}
					}	
				}
				SelectObject(hMemoryDC,hOldBitmap);
				ZeroMemory(&bi,sizeof(bi));
				bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
				bi.bmiHeader.biWidth=screenWidth;
				bi.bmiHeader.biHeight=screenHeight;
				bi.bmiHeader.biPlanes=1;
				bi.bmiHeader.biBitCount=24;
				bi.bmiHeader.biCompression=BI_RGB;
				rowSize=((screenWidth*3+3)&~3);
				imageSize=rowSize*screenHeight;
				pixels=(BYTE*)malloc(imageSize);
				if (pixels!=0) {
					if (GetDIBits(hScreenDC,hBitmap,0,screenHeight,pixels,&bi,DIB_RGB_COLORS)) {
						ZeroMemory(&bfh,sizeof(bfh));
						bfh.bfType=0x4D42;
						bfh.bfOffBits=sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER);
						bfh.bfSize=bfh.bfOffBits+imageSize;
						hFile=CreateFile(outputFile,GENERIC_WRITE,0,0,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);
						if (hFile!=INVALID_HANDLE_VALUE) {
							WriteFile(hFile,&bfh,sizeof(bfh),&bytesWritten,0);
							WriteFile(hFile,&bi.bmiHeader,sizeof(bi.bmiHeader),&bytesWritten,0);
							WriteFile(hFile,pixels,imageSize,&bytesWritten,0);
							CloseHandle(hFile);
						}
					}
					free(pixels);
				}
				DeleteObject(hBitmap);
				DeleteDC(hMemoryDC);
				ReleaseDC(hMainWindow,hScreenDC);
			}
			sprintf(statusMsg,"%s %s",GS(SCREENSHOT_TAKEN),toggle?"<<":">>");
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)statusMsg);
			toggle=!toggle;
		}
		break;
		case ID_SYSTEM_LIMITFPS:
			if (SyncGametoAudio) break;
			CheckedMenuItem(ID_SYSTEM_LIMITFPS,&LimitFPS,"Limit FPS");
			HandleTimers();
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)(LimitFPS?GS(LIMITFPS_ON):GS(LIMITFPS_OFF)));
			break;
		case ID_SYSTEM_SPEEDCAP:
			if (SyncGametoAudio) break;
			CheckedMenuItem(ID_SYSTEM_SPEEDCAP,&SpeedCap,"Speed Cap");
			if (!LimitFPS) HandleTimers();
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)(SpeedCap?GS(SPEEDCAP_ON):GS(SPEEDCAP_OFF)));
			break;
				case ID_CURRENTSAVE_DEFAULT:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_2:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_3:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_4:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_5:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_6:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_7:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_8:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_9:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_10:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_11:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_12:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_13:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_14:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_15:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_16:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_17:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_18:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_19:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_20:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_21:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_22:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_23:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_24:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_25:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_26:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_27:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_28:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_29:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
				case ID_CURRENTSAVE_30:
					SetCurrentSaveState(hWnd,LOWORD(wParam));
					break;
		case ID_SYSTEM_GSBUTTON:
		{
			char statusMsg[256];
			static BOOL toggle=FALSE;
			ApplyGSButton();
			sprintf(statusMsg,"%s %s",GS(GS_PRESS),toggle?"<<":">>");
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)statusMsg);
			toggle=!toggle;
		}
		break;
		case ID_OPTIONS_FULLSCREEN:
			if (inFullScreen) {
				ChangeWindow();
				inFullScreen=FALSE;
				UsuallyonTopWindow(hWnd);
				if (AutoHide) ShowCursor(TRUE);
			} else {
				if (UsuallyonTop) SetWindowPos(hWnd,HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOREPOSITION|SWP_NOSIZE);
				ChangeWindow();
				inFullScreen=TRUE;
				if (AutoHide) ShowCursor(FALSE);
			}
			if (strcmp(GfxDLL,"Icepir8sLegacyLLE.dll")!=0&&!CPU_Paused&&(LimitFPS&&!SyncGametoAudio||!LimitFPS&&SpeedCap)) Timer_Start();
			break;
		case ID_SYSTEM_ALTERNATEPAUSE:
			if (CPU_Paused) {
				PauseCPU();
				timeBeginPeriod(16);
				Sleep(1);
				timeEndPeriod(16);
				PauseCPU();
			} else SendMessage(hMainWindow,WM_COMMAND,ID_CPU_PAUSE,0);
			break;
		case ID_OPTIONS_UsuallyonTop:
			CheckedMenuItem(ID_OPTIONS_UsuallyonTop,&UsuallyonTop,"Usually on Top");
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)(UsuallyonTop?GS(USUALLYONTOP_ON):GS(USUALLYONTOP_OFF)));
			if (hManageWindow) UsuallyonTopWindow(hManageWindow);
			UsuallyonTopWindow(hWnd);
			break;
		case ID_OPTIONS_VideoToScreen:
			CheckedMenuItem(ID_OPTIONS_VideoToScreen,&VideoToScreen,"Capture Screenshots with Video Plugin");
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)(VideoToScreen?GS(VIDEOTOSCREEN_ON):GS(VIDEOTOSCREEN_OFF)));
			break;
		case ID_OPTIONS_CONFIG_GFX:
		if (strcmp(GfxDLL,"GLideN64.dll")==0) {
			HandleModal1(hWnd);
			if (CPU_Paused) GFXDllConfig(hWnd);
			else {
				if (AutoSleep) {
					ManualPaused=TRUE;
					GFXDllConfig(hWnd);
					ManualPaused=FALSE;
				} else {
					PauseCPU();
					GFXDllConfig(hWnd);
					PauseCPU();
				}
			}
			HandleModal2(hWnd);
		} else GFXDllConfig(hWnd);
		break;
		case ID_OPTIONS_CONFIG_AUDIO:
		if (!CPURunning&&strcmp(AudioDLL,"Jabo_Dsound.dll")==0) {
			HandleModal1(hWnd);
			MessageBox(0,GS(MSG_PLS_START),AppName,MB_OK|MB_ICONEXCLAMATION|MB_SETFOREGROUND);
			HandleModal2(hWnd);
		} else AiDllConfig(hWnd);
		break;
		case ID_OPTIONS_CONFIG_CONTROL:
		if (!CPURunning&&strcmp(ControllerDLL,"shankle-sdl2-input.dll")==0) {
			HandleModal1(hWnd);
			MessageBox(0,GS(MSG_PLS_START),AppName,MB_OK|MB_ICONEXCLAMATION|MB_SETFOREGROUND);
			HandleModal2(hWnd);
		} else ContConfig(hWnd);
		break;
		case ID_OPTIONS_GAMECAPTURE:
		{
			char path_buffer[_MAX_PATH],drive[_MAX_DRIVE],dir[_MAX_DIR],Runtimesdir[_MAX_DIR],ffmpegPath[_MAX_PATH],outputFile[_MAX_PATH],Directory[_MAX_PATH],*IniFile,Identifier[100],cmd[4096],WinTitle[512],GameName[200];
			int fileIndex=0;
			RECT statusRect;
			GetWindowText(hMainWindow,WinTitle,sizeof(WinTitle));
			GetModuleFileName(0,path_buffer,sizeof(path_buffer));
			_splitpath(path_buffer,drive,dir,0,0);
			sprintf(Runtimesdir,"%s\\Runtimes\\",dir);
			_makepath(ffmpegPath,drive,Runtimesdir,"ffmpeg","exe");
			if (GetFileAttributes(ffmpegPath)==INVALID_FILE_ATTRIBUTES) {
				DisplayError(GS(FFMPEG_NOFIND));
				break;
			}
			FetchScreenAndVideoDir(Directory);
			IniFile=GetIniFileName();
			sprintf(Identifier,"%08X-%08X-C:%X",*(DWORD*)(&RomHeader[0x10]),*(DWORD*)(&RomHeader[0x14]),RomHeader[0x3D]);
			_GetPrivateProfileString(Identifier,"Game Name","",GameName,sizeof(GameName),IniFile);
			if (GetWindowRect(hStatusWnd,&statusRect)) cropHeight=statusRect.bottom-statusRect.top;
			do {
				if (strcmp(GameName,"(UNREGISTERED GAME ENTRY)")==0) sprintf(outputFile,"%s\\%04d%s.mp4",Directory,fileIndex,RecordRGB?"_RGB":"");
				else sprintf(outputFile,"%s\\%s %04d%s.mp4",Directory,GameName,fileIndex,RecordRGB?"_RGB":"");
				fileIndex++;
			} while (GetFileAttributes(outputFile)!=INVALID_FILE_ATTRIBUTES);
			sprintf(cmd,"cmd /K cd /d \"%s%s\" && ffmpeg -y -f gdigrab %s-framerate 60 -i title=\"%s\" -vf \"crop=trunc(iw/2)*2:trunc((ih-%d)/2)*2:0:mod(ih-%d\\,2)\" -movflags +frag_keyframe+empty_moov -level 4.1 %s-crf 14 -pix_fmt %s -preset veryfast ""\"%s\"",drive,Runtimesdir,AutoHide?"-draw_mouse 0 ":"",WinTitle,cropHeight,cropHeight,RecordRGB?"-c:v libx264rgb ":"",RecordRGB?"rgb24":"yuv420p",outputFile);
			STARTUPINFO si;
			PROCESS_INFORMATION pi;
			ZeroMemory(&si,sizeof(si));
			si.cb=sizeof(si);
			si.dwFlags=STARTF_USESHOWWINDOW;
			si.wShowWindow=SW_SHOW;
			ZeroMemory(&pi,sizeof(pi));
			if (!CreateProcess(0,cmd,0,0,FALSE,CREATE_NEW_CONSOLE,0,0,&si,&pi)) DisplayError(GS(FFMPEG_NOBOOT));
			CloseHandle(pi.hProcess);
			CloseHandle(pi.hThread);
		}
		SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(RECORDING_START));
		break;
		case ID_OPTIONS_RGBREC:
		CheckedMenuItem(ID_OPTIONS_RGBREC,&RecordRGB,"Record gameplay with RGB instead of YUV");
		SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)(RecordRGB?GS(RGBREC_ON):GS(RGBREC_OFF)));
		break;
		case ID_OPTIONS_HIDE_CURSOR:
		CheckedMenuItem(ID_OPTIONS_HIDE_CURSOR,&AutoHide,"Hide Mouse Cursor");
		SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)(AutoHide?GS(AUTOHIDE_ON):GS(AUTOHIDE_OFF)));
		if (inFullScreen&&strcmp(GfxDLL,"Icepir8sLegacyLLE.dll")!=0) AutoHide?ShowCursor(FALSE):ShowCursor(TRUE);
		break;
		case ID_OPTIONS_CREATE_STATUS_BAR:
		CheckedMenuItem(ID_OPTIONS_CREATE_STATUS_BAR,&CreateStatusBar,"Display Status Bar");
		if (CreateStatusBar&&hStatusWnd==0) hStatusWnd=CreateStatusWindow(WS_CHILD|WS_VISIBLE,"",hMainWindow,100);
		SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)(CreateStatusBar?GS(STATUSBAR_ON):GS(STATUSBAR_OFF)));
		break;
		case ID_OPTIONS_SETTINGS:
		if (UsuallyonTop) SetWindowPos(hWnd,HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOREPOSITION|SWP_NOSIZE);
		if (Recursion) {
			ChangeSettings(hWnd);
			if (AutoRefreshRomBrowser&&!Recursion&&!RefreshRomBrowserOnShutdown) RefreshRomBrowser();
		} else {
			ChangeSettings(hWnd);
			if (AutoRefreshRomBrowser&&Recursion&&!RefreshRomBrowserOnShutdown) RefreshRomBrowser();
		}
		UsuallyonTopWindow(hWnd);
		break;
		case ID_OPTIONS_CHEATS:
		ManageCheats(0);
		break;
		case ID_HELP_GUIDE:
			{
				char path_buffer[_MAX_PATH],drive[_MAX_DRIVE],dir[_MAX_DIR],Runtimesdir[_MAX_DIR],fname[_MAX_FNAME],ext[_MAX_EXT],HelpFileName[_MAX_PATH];
				GetModuleFileName(0,path_buffer,sizeof(path_buffer));
				_splitpath(path_buffer,drive,dir,fname,ext);
				sprintf(Runtimesdir,"%sRuntimes\\",dir);
				_makepath(HelpFileName,drive,Runtimesdir,"User Guide","txt");
				if (HtmlHelp(hWnd,HelpFileName,HH_DISPLAY_INDEX,0)==0) {
					ShellExecute(hWnd,"open",HelpFileName,0,0,SW_SHOW);
				}
			}
		break;
		case ID_HELP_UNINSTALL:
			HandleModal1(hWnd);
			if (MessageBox(0,GS(MSG_CONFIRMATION_UNINSTALL),GS(MENU_UNINSTALL),MB_OKCANCEL|MB_ICONEXCLAMATION|MB_SETFOREGROUND)==IDOK) {
				DestroyWindow(hWnd);
				RegDeleteTree(HKEY_CURRENT_USER,"PJ64 V 1.6.2");
			}
			HandleModal2(hWnd);
			break;
		case ID_ALLOCATE_COMPILE_SD:
		{
			static char isoFilePath[1024];
			HandleModal1(hWnd);
			SHGetFolderPath(0,CSIDL_APPDATA,0,0,isoFilePath);
			strcat(isoFilePath,"\\PJ64 1.6.2\\AUTO0.iso");
			if (MessageBox(0,GS(Allocate_SD_Info),GS(AllocateCompile_SD),MB_OKCANCEL|MB_ICONEXCLAMATION|MB_SETFOREGROUND)==IDOK) {
				char path_buffer[_MAX_PATH],drive[_MAX_DRIVE],dir[_MAX_DIR],RuntimesSDdir[_MAX_DIR],fname[_MAX_FNAME],ext[_MAX_EXT],HelpFileName[_MAX_PATH];
				GetModuleFileName(0,path_buffer,sizeof(path_buffer));
				_splitpath(path_buffer,drive,dir,fname,ext);
				sprintf(RuntimesSDdir,"%sRuntimes\\SD\\",dir);
				if (GetFileAttributes(isoFilePath)!=INVALID_FILE_ATTRIBUTES) _makepath(HelpFileName,drive,RuntimesSDdir,"SD_Allocate","bat");
				else _makepath(HelpFileName,drive,RuntimesSDdir,"SD_Compile","bat");
				if (HtmlHelp(hWnd,HelpFileName,HH_DISPLAY_INDEX,0)==0) ShellExecute(hWnd,"runas",HelpFileName,0,0,SW_SHOW);
			}
			HandleModal2(hWnd);
		}
			break;
		case ID_HELP_ABOUTSETTINGFILES: AboutIniBox(); break;
		default:
			if (LOWORD(wParam)>=ID_FILE_RECENT_FILE&&LOWORD(wParam)<=(ID_FILE_RECENT_FILE+RomsToRemember)) LoadRecentRom(LOWORD(wParam));
			else if (LOWORD(wParam)>=ID_FILE_RECENT_DIR&&LOWORD(wParam)<=(ID_FILE_RECENT_DIR+RomDirsToRemember)) SetRecentRomDir(LOWORD(wParam));
			else if (LOWORD(wParam)>=ID_LANG_SELECT&&LOWORD(wParam)<=(ID_LANG_SELECT+100)) {
				SelectLangMenuItem(GetMenu(hWnd),LOWORD(wParam));
				ResetRomBrowserColumns();
				SetupMenu(hWnd);
			}
		}
		break;
#define MinHeight 480
#define MinWidth 640
	case WM_SIZING:
		{
			LPRECT lprc=(LPRECT) lParam;
			int fwSide=wParam;
			if ((lprc->bottom-lprc->top)<=MinHeight) {
				switch (fwSide) {
				case WMSZ_TOPLEFT:
				case WMSZ_TOP:
				case WMSZ_TOPRIGHT:
					lprc->top=lprc->bottom-MinHeight;
					break;
				case WMSZ_BOTTOMLEFT:
				case WMSZ_BOTTOM:
				case WMSZ_BOTTOMRIGHT:
					lprc->bottom=lprc->top+MinHeight;
					break;
				}
			}
			if ((lprc->right-lprc->left)<=MinWidth) {
				switch (fwSide) {
				case WMSZ_TOPLEFT:
				case WMSZ_LEFT:
				case WMSZ_BOTTOMLEFT:
					lprc->left=lprc->right-MinWidth;
					break;
				case WMSZ_TOPRIGHT:
				case WMSZ_RIGHT:
				case WMSZ_BOTTOMRIGHT:
					lprc->right=lprc->left+MinWidth;
					break;
				}
			}
		}
		break;
	case WM_DESTROY:
		ShutdownApplication();
		PostQuitMessage(0);
		break;
	case WM_DROPFILES: {
		HDROP hDrop=(HDROP)wParam;
		DragQueryFile(hDrop,0,CurrentFileName,sizeof(CurrentFileName));
		DragFinish(hDrop);
		SetForegroundWindow(hWnd);
		OpenChosenFile();
		break;
	}
	default:
		return DefWindowProc(hWnd,uMsg,wParam,lParam);
	}
	return TRUE;
}
void MenuSetText (HMENU hMenu,int MenuPos,char*Title,char*Shortcut) {
	MENUITEMINFO MenuInfo;
	char String[256];
	if (Title==0||strlen(Title)==0) return;
	memset(&MenuInfo,0,sizeof(MENUITEMINFO));
	MenuInfo.cbSize=sizeof(MENUITEMINFO);
	MenuInfo.fMask=MIIM_TYPE;
	MenuInfo.fType=MFT_STRING;
	MenuInfo.fState=MFS_ENABLED;
	MenuInfo.dwTypeData=String;
	MenuInfo.cch=256;
	GetMenuItemInfo(hMenu,MenuPos,TRUE,&MenuInfo);
	if (strchr(Title,'\t')!=0) {*(strchr(Title,'\t'))='\0';}
	strcpy(String,Title);
	if (Shortcut) {sprintf(String,"%s\t%s",String,Shortcut);}
	SetMenuItemInfo(hMenu,MenuPos,TRUE,&MenuInfo);
}
int RegisterWinClass () {
	WNDCLASS wcl;
	wcl.style		=CS_OWNDC|CS_HREDRAW|CS_VREDRAW;
	wcl.cbClsExtra		=0;
	wcl.cbWndExtra		=0;
	wcl.hIcon			=LoadIcon(hInst,"ICON");
	wcl.hCursor			=LoadCursor(hInst,IDC_ARROW);
	wcl.hInstance		=hInst;
	wcl.lpfnWndProc		=(WNDPROC)Main_Proc;
	wcl.hbrBackground	=(HBRUSH)GetStockObject(BLACK_BRUSH);
	wcl.lpszMenuName	=MAKEINTRESOURCE(MAIN_MENU);
	wcl.lpszClassName	=AppName;
	if (RegisterClass(&wcl)==0) return FALSE;
	wcl.lpfnWndProc		=(WNDPROC)Cheat_Proc;
	wcl.hbrBackground	=(HBRUSH)(COLOR_BTNFACE+1);
	wcl.lpszMenuName	=0;
	wcl.lpszClassName	="PJ64.Cheats";
	if (RegisterClass(&wcl)==0) return FALSE;
	return TRUE;
}
void SetupMenu (HWND hWnd) {
	char String[256];
	long lResult;
	DWORD count,Type,Bytes;
	HKEY hKeyResults=0;
	MENUITEMINFO menuinfo;
	HMENU hMenu=GetMenu(hWnd);
	int State;
	if (inFullScreen) return;
	DestroyMenu(hMenu);
	hMenu=LoadMenu(hInst,MAKEINTRESOURCE(MAIN_MENU));
	FixMenuLang(hMenu);
	SetMenu(hWnd,hMenu);
	CreateLangList(GetSubMenu(hMenu,0),6,ID_LANG_SELECT);
	sprintf(String,"PJ64 V 1.6.2\\Configuration");
	lResult=RegOpenKeyEx(HKEY_CURRENT_USER,String,0,KEY_ALL_ACCESS,&hKeyResults);
	if (lResult==ERROR_SUCCESS) {
		for (count=0;count<RomDirsToRemember;count++) {
			Bytes=sizeof(LastDirs[count]);
			sprintf(String,"RecentDir%d",count+1);
			lResult=RegQueryValueEx(hKeyResults,String,0,&Type,(LPBYTE)LastDirs[count],&Bytes);
			if (lResult!=ERROR_SUCCESS) {
				memset(LastDirs[count],0,sizeof(LastDirs[count]));
				break;
			}
		}
		RegCloseKey(hKeyResults);
	}
	{
	memset(&menuinfo,0,sizeof(MENUITEMINFO));
	menuinfo.cbSize=sizeof(MENUITEMINFO);
	menuinfo.fMask=MIIM_TYPE|MIIM_ID;
	menuinfo.fType=MFT_STRING;
	menuinfo.fState=MFS_ENABLED;
	menuinfo.dwTypeData=String;
	menuinfo.cch=256;
	sprintf(String," ");
	HMENU hSubMenu=GetSubMenu(hMenu,0);
	InsertMenuItem(hSubMenu,MenuLocOfUsedDirs,TRUE,&menuinfo);
	hSubMenu=CreateMenu();
	if (strlen(LastDirs[0])==0) {
		menuinfo.wID=ID_FILE_RECENT_DIR;
		sprintf(String," ");
		InsertMenuItem(hSubMenu,0,TRUE,&menuinfo);
	}
	menuinfo.fMask=MIIM_TYPE|MIIM_ID;
	for (count=0;count<RomDirsToRemember;count++) {
		if (strlen(LastDirs[count])==0) {break;}
		menuinfo.wID=ID_FILE_RECENT_DIR+count;
		sprintf(String,"&%d %s",(count+1) % 10,LastDirs[count]);
		InsertMenuItem(hSubMenu,count,TRUE,&menuinfo);
	}
	ModifyMenu(GetSubMenu(hMenu,0),MenuLocOfUsedDirs,MF_POPUP|MF_BYPOSITION,(DWORD)hSubMenu,GS(MENU_RECENT_DIR));
	if (strlen(LastDirs[0])==0||RomDirsToRemember==0) EnableMenuItem(GetSubMenu(hMenu,0),MenuLocOfUsedDirs,MF_BYPOSITION|MFS_DISABLED);
	else EnableMenuItem(GetSubMenu(hMenu,0),MenuLocOfUsedDirs,MF_BYPOSITION|MFS_ENABLED);
	}
	sprintf(String,"PJ64 V 1.6.2\\Configuration");
	lResult=RegOpenKeyEx(HKEY_CURRENT_USER,String,0,KEY_ALL_ACCESS,&hKeyResults);
	if (lResult==ERROR_SUCCESS) {
		for (count=0;count<RomsToRemember;count++) {
			Bytes=sizeof(LastRoms[count]);
			sprintf(String,"RecentFile%d",count+1);
			lResult=RegQueryValueEx(hKeyResults,String,0,&Type,(LPBYTE)LastRoms[count],&Bytes);
			if (lResult!=ERROR_SUCCESS) {
				memset(LastRoms[count],0,sizeof(LastRoms[count]));
				break;
			}
		}
		RegCloseKey(hKeyResults);
	}
	{
	memset(&menuinfo,0,sizeof(MENUITEMINFO));
	menuinfo.cbSize=sizeof(MENUITEMINFO);
	menuinfo.fMask=MIIM_TYPE|MIIM_ID;
	menuinfo.fType=MFT_STRING;
	menuinfo.fState=MFS_ENABLED;
	menuinfo.dwTypeData=String;
	menuinfo.cch=256;
	sprintf(String," ");
	HMENU hSubMenu=GetSubMenu(hMenu,0);
	InsertMenuItem(hSubMenu,MenuLocOfUsedFiles,TRUE,&menuinfo);
	hSubMenu=CreateMenu();
	if (strlen(LastRoms[0])==0) {
		menuinfo.wID=ID_FILE_RECENT_DIR;
		sprintf(String," ");
		InsertMenuItem(hSubMenu,0,TRUE,&menuinfo);
	}
	menuinfo.fMask=MIIM_TYPE|MIIM_ID;
	for (count=0;count<RomsToRemember;count++) {
		if (strlen(LastRoms[count])==0) {break;}
		menuinfo.wID=ID_FILE_RECENT_FILE+count;
		sprintf(String,"&%d %s",(count+1) % 10,LastRoms[count]);
		InsertMenuItem(hSubMenu,count,TRUE,&menuinfo);
	}
	ModifyMenu(GetSubMenu(hMenu,0),MenuLocOfUsedFiles,MF_POPUP|MF_BYPOSITION,(DWORD)hSubMenu,GS(MENU_RECENT_ROM));
	if (strlen(LastRoms[0])==0||RomsToRemember==0) EnableMenuItem(GetSubMenu(hMenu,0),MenuLocOfUsedFiles,MF_BYPOSITION|MFS_DISABLED);
	else EnableMenuItem(GetSubMenu(hMenu,0),MenuLocOfUsedFiles,MF_BYPOSITION|MFS_ENABLED);
	}
	CheckMenuItem(hMenu,CurrentSaveSlot,MFS_CHECKED);
	if (LimitFPS) CheckMenuItem(hMenu,ID_SYSTEM_LIMITFPS,MFS_CHECKED);
	if (SpeedCap) CheckMenuItem(hMenu,ID_SYSTEM_SPEEDCAP,MFS_CHECKED);
	if (RecordRGB) CheckMenuItem(hMenu,ID_OPTIONS_RGBREC,MFS_CHECKED);
	if (AutoHide) CheckMenuItem(hMenu,ID_OPTIONS_HIDE_CURSOR,MFS_CHECKED);
	if (VideoToScreen) CheckMenuItem(hMenu,ID_OPTIONS_VideoToScreen,MFS_CHECKED);
	if (CreateStatusBar) CheckMenuItem(hMenu,ID_OPTIONS_CREATE_STATUS_BAR,MFS_CHECKED);
	if (UsuallyonTop) CheckMenuItem(hMenu,ID_OPTIONS_UsuallyonTop,MFS_CHECKED);
	if (strcmp(AudioDLL,"No Audio.dll")!=0) EnableMenuItem(hMenu,ID_OPTIONS_CONFIG_AUDIO,AiDllConfig==0?MF_GRAYED:MF_ENABLED);
	EnableMenuItem(hMenu,ID_OPTIONS_CONFIG_GFX,GFXDllConfig==0?MF_GRAYED:MF_ENABLED);
	EnableMenuItem(hMenu,ID_OPTIONS_CONFIG_CONTROL,ContConfig==0?MF_GRAYED:MF_ENABLED);
	State=CPURunning?MFS_ENABLED:MFS_DISABLED;
	EnableMenuItem(hMenu,ID_FILE_ENDEMULATION,State);
	EnableMenuItem(hMenu,ID_CPU_RESET,State);
	EnableMenuItem(hMenu,ID_CPU_PAUSE,State);
	EnableMenuItem(hMenu,ID_SYSTEM_ALTERNATEPAUSE,State);
	EnableMenuItem(hMenu,ID_OPTIONS_CHEATS,State);
	EnableMenuItem(hMenu,ID_CPU_SAVE,State);
	EnableMenuItem(hMenu,ID_CPU_SAVEAS,State);
	EnableMenuItem(hMenu,ID_CPU_RESTORE,State);
	EnableMenuItem(hMenu,ID_CPU_LOAD,State);
	EnableMenuItem(hMenu,ID_SYSTEM_GSBUTTON,State);
	EnableMenuItem(hMenu,ID_OPTIONS_GAMECAPTURE,State);	
	if (CaptureScreen!=0||!VideoToScreen) EnableMenuItem(hMenu,ID_SYSTEM_GENERATEBITMAP,State);
	if (ChangeWindow!=0) EnableMenuItem(hMenu,ID_OPTIONS_FULLSCREEN,State);
	EnableMenuItem(GetSubMenu(hMenu,1),13,State|MF_BYPOSITION);
	State=CPURunning?MFS_DISABLED:MFS_ENABLED;
	EnableMenuItem(hMenu,ID_FILE_REFRESHROMLIST,State);
	if (SyncGametoAudio) {
		EnableMenuItem(hMenu,ID_SYSTEM_LIMITFPS,State);
		EnableMenuItem(hMenu,ID_SYSTEM_SPEEDCAP,State);
	}
	if (strlen(LastRoms[0])>0) EnableMenuItem(hMenu,ID_FILE_STARTEMULATION,State);
	if (strlen(RomName)>0) {
		EnableMenuItem(hMenu,ID_FILE_ROM_INFO,MFS_ENABLED);
		EnableMenuItem(hMenu,ID_OPTIONS_CHEATS,MFS_ENABLED);
	}
	hMainMenu=hMenu;
}
void SetCurrentSaveState (HWND hWnd,int State) {
	char String[256];
	HMENU hMenu;
	hMenu=GetMenu(hWnd);
	if (!CPURunning) State=ID_CURRENTSAVE_DEFAULT;
	CheckMenuItem(hMenu,ID_CURRENTSAVE_DEFAULT,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_2,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_3,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_4,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_5,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_6,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_7,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_8,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_9,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_10,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_11,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_12,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_13,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_14,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_15,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_16,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_17,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_18,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_19,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_20,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_21,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_22,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_23,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_24,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_25,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_26,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_27,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_28,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_29,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,ID_CURRENTSAVE_30,MF_BYCOMMAND|MFS_UNCHECKED);
	CheckMenuItem(hMenu,State,MF_BYCOMMAND|MFS_CHECKED);
	strcpy(CurrentSave,RomName);
	switch (State) {
	case ID_CURRENTSAVE_DEFAULT:
		strcat(CurrentSave," 01.st");
		break;
	case ID_CURRENTSAVE_2:
		strcat(CurrentSave," 02.st");
		break;
	case ID_CURRENTSAVE_3:
		strcat(CurrentSave," 03.st");
		break;
	case ID_CURRENTSAVE_4:
		strcat(CurrentSave," 04.st");
		break;
	case ID_CURRENTSAVE_5:
		strcat(CurrentSave," 05.st");
		break;
	case ID_CURRENTSAVE_6:
		strcat(CurrentSave," 06.st");
		break;
	case ID_CURRENTSAVE_7:
		strcat(CurrentSave," 07.st");
		break;
	case ID_CURRENTSAVE_8:
		strcat(CurrentSave," 08.st");
		break;
	case ID_CURRENTSAVE_9:
		strcat(CurrentSave," 09.st");
		break;
	case ID_CURRENTSAVE_10:
		strcat(CurrentSave," 10.st");
		break;
	case ID_CURRENTSAVE_11:
		strcat(CurrentSave," 11.st");
		break;
	case ID_CURRENTSAVE_12:
		strcat(CurrentSave," 12.st");
		break;
	case ID_CURRENTSAVE_13:
		strcat(CurrentSave," 13.st");
		break;
	case ID_CURRENTSAVE_14:
		strcat(CurrentSave," 14.st");
		break;
	case ID_CURRENTSAVE_15:
		strcat(CurrentSave," 15.st");
		break;
	case ID_CURRENTSAVE_16:
		strcat(CurrentSave," 16.st");
		break;
	case ID_CURRENTSAVE_17:
		strcat(CurrentSave," 17.st");
		break;
	case ID_CURRENTSAVE_18:
		strcat(CurrentSave," 18.st");
		break;
	case ID_CURRENTSAVE_19:
		strcat(CurrentSave," 19.st");
		break;
	case ID_CURRENTSAVE_20:
		strcat(CurrentSave," 20.st");
		break;
	case ID_CURRENTSAVE_21:
		strcat(CurrentSave," 21.st");
		break;
	case ID_CURRENTSAVE_22:
		strcat(CurrentSave," 22.st");
		break;
	case ID_CURRENTSAVE_23:
		strcat(CurrentSave," 23.st");
		break;
	case ID_CURRENTSAVE_24:
		strcat(CurrentSave," 24.st");
		break;
	case ID_CURRENTSAVE_25:
		strcat(CurrentSave," 25.st");
		break;
	case ID_CURRENTSAVE_26:
		strcat(CurrentSave," 26.st");
		break;
	case ID_CURRENTSAVE_27:
		strcat(CurrentSave," 27.st");
		break;
	case ID_CURRENTSAVE_28:
		strcat(CurrentSave," 28.st");
		break;
	case ID_CURRENTSAVE_29:
		strcat(CurrentSave," 29.st");
		break;
	case ID_CURRENTSAVE_30:
		strcat(CurrentSave," 30.st");
	}
	sprintf(String,"%s",CurrentSave);
	SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)String);
	CurrentSaveSlot=State;
}
void HandleModal1 (HWND hWnd) {
	if (inFullScreen) {
		if (strcmp(GfxDLL,"Icepir8sLegacyLLE.dll")!=0) ShowCursor(TRUE);
		SendMessage(hWnd,WM_COMMAND,ID_OPTIONS_FULLSCREEN,0);
	}
	if (UsuallyonTop) {
		if (hManageWindow) SetWindowPos(hManageWindow,HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOREPOSITION|SWP_NOSIZE);
		SetWindowPos(hWnd,HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOREPOSITION|SWP_NOSIZE);
	}
	EnableWindow(hWnd,FALSE);
}
void HandleModal2 (HWND hWnd) {
	UsuallyonTopWindow(hWnd);
	SetForegroundWindow(hWnd);
	EnableWindow(hWnd,TRUE);
}
void TerminatePreviousInstance () {
	TCHAR exe[MAX_PATH];
	GetModuleFileName(0,exe,MAX_PATH);
	LPCTSTR name=_tcsrchr(exe,'\\');
	name=name?name+1:exe;
	HANDLE s=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
	if (s==INVALID_HANDLE_VALUE) return;
	PROCESSENTRY32 e={0};
	e.dwSize=sizeof(e);
	DWORD pid=GetCurrentProcessId(),foundPID=0;
	int matchCount=0;
	if (Process32First(s,&e)) do {
		if (!_tcsicmp(e.szExeFile,name)&&e.th32ProcessID!=pid) {
			HANDLE p=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,e.th32ProcessID);
			if (p) {
				if (!matchCount++) foundPID=e.th32ProcessID;
				CloseHandle(p);
			}
		}
	} while (Process32Next(s,&e));
	CloseHandle(s);
	if (matchCount==1) {
		int result=MessageBox(0,GS(EXTRA_PROJECT64),AppName,MB_YESNOCANCEL|MB_ICONQUESTION|MB_SETFOREGROUND);
		if (result==IDCANCEL) ExitProcess(0);
		if (result==IDNO) return;
		HANDLE p=OpenProcess(PROCESS_TERMINATE,FALSE,foundPID);
		if (p) {
			TerminateProcess(p,0);
			CloseHandle(p);
		}
	}
}
int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpszArgs,int nWinMode) {
	const char*regPaths[]={"PJ64 V 1.6.2\\Jabo Ver1.6.2 Regs\\Direct3D8 1.6.2","PJ64 V 1.6.2\\Jabo Ver1.6.2 Regs\\DirectInput7 1.6.2   ",};
	int screenHeight=GetSystemMetrics(SM_CYSCREEN),screenWidth=GetSystemMetrics(SM_CXSCREEN),i;
	char*IniFile,String[256],String2[256],title[256];
	HKEY hKeyResults;	
	DWORD dwDataTF=0x00000000,dwDataFSH1080p=0x00000438,dwDataFSW1080pFSH25K=0x000005a0,dwDataFSW25K=0X00000780,dwDataOPT1080p=0x00000804,dwDataFSF=0x00000016,dwData960pHeight=0x000003c0,dwData960pWidth=0x00000500,dwDataOPT960p=0x00000807,dwDataRange=0x0000003f,dwDisposition;
	sprintf(String,"PJ64 V 1.6.2\\Configuration");
	LoadLanguage(String);
	TerminatePreviousInstance();
	HANDLE hJob=CreateJobObject(0,0);
	JOBOBJECT_BASIC_UI_RESTRICTIONS jbur={0};
	jbur.UIRestrictionsClass=JOB_OBJECT_UILIMIT_DESKTOP|JOB_OBJECT_UILIMIT_DISPLAYSETTINGS|JOB_OBJECT_UILIMIT_EXITWINDOWS|JOB_OBJECT_UILIMIT_GLOBALATOMS|JOB_OBJECT_UILIMIT_HANDLES|JOB_OBJECT_UILIMIT_READCLIPBOARD|JOB_OBJECT_UILIMIT_SYSTEMPARAMETERS|JOB_OBJECT_UILIMIT_WRITECLIPBOARD;
	if (!SetInformationJobObject(hJob,JobObjectBasicUIRestrictions,&jbur,sizeof(jbur))) CloseHandle(hJob);
	JOBOBJECT_EXTENDED_LIMIT_INFORMATION jeli={0};
	jeli.BasicLimitInformation.LimitFlags=JOB_OBJECT_LIMIT_ACTIVE_PROCESS|JOB_OBJECT_LIMIT_AFFINITY|JOB_OBJECT_LIMIT_DIE_ON_UNHANDLED_EXCEPTION|JOB_OBJECT_LIMIT_JOB_MEMORY|JOB_OBJECT_LIMIT_PRIORITY_CLASS|JOB_OBJECT_LIMIT_PROCESS_MEMORY|JOB_OBJECT_LIMIT_WORKINGSET;
	jeli.BasicLimitInformation.ActiveProcessLimit=1;
	jeli.JobMemoryLimit=100*1024*1024;
	jeli.ProcessMemoryLimit=50*1024*1024;
	jeli.BasicLimitInformation.MinimumWorkingSetSize=10*1024*1024;
	jeli.BasicLimitInformation.MaximumWorkingSetSize=50*1024*1024;
	jeli.BasicLimitInformation.Affinity=1;
	jeli.BasicLimitInformation.PriorityClass=NORMAL_PRIORITY_CLASS;
	if (!SetInformationJobObject(hJob,JobObjectExtendedLimitInformation,&jeli,sizeof(jeli))) CloseHandle(hJob);
	JOBOBJECT_SECURITY_LIMIT_INFORMATION jsl={0};
	jsl.SecurityLimitFlags=JOB_OBJECT_SECURITY_NO_ADMIN|JOB_OBJECT_SECURITY_RESTRICTED_TOKEN|JOB_OBJECT_SECURITY_ONLY_TOKEN|JOB_OBJECT_SECURITY_FILTER_TOKENS;
	if (!SetInformationJobObject(hJob,JobObjectSecurityLimitInformation,&jsl,sizeof(jsl))) CloseHandle(hJob);
	if (!AssignProcessToJobObject(hJob,GetCurrentProcess())) CloseHandle(hJob);
	HACCEL AccelWinMode,AccelCPURunning,AccelRomBrowser;
	DWORD X,Y;
	MSG msg;
	if (!InitializeApplication (hInstance)) return FALSE;
	if (!RegisterWinClass()) return FALSE;
	if (screenHeight>=1440&&screenWidth>=1920) {
  		X=(GetSystemMetrics(SM_CXSCREEN)-1280)/2;
		Y=(GetSystemMetrics(SM_CYSCREEN)-960)/2;
	} else if (screenHeight>=1080&&screenWidth>=1440) {
		X=(GetSystemMetrics(SM_CXSCREEN)-800)/2;
		Y=(GetSystemMetrics(SM_CYSCREEN)-600)/2;
	} else {
		X=(GetSystemMetrics(SM_CXSCREEN)-640)/2;
		Y=(GetSystemMetrics(SM_CYSCREEN)-480)/2;
	}
	AccelWinMode   =LoadAccelerators(hInst,MAKEINTRESOURCE(IDR_WINDOWMODE));
	AccelCPURunning=LoadAccelerators(hInst,MAKEINTRESOURCE(IDR_CPURUNNING));
	AccelRomBrowser=LoadAccelerators(hInst,MAKEINTRESOURCE(IDR_ROMBROWSER));
	hHiddenWindow=CreateWindow(AppName,AppName,WS_OVERLAPPED|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_SYSMENU|WS_MINIMIZEBOX,X,Y,4,3,0,0,hInst,0);
	if (!hHiddenWindow) return FALSE;
	IniFile=GetIniFileName();
	_GetPrivateProfileString("Meta","Version","",String,sizeof(String),IniFile);
	_GetPrivateProfileString("Meta","Date","",String2,sizeof(String2),IniFile);
	if (strlen(String)==0) strcpy(String,"UNKNOWN VERSION");
	if (strlen(String2)==0) strcpy(String2,"UNKNOWN DATE");
	sprintf(title,"%s V%s %s",AppName,String,String2);
	hMainWindow=CreateWindow(AppName,title,WS_OVERLAPPED|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_SYSMENU|WS_MINIMIZEBOX,X,Y,4,3,0,0,hInst,0);
	DragAcceptFiles(hMainWindow,TRUE);
	if (!hMainWindow) return FALSE;
	for (i=0;i<sizeof(regPaths) / sizeof(regPaths[0]);++i) {
		LONG lRet=RegOpenKeyEx(HKEY_CURRENT_USER,regPaths[i],0,KEY_READ,&hKeyResults);
		if (lRet!=ERROR_SUCCESS) {
			lRet=RegCreateKeyEx(HKEY_CURRENT_USER,regPaths[i],0,0,REG_OPTION_NON_VOLATILE,KEY_WRITE,0,&hKeyResults,&dwDisposition);
			if (lRet==ERROR_SUCCESS) {
				if (strstr(regPaths[i],"8")) {
					RegSetValueEx(hKeyResults,"Full Screen Format",0,REG_DWORD,(const BYTE*)&dwDataFSF,sizeof(dwDataFSF));
					if (screenHeight>=1440&&screenWidth>=1920) {
						RegSetValueEx(hKeyResults,"Full Screen Height",0,REG_DWORD,(const BYTE*)&dwDataFSW1080pFSH25K,sizeof(dwDataFSW1080pFSH25K));
						RegSetValueEx(hKeyResults,"Full Screen Width",0,REG_DWORD,(const BYTE*)&dwDataFSW25K,sizeof(dwDataFSW25K));
						RegSetValueEx(hKeyResults,"Options",0,REG_DWORD,(const BYTE*)&dwDataOPT960p,sizeof(dwDataOPT960p));
					} else if (screenHeight>=1080&&screenWidth>=1440) {
						RegSetValueEx(hKeyResults,"Full Screen Height",0,REG_DWORD,(const BYTE*)&dwDataFSH1080p,sizeof(dwDataFSH1080p));
						RegSetValueEx(hKeyResults,"Full Screen Width",0,REG_DWORD,(const BYTE*)&dwDataFSW1080pFSH25K,sizeof(dwDataFSW1080pFSH25K));
						RegSetValueEx(hKeyResults,"Options",0,REG_DWORD,(const BYTE*)&dwDataOPT1080p,sizeof(dwDataOPT1080p));
					} else if (screenHeight>=960&&screenWidth>=1280&&strstr(regPaths[i],"8")) {
					RegSetValueEx(hKeyResults,"Full Screen Height",0,REG_DWORD,(const BYTE*)&dwData960pHeight,sizeof(dwData960pHeight));
					RegSetValueEx(hKeyResults,"Full Screen Width",0,REG_DWORD,(const BYTE*)&dwData960pWidth,sizeof(dwData960pWidth));
					}
				}
				if (strstr(regPaths[i],"7")) {
					RegSetValueEx(hKeyResults,"Range(0)",0,REG_DWORD,(const BYTE*)&dwDataRange,sizeof(dwDataRange));
					RegSetValueEx(hKeyResults,"Range(1)",0,REG_DWORD,(const BYTE*)&dwDataRange,sizeof(dwDataRange));
					RegSetValueEx(hKeyResults,"Range(2)",0,REG_DWORD,(const BYTE*)&dwDataRange,sizeof(dwDataRange));
					RegSetValueEx(hKeyResults,"Range(3)",0,REG_DWORD,(const BYTE*)&dwDataRange,sizeof(dwDataRange));
				}
				RegCloseKey(hKeyResults);
				FirstBoot=TRUE;
			}
		}
	}
	if (FirstBoot) {
		char IntroMessage[99];
#ifdef CLASSIC_PLUGINS
#define PLUGINS "Classic Plugins - Project64.exe uses Jabo Video/Audio/Input as default plugins for old PC's and classic ROMhacks (mostly hacks up to year 2020). Switching to GLideN64 is necessary for all modern-day ROMhacks."
#elif MODERN_PLUGINS
#define PLUGINS "Modern Plugins - Project64_Modern.exe uses GLideN64 Video, Azi Audio, and N-Rage's Input as default plugins for modern PC's and modern ROMhacks. Switching to Jabo's D3D8 is necessary for most legacy ROMhacks."
#endif
		sprintf(IntroMessage,"Project64 1.6.2 is a personal update of Project64 1.6.1 made to enjoy retail and ROMhack games with most PC's.\n\n\n%s\n\n\nSee User Guide for my contact info and helpful information, especially regarding personal/legal usage, plugin details, running ROMhacks, using the ROM Browser/ROM Notes system, and Advanced Settings. Please be patient if expecting a response from contacting me as I am usually quite busy. Credits are found towards the very bottom of Visual Studio Source Code/Main.h (view from Visual Studio with the .vcxproj file or open with a notepad app) and the User Guide.\n\n\n- Edwin Bruce Shankle IV\n\nP.S. I'll be taking time to focus on other N64 projects and my personal well being before managing production of version 27! If you want an updated version of my build, you'll have to do it yourself by modifying the included visual studio source code. I suggest building this project using the v120_xp toolset from installing Visual Studio Community 2013 until I'm around to develop and release another update of my project again. Sorry for this inconvenience and good luck with your usage of this application playing retail and ROMhacked retail games",PLUGINS);
		MessageBox(0,IntroMessage,AppName,MB_OK|MB_ICONINFORMATION|MB_SETFOREGROUND);
	}
	ShowWindow(hMainWindow,SW_SHOW);
	SetupMenu(hMainWindow); // For recent lists with __argc>1/Open ROM from extension association and to display menu options ASAP
	if (__argc>1) {
		strcpy(CurrentFileName,__argv[1]);
		OpenChosenFile();
	}
	if (!CPURunning) OpenRomBrowser(); // Load ROM Browser if initial startup or Open ROM from extension association failed
	while (GetMessage(&msg,0,0,0)) {
		if (!CPURunning&&TranslateAccelerator(hMainWindow,AccelRomBrowser,&msg)) continue;
		if (CPURunning) {
			if (TranslateAccelerator(hMainWindow,AccelCPURunning,&msg)) continue;
			if (!inFullScreen&&TranslateAccelerator(hMainWindow,AccelWinMode,&msg)) continue;
		}
		if (IsDialogMessage(hManageWindow,&msg)) continue;
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	CloseHandle(hJob);
	ShutdownApplication();
	return msg.wParam;
}