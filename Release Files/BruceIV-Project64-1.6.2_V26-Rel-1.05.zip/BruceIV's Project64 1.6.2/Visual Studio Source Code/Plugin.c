/*
*Project64 - A Nintendo 64 emulator.
*
*(c) Copyright 2001 zilmar (zilmar@emulation64.com) and
*Jabo (jabo@emulation64.com).
*
*pj64 homepage: www.pj64.net
*
*Permission to use, copy, modify and distribute Project64 in both binary and
*source form, for non-commercial purposes, is hereby granted without fee,
*providing that this license information and copyright notice appear with
*all copies and any derived work.
*
*This software is provided 'as-is', without any express or implied
*warranty. In no event shall the authors be held liable for any damages
*arising from the use of this software.
*
*Project64 is freeware for PERSONAL USE only. Commercial users should
*seek permission of the copyright holders first. Commercial use includes
*charging money for Project64 or software derived from Project64.
*
*The copyright holders request that bug fixes and improvements to the code
*should be forwarded to them so if they want them.
*
*/
#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#include "Main.h"
#include "Cheat.h"
#include "CPU.h"
#include "ROM.h"
#include "Plugin.h"
#include "Resource.h"
char RSPDLL[100],GfxDLL[100],AudioDLL[100],ControllerDLL[100],*PluginNames[MaxDlls];
HINSTANCE hAudioDll,hControllerDll,hGfxDll,hRSPDLL;
DWORD PluginCount,RspTaskValue,AudioIntrReg;
WORD RSPVersion,ContVersion;
HANDLE hAudioThread=0;
CONTROL Controllers[4];
BOOL PluginsInitialized=FALSE,GLideN64NeedsToBeSetupFirst=FALSE,GonetzGLHasBeenSetupFirst=FALSE,PluginsChanged(HWND hDlg),ValidPluginVersion(PLUGIN_INFO*PluginInfo);
void AudioThread () {
	SetThreadPriority(GetCurrentThread(),THREAD_PRIORITY_TIME_CRITICAL);
	for (;;) {AiUpdate(TRUE);}
}
void GetPluginDir(char*Directory) {
	char path_buffer[_MAX_PATH],drive[_MAX_DRIVE],dir[_MAX_DIR],fname[_MAX_FNAME],ext[_MAX_EXT];
	GetModuleFileName(0,path_buffer,sizeof(path_buffer));
	_splitpath(path_buffer,drive,dir,fname,ext);
	strcpy(Directory,drive);
	strcat(Directory,dir);
	strcat(Directory,"Plugin\\");
}
void FetchScreenAndVideoDir(char*Directory) {
	char path_buffer[_MAX_PATH],drive[_MAX_DRIVE],dir[_MAX_DIR],fname[_MAX_FNAME],ext[_MAX_EXT],Dir[256],Group[200];
	long lResult;
	HKEY hKeyResults=0;
	GetModuleFileName(0,path_buffer,sizeof(path_buffer));
	_splitpath(path_buffer,drive,dir,fname,ext);
	sprintf(Directory,"%s%sScreenshots and Videos\\",drive,dir);
	sprintf(Group,"PJ64 V 1.6.2\\Configuration");
	lResult=RegOpenKeyEx(HKEY_CURRENT_USER,Group,0,KEY_ALL_ACCESS,&hKeyResults);
	if (lResult==ERROR_SUCCESS) {
		DWORD Type,Value,Bytes=4;
		lResult=RegQueryValueEx(hKeyResults,"AppPath Screenshots and Videos",0,&Type,(LPBYTE)(&Value),&Bytes);
		if (lResult==ERROR_SUCCESS) {
			if (Value==FALSE) {
				Bytes=sizeof(Dir);
				lResult=RegQueryValueEx(hKeyResults,"CustomPath Screenshots and Videos",0,&Type,(LPBYTE)Dir,&Bytes);
				if (lResult==ERROR_SUCCESS) {strcpy(Directory,Dir);}
			}
		}
		RegCloseKey(hKeyResults);
	}
	CreateDirectory(Directory,0);
}
BOOL LoadAudioDll(char*AudioDll) {
	PLUGIN_INFO PluginInfo;
	char DllName[300];
	GetPluginDir(DllName);
	strcat(DllName,AudioDll);
	hAudioDll=LoadLibrary(DllName);
	if (hAudioDll==0) return FALSE;
	GetDllInfo=(void (__cdecl*)(PLUGIN_INFO*))GetProcAddress(hAudioDll,"GetDllInfo");
	if (GetDllInfo==0) return FALSE;
	GetDllInfo(&PluginInfo);
	if (!ValidPluginVersion(&PluginInfo)||PluginInfo.MemoryBswaped==FALSE) return FALSE;
	AiCloseDLL=(void (__cdecl*)(void))GetProcAddress(hAudioDll,"CloseDLL");
	if (AiCloseDLL==0) return FALSE;
	AiDacrateChanged=(void (__cdecl*)(int))GetProcAddress(hAudioDll,"AiDacrateChanged");
	if (AiDacrateChanged==0) return FALSE;
	AiLenChanged=(void (__cdecl*)(void))GetProcAddress(hAudioDll,"AiLenChanged");
	if (AiLenChanged==0) return FALSE;
	AiReadLength=(DWORD (__cdecl*)(void))GetProcAddress(hAudioDll,"AiReadLength");
	if (AiReadLength==0) return FALSE;
	InitiateAudio=(BOOL (__cdecl*)(AUDIO_INFO))GetProcAddress(hAudioDll,"InitiateAudio");
	if (InitiateAudio==0) return FALSE;
	AiRomClosed=(void (__cdecl*)(void))GetProcAddress(hAudioDll,"RomClosed");
	if (AiRomClosed==0) return FALSE;
	ProcessAList=(void (__cdecl*)(void))GetProcAddress(hAudioDll,"ProcessAList");
	if (ProcessAList==0) return FALSE;
	AiDllConfig=(void (__cdecl*)(HWND))GetProcAddress(hAudioDll,"DllConfig");
	AiUpdate=(void (__cdecl*)(BOOL))GetProcAddress(hAudioDll,"AiUpdate");
	return TRUE;
}
BOOL LoadControllerDll(char*ControllerDll) {
	PLUGIN_INFO PluginInfo;
	char DllName[300];
	GetPluginDir(DllName);
	strcat(DllName,ControllerDll);
	hControllerDll=LoadLibrary(DllName);
	if (hControllerDll==0) return FALSE;
	GetDllInfo=(void (__cdecl*)(PLUGIN_INFO*))GetProcAddress(hControllerDll,"GetDllInfo");
	if (GetDllInfo==0) return FALSE;
	PluginInfo.MemoryBswaped=TRUE;
	PluginInfo.NormalMemory=TRUE;
	GetDllInfo(&PluginInfo);
	if (!ValidPluginVersion(&PluginInfo)||PluginInfo.MemoryBswaped==FALSE) return FALSE;
	ContVersion=PluginInfo.Version;
	ContCloseDLL=(void (__cdecl*)(void))GetProcAddress(hControllerDll,"CloseDLL");
	if (ContCloseDLL==0) return FALSE;
	if (ContVersion==0x0100) {
		InitiateControllers_1_0=(void (__cdecl*)(HWND,CONTROL*))GetProcAddress(hControllerDll,"InitiateControllers");
		if (InitiateControllers_1_0==0) return FALSE;
	}
	if (ContVersion==0x0101) {
		InitiateControllers_1_1=(void (__cdecl*)(CONTROL_INFO))GetProcAddress(hControllerDll,"InitiateControllers");
		if (InitiateControllers_1_1==0) return FALSE;
	}
	ControllerCommand=(void (__cdecl*)(int,BYTE*))GetProcAddress(hControllerDll,"ControllerCommand");
	ReadController=(void (__cdecl*)(int,BYTE*))GetProcAddress(hControllerDll,"ReadController");
	ContConfig=(void (__cdecl*)(HWND))GetProcAddress(hControllerDll,"DllConfig");
	GetKeys=(void (__cdecl*)(int,BUTTONS*))GetProcAddress(hControllerDll,"GetKeys");
	WM_KeyDown=(void (__cdecl*)(WPARAM,LPARAM))GetProcAddress(hControllerDll,"WM_KeyDown");
	WM_KeyUp=(void (__cdecl*)(WPARAM,LPARAM))GetProcAddress(hControllerDll,"WM_KeyUp");
	ContRomOpen=(void (__cdecl*)(void))GetProcAddress(hControllerDll,"RomOpen");
	ContRomClosed=(void (__cdecl*)(void))GetProcAddress(hControllerDll,"RomClosed");
	RumbleCommand=(void (__cdecl*)(int,BOOL))GetProcAddress(hControllerDll,"RumbleCommand");
	return TRUE;
}
BOOL LoadGFXDll(char*RSPDLL) {
	PLUGIN_INFO PluginInfo;
	char DllName[300];
	GetPluginDir(DllName);
	strcat(DllName,GfxDLL);
	hGfxDll=LoadLibrary(DllName);
	if (hGfxDll==0) return FALSE;
	GetDllInfo=(void (__cdecl*)(PLUGIN_INFO*))GetProcAddress(hGfxDll,"GetDllInfo");
	if (GetDllInfo==0) return FALSE;
	GetDllInfo(&PluginInfo);
	if (!ValidPluginVersion(&PluginInfo)||PluginInfo.MemoryBswaped==FALSE) return FALSE;
	GFXCloseDLL=(void (__cdecl*)(void))GetProcAddress(hGfxDll,"CloseDLL");
	if (GFXCloseDLL==0) return FALSE;
	ChangeWindow=(void (__cdecl*)(void))GetProcAddress(hGfxDll,"ChangeWindow");
	if (ChangeWindow==0) return FALSE;
	GFXDllConfig=(void (__cdecl*)(HWND))GetProcAddress(hGfxDll,"DllConfig");
	if (GFXDllConfig==0) return FALSE;
	InitiateGFX=(BOOL (__cdecl*)(GFX_INFO))GetProcAddress(hGfxDll,"InitiateGFX");
	if (InitiateGFX==0) return FALSE;
	MoveScreen=(void (__cdecl*)(int,int))GetProcAddress(hGfxDll,"MoveScreen");
	if (MoveScreen==0) return FALSE;
	ProcessDList=(void (__cdecl*)(void))GetProcAddress(hGfxDll,"ProcessDList");
	if (ProcessDList==0) return FALSE;
	GfxRomClosed=(void (__cdecl*)(void))GetProcAddress(hGfxDll,"RomClosed");
	if (GfxRomClosed==0) return FALSE;
	GfxRomOpen=(void (__cdecl*)(void))GetProcAddress(hGfxDll,"RomOpen");
	if (GfxRomOpen==0) return FALSE;
	UpdateScreen=(void (__cdecl*)(void))GetProcAddress(hGfxDll,"UpdateScreen");
	if (UpdateScreen==0) return FALSE;
	ViStatusChanged=(void (__cdecl*)(void))GetProcAddress(hGfxDll,"ViStatusChanged");
	if (ViStatusChanged==0) return FALSE;
	ViWidthChanged=(void (__cdecl*)(void))GetProcAddress(hGfxDll,"ViWidthChanged");
	if (ViWidthChanged==0) return FALSE;
	if (PluginInfo.Version>=0x0103) {
		ProcessRDPList=(void (__cdecl*)(void))GetProcAddress(hGfxDll,"ProcessRDPList");
		if (ProcessRDPList==0) return FALSE;
		CaptureScreen=(void (__cdecl*)(char*))GetProcAddress(hGfxDll,"CaptureScreen");
		if (CaptureScreen==0) return FALSE;
		ShowCFB=(void (__cdecl*)(void))GetProcAddress(hGfxDll,"ShowCFB");
		if (ShowCFB==0) return FALSE;
	} else {
		ProcessRDPList=0;
		CaptureScreen=0;
		ShowCFB=0;
	}
	return TRUE;
}
BOOL LoadRSPDLL(char*RSPDLL) {
	PLUGIN_INFO PluginInfo;
	char DllName[300];
	GetPluginDir(DllName);
	strcat(DllName,RSPDLL);
	hRSPDLL=LoadLibrary(DllName);
	if (hRSPDLL==0) return FALSE;
	GetDllInfo=(void (__cdecl*)(PLUGIN_INFO*))GetProcAddress(hRSPDLL,"GetDllInfo");
	if (GetDllInfo==0) return FALSE;
	GetDllInfo(&PluginInfo);
	if (!ValidPluginVersion(&PluginInfo)||PluginInfo.MemoryBswaped==FALSE) return FALSE;
	RSPVersion=PluginInfo.Version;
	if (RSPVersion==1) {RSPVersion=0x0100;}
	DoRspCycles=(DWORD (__cdecl*)(DWORD))GetProcAddress(hRSPDLL,"DoRspCycles");
	if (DoRspCycles==0) return FALSE;
	InitiateRSP_1_0=0;
	InitiateRSP_1_1=0;
	if (RSPVersion==0x100) {
		InitiateRSP_1_0=(void (__cdecl*)(RSP_INFO_1_0,DWORD*))GetProcAddress(hRSPDLL,"InitiateRSP");
		if (InitiateRSP_1_0==0) return FALSE;
	}
	if (RSPVersion==0x101) {
		InitiateRSP_1_1=(void (__cdecl*)(RSP_INFO_1_1,DWORD*))GetProcAddress(hRSPDLL,"InitiateRSP");
		if (InitiateRSP_1_1==0) return FALSE;
	}
	RSPRomClosed=(void (__cdecl*)(void))GetProcAddress(hRSPDLL,"RomClosed");
	if (RSPRomClosed==0) return FALSE;
	RSPCloseDLL=(void (__cdecl*)(void))GetProcAddress(hRSPDLL,"CloseDLL");
	if (RSPCloseDLL==0) return FALSE;
	return TRUE;
}
void HandlePluginsAndEmulationStartup () {
	int FAIL_MSG;
	long lResult;
	char String[256];
	static DWORD AI_DUMMY=0;
	DWORD NewRAMsize;
	HKEY hKeyResults=0;
	HWND hWnd;
	sprintf(String,"PJ64 V 1.6.2\\Configuration");
	lResult=RegOpenKeyEx(HKEY_CURRENT_USER,String,0,KEY_ALL_ACCESS,&hKeyResults);
	if (lResult==ERROR_SUCCESS) {
		DWORD Type,Bytes=100;
		if (!inFullScreen) {
			lResult=RegQueryValueEx(hKeyResults,"Graphics Dll",0,&Type,(LPBYTE)(GfxDLL),&Bytes);
			if (lResult!=ERROR_SUCCESS) sprintf(GfxDLL,"%s",DefaultGFXDll);
		}
		Bytes=100;
		lResult=RegQueryValueEx(hKeyResults,"Audio Dll",0,&Type,(LPBYTE)(AudioDLL),&Bytes);
		if (lResult!=ERROR_SUCCESS) sprintf(AudioDLL,"%s",DefaultAudioDll);
		Bytes=100;
		lResult=RegQueryValueEx(hKeyResults,"Controller Dll",0,&Type,(LPBYTE)(ControllerDLL),&Bytes);
		if (lResult!=ERROR_SUCCESS) sprintf(ControllerDLL,"%s",DefaultControllerDll);
		Bytes=100;
		lResult=RegQueryValueEx(hKeyResults,"RSP Dll",0,&Type,(LPBYTE)(RSPDLL),&Bytes);
		if (lResult!=ERROR_SUCCESS) sprintf(RSPDLL,"%s",DefaultRSPDLL);
		RegCloseKey(hKeyResults);
	} else {
		sprintf(RSPDLL,"%s",DefaultRSPDLL);
		sprintf(GfxDLL,"%s",DefaultGFXDll);
		sprintf(AudioDLL,"%s",DefaultAudioDll);
		sprintf(ControllerDLL,"%s",DefaultControllerDll);
	}
	if (strcmp(GfxDLL,"Jabo_Direct3D8.dll")==0&&strcmp(RSPDLL,"Icepir8sLegacyRSP.dll")==0) strcpy(RSPDLL,"RSP.dll");
	SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(PLUGINS_INITIALIZING));
	if (CPURunning) {
		ReadRomSettings();
		if (RomProtectMemoryEnlargeBuffer==0) ProtectMemoryEnlargeBuffer=SystemProtectMemoryEnlargeBuffer;
		else ProtectMemoryEnlargeBuffer=RomProtectMemoryEnlargeBuffer;
		if (ProtectMemoryEnlargeBuffer==PROTECT_MEMORY_ENLARGE_BUFFER_ON) {
			if (VirtualAlloc(RecompCode,0x03200000,MEM_COMMIT,PAGE_EXECUTE_READWRITE)==0) { // Performance
				DisplayError(GS(MSG_MEM_ALLOC_ERROR));
				OpenRomBrowser();
				return;
			}
		} else {
			VirtualFree(RecompCode,0x03200000,MEM_DECOMMIT);
			if (VirtualAlloc(RecompCode,0x01400000,MEM_COMMIT,PAGE_EXECUTE_READWRITE)==0) {
				DisplayError(GS(MSG_MEM_ALLOC_ERROR));
				OpenRomBrowser();
				return;
			}
		}
		JumperPak=RomJumperPak;
		if (JumperPak) NewRAMsize=0x400000;
		else NewRAMsize=0x800000;
		if (NewRAMsize!=RDRAMsize) {
			if (RDRAMsize==0x400000) {
				if (VirtualAlloc(N64MEM+0x400000,0x400000,MEM_COMMIT,PAGE_READWRITE)==0) {
					DisplayError(GS(MSG_MEM_ALLOC_ERROR));
					OpenRomBrowser();
					return;
				}
				if (VirtualAlloc((BYTE*)JumpTable+0x400000,0x400000,MEM_COMMIT,PAGE_READWRITE)==0) {
					DisplayError(GS(MSG_MEM_ALLOC_ERROR));
					OpenRomBrowser();
					return;
				}
				if (VirtualAlloc((BYTE*)DelaySlotTable+(0x400000>>0xA),(0x400000>>0xA),MEM_COMMIT,PAGE_READWRITE)==0) {
					DisplayError(GS(MSG_MEM_ALLOC_ERROR));
					OpenRomBrowser();
					return;
				}
			} else {
				VirtualFree(N64MEM+0x400000,0x400000,MEM_DECOMMIT);
				VirtualFree((BYTE*)JumpTable+0x400000,0x400000,MEM_DECOMMIT);
				VirtualFree((BYTE*)DelaySlotTable+(0x400000>>0xA),(0x400000>>0xA),MEM_DECOMMIT);
			}
		}
		if (RomSaveUsing==Default) {
			// This masks most auto save type issues to extend compatibility for ROMhacks. The reason why it is still set manually per Game.ini is for hacks with custom internal name and shared CRC.
			if (strcmp(RomName,"CONKER BFD")==0||strcmp(RomName,"DRACULA MOKUSHIROKU")==0||strcmp(RomName,"DRACULA MOKUSHIROKU2")==0||strcmp(RomName,"BANJO KAZOOIE 2")==0||strcmp(RomName,"BANJO TOOIE")==0||strcmp(RomName,"CRUIS'N WORLD")==0||strcmp(RomName,"CUSTOMROBOV2")==0||strcmp(RomName,"DONKEY KONG 64")==0||strcmp(RomName,"霓状虞2 硕厣驾棉�")==0||strcmp(RomName,"霓状虞3 伤蘩上罶OS!")==0||strcmp(RomName,"EXCITEBIKE64")==0||strcmp(RomName,"裁拗辰股习嫁嫁")==0||strcmp(RomName,"NBA COURTSIDE")==0||strcmp(RomName,"Madden NFL 2002")==0||strcmp(RomName,"MarioParty3")==0||strcmp(RomName,"MarioTennis")==0||strcmp(RomName,"MarioTennis64")==0||strcmp(RomName,"EVANGELION")==0||strcmp(RomName,"Parlor PRO 64")==0||strcmp(RomName,"Ultraman Battle JAPA")==0||strcmp(RomName,"Perfect Dark")==0||strcmp(RomName,"RIDGE RACER 64")==0||strcmp(RomName,"Robopon 64")==0||strcmp(RomName,"STAR WARS EP1 RACER")==0||strcmp(RomName,"YOSHI STORY")==0) SaveUsing=EEPROM_16K;
			else if (strcmp(RomName,"THE LEGEND OF ZELDA")==0) SaveUsing=SRAM;
			else if (strcmp(RomName,"NBA Courtside 2")==0||strcmp(RomName,"POKEMON STADIUM")==0) SaveUsing=FlashRAM;
			else SaveUsing=Default;
		} else SaveUsing=RomSaveUsing;
		if (RomCF==0) CountPerOp=SystemCF;
		else CountPerOp=RomCF;
		SyncGametoAudio=RomSyncGametoAudio;
		if (SyncGametoAudio) LimitFPS=TRUE;
		if (strcmp(AudioDLL,"No Audio.dll")==0||RomJAI||RomShankleAziAI) EmulateAI=TRUE;
		else EmulateAI=FALSE;
		AlignDMA=RomAlignDMA;
		DelayRDP=RomDelayRDP;
		AudioSignal=RomAudioSignal;
		DelayRSP=RomDelayRSP;
		VirtualSD=RomVirtualSD;
		FiftyNineHertz=RomFiftyNineHertz;
		DelaySI=RomDelaySI;
		SkipBps=RomSkipBps;
		CpuRecompiler=RomCpuRecompiler;
		CCMod=RomCCMod;
		UseTLB=RomUseTLB;
		Lag=RomLag;
		if (RomUseCache==0) UseCache=SystemUseCache;
		else UseCache=RomUseCache;
		if (SkipAudioClear) ApplySkipAudioClear=TRUE;
		else ApplySkipAudioClear=FALSE;
		hWnd=hMainWindow;
		LoadCheats();
		if (!inFullScreen) {
			if (strcmp(GfxDLL,"Icepir8sLegacyLLE.dll")==0) {
				if (GonetzGLHasBeenSetupFirst) goto SIZE_MAXIMIZE;
				else {
					GLideN64NeedsToBeSetupFirst=TRUE;
					strcpy(GfxDLL,"GLideN64.dll");
				}
			} else {
				SetWindowLong(hMainWindow,GWL_STYLE,GetWindowLong(hMainWindow,GWL_STYLE)&~(WS_SIZEBOX|WS_MAXIMIZEBOX));
				DrawMenuBar(hMainWindow);
			}
		}
	} else {
		hWnd=hHiddenWindow;
		SIZE_MAXIMIZE: SetWindowLong(hMainWindow,GWL_STYLE,GetWindowLong(hMainWindow,GWL_STYLE)|WS_SIZEBOX|WS_MAXIMIZEBOX);
	}
	ShutdownPlugins();
	PluginsInitialized=TRUE;
	if (!inFullScreen) {
		if (!LoadGFXDll(GfxDLL)) {
			if (GLideN64NeedsToBeSetupFirst) goto DONE_INIT_GLideN64;
			FAIL_MSG=MSG_FAIL_INIT_GFX;
			PluginsInitialized=FALSE;
		} else {
			GFX_INFO GfxInfo;
			GfxInfo.MemoryBswaped=TRUE;
			GfxInfo.CheckInterrupts=CheckInterrupts;
			GfxInfo.hStatusBar=hStatusWnd;
			GfxInfo.hWnd=hWnd;
			GfxInfo.HEADER=RomHeader;
			GfxInfo.RDRAM=N64MEM;
			GfxInfo.DMEM=DMEM;
			GfxInfo.IMEM=IMEM;
			GfxInfo.MI__INTR_REG=&MI_INTR_REG;
			GfxInfo.DPC__START_REG=&DPC_START_REG;
			GfxInfo.DPC__END_REG=&DPC_END_REG;
			GfxInfo.DPC__CURRENT_REG=&DPC_CURRENT_REG;
			GfxInfo.DPC__STATUS_REG=&DPC_STATUS_REG;
			GfxInfo.DPC__CLOCK_REG=&DPC_CLOCK_REG;
			GfxInfo.DPC__BUFBUSY_REG=&DPC_BUFBUSY_REG;
			GfxInfo.DPC__PIPEBUSY_REG=&DPC_PIPEBUSY_REG;
			GfxInfo.DPC__TMEM_REG=&DPC_TMEM_REG;
			GfxInfo.VI__STATUS_REG=&VI_STATUS_REG;
			GfxInfo.VI__ORIGIN_REG=&VI_ORIGIN_REG;
			GfxInfo.VI__WIDTH_REG=&VI_WIDTH_REG;
			GfxInfo.VI__INTR_REG=&VI_INTR_REG;
			GfxInfo.VI__V_CURRENT_LINE_REG=&VI_CURRENT_REG;
			GfxInfo.VI__TIMING_REG=&VI_TIMING_REG;
			GfxInfo.VI__V_SYNC_REG=&VI_V_SYNC_REG;
			GfxInfo.VI__H_SYNC_REG=&VI_H_SYNC_REG;
			GfxInfo.VI__LEAP_REG=&VI_LEAP_REG;
			GfxInfo.VI__H_START_REG=&VI_H_START_REG;
			GfxInfo.VI__V_START_REG=&VI_V_START_REG;
			GfxInfo.VI__V_BURST_REG=&VI_V_BURST_REG;
			GfxInfo.VI__X_SCALE_REG=&VI_X_SCALE_REG;
			GfxInfo.VI__Y_SCALE_REG=&VI_Y_SCALE_REG;
			if (!InitiateGFX(GfxInfo)) {
				if (GLideN64NeedsToBeSetupFirst) goto DONE_INIT_GLideN64;
				FAIL_MSG=MSG_FAIL_INIT_GFX;
				PluginsInitialized=FALSE;
			}
		}
		if (GLideN64NeedsToBeSetupFirst) goto StartEmulation;
	}
	if (!LoadAudioDll(AudioDLL)) {
		AiCloseDLL=0;
		AiDacrateChanged=0;
		AiLenChanged=0;
		AiReadLength=0;
		AiUpdate=0;
		InitiateAudio=0;
		ProcessAList=0;
		AiRomClosed=0;
		FAIL_MSG=MSG_FAIL_INIT_AUDIO;
		PluginsInitialized=FALSE;
	} else {
		AUDIO_INFO AudioInfo;
		AudioInfo.hwnd=hWnd;
		AudioInfo.hinst=hInst;
		AudioInfo.MemoryBswaped=TRUE;
		AudioInfo.HEADER=RomHeader;
		AudioInfo.RDRAM=N64MEM;
		AudioInfo.DMEM=DMEM;
		AudioInfo.IMEM=IMEM;
		if (EmulateAI) AudioInfo.MI__INTR_REG=&AI_DUMMY;
		else AudioInfo.MI__INTR_REG=&AudioIntrReg;
		AudioInfo.AI__DRAM_ADDR_REG=&AI_DRAM_ADDR_REG;
		AudioInfo.AI__LEN_REG=&AI_LEN_REG;
		AudioInfo.AI__CONTROL_REG=&AI_CONTROL_REG;
		if (EmulateAI||SyncGametoAudio) AudioInfo.AI__STATUS_REG=&AI_DUMMY;
		else AudioInfo.AI__STATUS_REG=&AI_STATUS_REG;
		AudioInfo.AI__DACRATE_REG=&AI_DACRATE_REG;
		AudioInfo.AI__BITRATE_REG=&AI_BITRATE_REG;
		AudioInfo.CheckInterrupts=AiCheckInterrupts;
		if (EmulateAI) EmuAI_InitializePluginHook();
		if (!InitiateAudio(AudioInfo)) {
			AiCloseDLL=0;
			AiDacrateChanged=0;
			AiLenChanged=0;
			AiReadLength=0;
			AiUpdate=0;
			InitiateAudio=0;
			ProcessAList=0;
			AiRomClosed=0;
			FAIL_MSG=MSG_FAIL_INIT_AUDIO;
			PluginsInitialized=FALSE;
		}
		if (AiUpdate&&PluginsInitialized) hAudioThread=CreateThread(0,0,(LPTHREAD_START_ROUTINE)AudioThread,(LPVOID)0,0,0);
	}
	if (!LoadControllerDll(ControllerDLL)) {
		FAIL_MSG=MSG_FAIL_INIT_CONTROL;
		PluginsInitialized=FALSE;
	} else {
		Controllers[0].Present=FALSE;
		Controllers[0].RawData=FALSE;
		Controllers[0].Plugin=PLUGIN_NONE;
		Controllers[1].Present=FALSE;
		Controllers[1].RawData=FALSE;
		Controllers[1].Plugin=PLUGIN_NONE;
		Controllers[2].Present=FALSE;
		Controllers[2].RawData=FALSE;
		Controllers[2].Plugin=PLUGIN_NONE;
		Controllers[3].Present=FALSE;
		Controllers[3].RawData=FALSE;
		Controllers[3].Plugin=PLUGIN_NONE;
		if (ContVersion==0x0100) {
			InitiateControllers_1_0(hWnd,Controllers);
		}
		if (ContVersion==0x0101) {
			CONTROL_INFO ControlInfo;
			ControlInfo.Controls=Controllers;
			ControlInfo.HEADER=RomHeader;
			ControlInfo.hinst=hInst;
			ControlInfo.hMainWindow=hWnd;
			ControlInfo.MemoryBswaped=TRUE;
			InitiateControllers_1_1(ControlInfo);
		}
	}
	if (!LoadRSPDLL(RSPDLL)) {
		FAIL_MSG=MSG_FAIL_INIT_RSP;
		PluginsInitialized=FALSE;
	} else {
		DWORD dwDataListsFromPluginInterpreterCore=0x00000000,dwDataListsToPluginRecompilerCore=0x00000001,dwDisposition;
		const char*regPath="PJ64 V 1.6.2\\Configuration\\1.6 RSP";
		HKEY hKeyResults;
		LONG lRet;
		lRet=RegCreateKeyExA(HKEY_CURRENT_USER,regPath,0,0,REG_OPTION_NON_VOLATILE,KEY_SET_VALUE,0,&hKeyResults,&dwDisposition);
		if (lRet==ERROR_SUCCESS&&CPURunning&&strcmp(RSPDLL,"RSP.dll")==0) {
			if (RomRspRecompiler) RegSetValueEx(hKeyResults,"RSP Core",0,REG_DWORD,(const BYTE*)&dwDataListsToPluginRecompilerCore,sizeof(dwDataListsToPluginRecompilerCore));
			else RegSetValueEx(hKeyResults,"RSP Core",0,REG_DWORD,(const BYTE*)&dwDataListsFromPluginInterpreterCore,sizeof(dwDataListsFromPluginInterpreterCore));
			if (strcmp(AudioDLL,"Jabo_Dsound.dll")==0) RegSetValueEx(hKeyResults,"List Type",0,REG_DWORD,(const BYTE*)&dwDataListsFromPluginInterpreterCore,sizeof(dwDataListsFromPluginInterpreterCore));
			else RegSetValueEx(hKeyResults,"List Type",0,REG_DWORD,(const BYTE*)&dwDataListsToPluginRecompilerCore,sizeof(dwDataListsToPluginRecompilerCore));
			RegCloseKey(hKeyResults);
		}
		RSP_INFO_1_0 RspInfo10;
		RSP_INFO_1_1 RspInfo11;
		RspInfo10.CheckInterrupts=CheckInterrupts;
		RspInfo11.CheckInterrupts=CheckInterrupts;
		RspInfo10.ProcessDlist=ProcessDList;
		RspInfo11.ProcessDlist=ProcessDList;
		RspInfo10.ProcessAlist=ProcessAList;
		RspInfo11.ProcessAlist=ProcessAList;
		RspInfo10.ProcessRdpList=ProcessRDPList;
		RspInfo11.ProcessRdpList=ProcessRDPList;
		RspInfo11.ShowCFB=ShowCFB;
		RspInfo10.hInst=hInst;
		RspInfo11.hInst=hInst;
		RspInfo10.RDRAM=N64MEM;
		RspInfo11.RDRAM=N64MEM;
		RspInfo10.DMEM=DMEM;
		RspInfo11.DMEM=DMEM;
		RspInfo10.IMEM=IMEM;
		RspInfo11.IMEM=IMEM;
		RspInfo10.MemoryBswaped=FALSE;
		RspInfo11.MemoryBswaped=FALSE;
		RspInfo10.MI__INTR_REG=&MI_INTR_REG;
		RspInfo11.MI__INTR_REG=&MI_INTR_REG;
		RspInfo10.SP__MEM_ADDR_REG=&SP_MEM_ADDR_REG;
		RspInfo11.SP__MEM_ADDR_REG=&SP_MEM_ADDR_REG;
		RspInfo10.SP__DRAM_ADDR_REG=&SP_DRAM_ADDR_REG;
		RspInfo11.SP__DRAM_ADDR_REG=&SP_DRAM_ADDR_REG;
		RspInfo10.SP__RD_LEN_REG=&SP_RD_LEN_REG;
		RspInfo11.SP__RD_LEN_REG=&SP_RD_LEN_REG;
		RspInfo10.SP__WR_LEN_REG=&SP_WR_LEN_REG;
		RspInfo11.SP__WR_LEN_REG=&SP_WR_LEN_REG;
		RspInfo10.SP__STATUS_REG=&SP_STATUS_REG;
		RspInfo11.SP__STATUS_REG=&SP_STATUS_REG;
		RspInfo10.SP__DMA_FULL_REG=&SP_DMA_FULL_REG;
		RspInfo11.SP__DMA_FULL_REG=&SP_DMA_FULL_REG;
		RspInfo10.SP__DMA_BUSY_REG=&SP_DMA_BUSY_REG;
		RspInfo11.SP__DMA_BUSY_REG=&SP_DMA_BUSY_REG;
		RspInfo10.SP__PC_REG=&SP_PC_REG;
		RspInfo11.SP__PC_REG=&SP_PC_REG;
		RspInfo10.SP__SEMAPHORE_REG=&SP_SEMAPHORE_REG;
		RspInfo11.SP__SEMAPHORE_REG=&SP_SEMAPHORE_REG;
		RspInfo10.DPC__START_REG=&DPC_START_REG;
		RspInfo11.DPC__START_REG=&DPC_START_REG;
		RspInfo10.DPC__END_REG=&DPC_END_REG;
		RspInfo11.DPC__END_REG=&DPC_END_REG;
		RspInfo10.DPC__CURRENT_REG=&DPC_CURRENT_REG;
		RspInfo11.DPC__CURRENT_REG=&DPC_CURRENT_REG;
		RspInfo10.DPC__STATUS_REG=&DPC_STATUS_REG;
		RspInfo11.DPC__STATUS_REG=&DPC_STATUS_REG;
		RspInfo10.DPC__CLOCK_REG=&DPC_CLOCK_REG;
		RspInfo11.DPC__CLOCK_REG=&DPC_CLOCK_REG;
		RspInfo10.DPC__BUFBUSY_REG=&DPC_BUFBUSY_REG;
		RspInfo11.DPC__BUFBUSY_REG=&DPC_BUFBUSY_REG;
		RspInfo10.DPC__PIPEBUSY_REG=&DPC_PIPEBUSY_REG;
		RspInfo11.DPC__PIPEBUSY_REG=&DPC_PIPEBUSY_REG;
		RspInfo10.DPC__TMEM_REG=&DPC_TMEM_REG;
		RspInfo11.DPC__TMEM_REG=&DPC_TMEM_REG;
		if (RSPVersion==0x0100) InitiateRSP_1_0(RspInfo10,&RspTaskValue);
		if (RSPVersion==0x0101) InitiateRSP_1_1(RspInfo11,&RspTaskValue);
	}
	SetupMenu(hMainWindow);
	UsuallyonTopWindow(hMainWindow);
	if (PluginsInitialized&&!UserCancelPluginInit) {
		if (CPURunning) {
			DWORD count;
			StartEmulation:
			RDRAMsize=NewRAMsize;
			memset(&CPU_Action,0,sizeof(CPU_Action));
			CPU_Action.hStepping=CreateEvent(0,FALSE,FALSE,0);
			WrittenToRom=FALSE;			
			InitializeTLB();
			InitializeR4300iRegisters(LoadPifRom(*(ROM+0x3D)),*(ROM+0x3D),GetCicChipID(ROM));
			OpcodeMapInterpreter();
			RecompPos=RecompCode;
			Timers.CurrentTimerType=-1;
			Timers.Timer=0;
			CurrentFrame=0;
			for (count=0;count<MaxTimers;count++) {Timers.Active[count]=FALSE;}
			ChangeTimer(ViTimer,5000);
			ChangeCompareTimer();
			ViFieldSerration=0;
			DMAUsed=FALSE;
			CPU_Paused=FALSE;
			ManualPaused=FALSE;
			Timer_Start();
			if (CpuRecompiler) hCPU=CreateThread(0,0,(LPTHREAD_START_ROUTINE)StartRecompilerCPU,0,0,0);
			else hCPU=CreateThread(0,0,(LPTHREAD_START_ROUTINE)StartInterpreterCPU,0,0,0);
			if (GLideN64NeedsToBeSetupFirst) {
				EndEmulation();
				DONE_INIT_GLideN64:
				GonetzGLHasBeenSetupFirst=TRUE;
				GLideN64NeedsToBeSetupFirst=FALSE;
				strcpy(GfxDLL,"Icepir8sLegacyLLE.dll");
				goto SIZE_MAXIMIZE;
			}
			if (strcmp(GfxDLL,"GLideN64.dll")==0&&!GonetzGLHasBeenSetupFirst) GonetzGLHasBeenSetupFirst=TRUE;
			if (EmulateAI&&!LimitFPS) {
				LimitFPS=TRUE;
				HandleTimers();
				LimitFPS=FALSE;
				if (SpeedCap) HandleTimers();
			} else HandleTimers();
			SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(MSG_EMULATION_STARTED));
		} else SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(PLUGINS_INITIALIZED));
	} else {
		if (UserCancelPluginInit) goto SKIP_INIT;
		if (inFullScreen) SendMessage(hMainWindow,WM_COMMAND,ID_OPTIONS_FULLSCREEN,0);
		if (!UserCancelPluginInit) HandleModal1(hMainWindow);
		if (CPURunning) {
			if (MessageBox(0,GS(FAIL_MSG),AppName,MB_OKCANCEL|MB_ICONEXCLAMATION|MB_SETFOREGROUND)==IDCANCEL) {
				UserCancelPluginInit=TRUE;
				OpenRomBrowser();
				UserCancelPluginInit=FALSE;
				return;
			}
		} else if (MessageBox(0,GS(FAIL_MSG),AppName,MB_OKCANCEL|MB_ICONEXCLAMATION|MB_SETFOREGROUND)==IDCANCEL) SKIP_INIT: PluginsInitialized=TRUE;
		HandleModal2(hMainWindow);
		if (PluginsInitialized) SendMessage(hStatusWnd,SB_SETTEXT,0,(LPARAM)GS(PLUGINS_NOT_INITIALIZED));
		else {
			SendMessage(hMainWindow,WM_COMMAND,ID_OPTIONS_SETTINGS,0);
			if (CPURunning) HandlePluginsAndEmulationStartup();
		}
	}
}
void SetupPluginsScreen (HWND hDlg) {
	WIN32_FIND_DATA FindData;
	PLUGIN_INFO PluginInfo;
	char SearchsStr[300],Plugin[300];
	HANDLE hFind,hLib;
	int index;
	SetDlgItemText(hDlg,RSP_ABOUT,GS(PLUG_ABOUT));
	SetDlgItemText(hDlg,GFX_ABOUT,GS(PLUG_ABOUT));
	SetDlgItemText(hDlg,AUDIO_ABOUT,GS(PLUG_ABOUT));
	SetDlgItemText(hDlg,CONT_ABOUT,GS(PLUG_ABOUT));
	SetDlgItemText(hDlg,IDC_RSP_NAME,GS(PLUG_RSP));
	SetDlgItemText(hDlg,IDC_GFX_NAME,GS(PLUG_GFX));
	SetDlgItemText(hDlg,IDC_AUDIO_NAME,GS(PLUG_AUDIO));
	SetDlgItemText(hDlg,IDC_CONT_NAME,GS(PLUG_CTRL));
	GetPluginDir(SearchsStr);
	strcat(SearchsStr,"*.dll");
	hFind=FindFirstFile(SearchsStr,&FindData);
	if (hFind==INVALID_HANDLE_VALUE) return;
	PluginCount=0;
	for (;;) {
		PluginNames[PluginCount]=malloc(strlen(FindData.cFileName)+1);
		strcpy(PluginNames[PluginCount],FindData.cFileName);
		GetPluginDir(Plugin);
		strcat(Plugin,PluginNames[PluginCount]);
		hLib=LoadLibrary(Plugin);
		if (hLib==0) {
			DisplayError("%s\n %s",GS(MSG_FAIL_LOAD_PLUGIN),Plugin);
			if (FindNextFile(hFind,&FindData)==0) return;
			continue;
		}
		GetDllInfo=(void (__cdecl*)(PLUGIN_INFO*))GetProcAddress(hLib,"GetDllInfo");
		if (GetDllInfo==0) {
			FreeLibrary(hLib);
			if (FindNextFile(hFind,&FindData)==0) return;
			continue;
		}
		GetDllInfo(&PluginInfo);
		if (!ValidPluginVersion(&PluginInfo)||
			(PluginInfo.Type!=PLUGIN_TYPE_CONTROLLER&&PluginInfo.MemoryBswaped==FALSE))
		{
			FreeLibrary(hLib);
			if (FindNextFile(hFind,&FindData)==0) return;
			continue;
		}
		switch(PluginInfo.Type) {
		case PLUGIN_TYPE_RSP:
			index=SendMessage(GetDlgItem(hDlg,RSP_LIST),CB_ADDSTRING,(WPARAM)0,(LPARAM)&PluginInfo.Name);
			SendMessage(GetDlgItem(hDlg,RSP_LIST),CB_SETITEMDATA,(WPARAM)index,(LPARAM)PluginCount);
			if(_stricmp(RSPDLL,PluginNames[PluginCount])==0) {
				SendMessage(GetDlgItem(hDlg,RSP_LIST),CB_SETCURSEL,(WPARAM)index,(LPARAM)0);
				RSPDLLAbout=(void (__cdecl*)(HWND))GetProcAddress(hLib,"DllAbout");
				EnableWindow(GetDlgItem(hDlg,RSP_ABOUT),RSPDLLAbout!=0?TRUE:FALSE);
			} else {
				FreeLibrary(hLib);
			}
			break;
		case PLUGIN_TYPE_GFX:
			index=SendMessage(GetDlgItem(hDlg,GFX_LIST),CB_ADDSTRING,(WPARAM)0,(LPARAM)&PluginInfo.Name);
			SendMessage(GetDlgItem(hDlg,GFX_LIST),CB_SETITEMDATA,(WPARAM)index,(LPARAM)PluginCount);
			if(_stricmp(GfxDLL,PluginNames[PluginCount])==0) {
				SendMessage(GetDlgItem(hDlg,GFX_LIST),CB_SETCURSEL,(WPARAM)index,(LPARAM)0);
				GFXDllAbout=(void (__cdecl*)(HWND))GetProcAddress(hLib,"DllAbout");
				EnableWindow(GetDlgItem(hDlg,GFX_ABOUT),GFXDllAbout!=0?TRUE:FALSE);
			} else {
				FreeLibrary(hLib);
			}
			break;
		case PLUGIN_TYPE_AUDIO:
			index=SendMessage(GetDlgItem(hDlg,AUDIO_LIST),CB_ADDSTRING,(WPARAM)0,(LPARAM)&PluginInfo.Name);
			SendMessage(GetDlgItem(hDlg,AUDIO_LIST),CB_SETITEMDATA,(WPARAM)index,(LPARAM)PluginCount);
			if(_stricmp(AudioDLL,PluginNames[PluginCount])==0) {
				SendMessage(GetDlgItem(hDlg,AUDIO_LIST),CB_SETCURSEL,(WPARAM)index,(LPARAM)0);
				AiDllAbout=(void (__cdecl*)(HWND))GetProcAddress(hLib,"DllAbout");
				EnableWindow(GetDlgItem(hDlg,AUDIO_ABOUT),AiDllAbout!=0?TRUE:FALSE);
			} else {
				FreeLibrary(hLib);
			}
			break;
		case PLUGIN_TYPE_CONTROLLER:
			index=SendMessage(GetDlgItem(hDlg,CONT_LIST),CB_ADDSTRING,(WPARAM)0,(LPARAM)&PluginInfo.Name);
			SendMessage(GetDlgItem(hDlg,CONT_LIST),CB_SETITEMDATA,(WPARAM)index,(LPARAM)PluginCount);
			if(_stricmp(ControllerDLL,PluginNames[PluginCount])==0) {
				SendMessage(GetDlgItem(hDlg,CONT_LIST),CB_SETCURSEL,(WPARAM)index,(LPARAM)0);
				ContDllAbout=(void (__cdecl*)(HWND))GetProcAddress(hLib,"DllAbout");
				EnableWindow(GetDlgItem(hDlg,CONT_ABOUT),ContDllAbout!=0?TRUE:FALSE);
			} else {
				FreeLibrary(hLib);
			}
			break;
		}
		PluginCount+=1;
		if (FindNextFile(hFind,&FindData)==0) return;
	}
}
void ShutdownPlugins (void) {
	if (!inFullScreen) {
		if (GFXCloseDLL!=0) GFXCloseDLL();
		FreeLibrary(hGfxDll);
	}
	if (GLideN64NeedsToBeSetupFirst) return;
	TerminateThread(hAudioThread,0);
	if (AiCloseDLL!=0) AiCloseDLL();
	FreeLibrary(hAudioDll);
	if (ContCloseDLL!=0) ContCloseDLL();
	FreeLibrary(hControllerDll);
	if (RSPCloseDLL!=0) RSPCloseDLL();
	FreeLibrary(hRSPDLL);
}
BOOL ValidPluginVersion (PLUGIN_INFO*PluginInfo) {
	switch (PluginInfo->Type) {
	case PLUGIN_TYPE_RSP:
		if (PluginInfo->Version==0x0001||PluginInfo->Version==0x0100||PluginInfo->Version==0x0101) return TRUE;
	case PLUGIN_TYPE_GFX:
		if (PluginInfo->Version==0x0102||PluginInfo->Version==0x0103) return TRUE;
	case PLUGIN_TYPE_AUDIO:
		if (PluginInfo->Version==0x0101) return TRUE;
	case PLUGIN_TYPE_CONTROLLER:
		if (PluginInfo->Version==0x0100||PluginInfo->Version==0x0101) return TRUE;
	}
	return FALSE;
}